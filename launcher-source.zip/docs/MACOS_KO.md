# 츄르월드 macOS 배포

이 빌드는 유료 Apple 개발자 인증서를 사용하지 않는다. Apple Silicon에서 실행할 수 있도록 로컬 ad-hoc 서명을 적용하지만, 개발자 신원 인증이나 Apple 공증은 아니다. 따라서 처음 실행할 때 macOS의 확인 경고가 나타날 수 있다.

## Mac에서 설치 파일 만들기

Node.js 22를 설치한 Mac에서 프로젝트 폴더를 열고 터미널에서 실행한다.

```sh
bash tools/build-mac.command
```

의존성 설치, 테스트, Intel 및 Apple Silicon 빌드, 패키지 서명·아키텍처 검사가 끝나면 `dist` 폴더가 열린다. 이 명령은 GitHub에 업로드하지 않는다.

- `ChurWorld-Launcher-setup-2.2.6-arm64.dmg`: M 시리즈 맥
- `ChurWorld-Launcher-setup-2.2.6-x64.dmg`: 인텔 맥

파일명 버전은 package.json 버전에 따라 바뀐다. macOS 12 이상을 지원하는 Electron 39 기반이다. 실제 Mac에서 로그인과 Minecraft 1.21.4 실행을 확인한 뒤 배포한다.

## GitHub 무료 빌드

런처 소스가 들어 있는 공개 저장소에서 `.github/workflows/macos.yml`을 사용한다. **기존 churworld-distribution에는 모드 배포 파일만 있으므로 이 워크플로 파일만 올리면 빌드되지 않는다.** 소스 공개가 허용된 경우에만 준비한 소스 묶음을 올린다. 원본 `.github/workflows/build.yml`은 모든 OS를 자동 빌드하는 기존 파일이므로, 준비한 묶음에는 포함하지 않는다.

1. Actions에서 `Build macOS DMG (free, manual install)` 선택
2. `Run workflow` 실행
3. 두 아키텍처의 빌드가 완료되면 Artifacts의 `ChurWorld-macOS-arm64`, `ChurWorld-macOS-x64` 다운로드
4. 다운로드한 ZIP을 풀어 DMG를 꺼낸다.
5. 실제 Mac에서 테스트한 DMG 두 개를 **dlworn5434/churworld-distribution**의 동일 버전 릴리스(현재 `v2.2.6`) Assets에 추가한다. 윈도우 설치 파일이나 `latest.yml`을 교체할 필요는 없다.

이 워크플로는 설치 파일만 만들며 릴리스를 자동 게시하지 않는다. 표준 공개 저장소 빌드를 사용한다. 비공개 저장소의 실행 한도를 초과하면 과금될 수 있으므로 무료 사용 목적으로 비공개 저장소에서 임의 실행하지 않는다.

## 이용자 설치 및 업데이트

1. 맥의 칩에 맞는 DMG 다운로드
2. DMG를 열어 `ChurWorld Launcher`를 `응용 프로그램`으로 드래그
3. 출처와 파일이 확실한데 개발자 확인 경고가 뜨는 경우 Apple의 안내에 따라 시스템 설정 → 개인정보 보호 및 보안 → 그래도 열기 사용
4. 업데이트 알림이 뜨면 새 DMG를 내려받고, 실행 중인 런처를 종료한 후 응용 프로그램의 런처를 교체

맥에서는 GitHub 릴리스의 해당 CPU용 DMG를 확인해 다운로드 버튼을 제공한다. 앱 자동 교체는 하지 않는다. Windows만 올라온 버전이나 업로드 중인 DMG는 업데이트 대상으로 표시하지 않는다. 모드 다운로드/패치는 기존 게임 실행 흐름을 사용한다.

참고: https://support.apple.com/ko-kr/102445
