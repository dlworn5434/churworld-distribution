# 런처 2.2.7 자동 업데이트 준비

2026-10-04. Windows 설치 파일은 로컬 빌드하며 GitHub 게시를 자동 수행하지 않는다. Mac은 기존 수동 GitHub Actions 또는 실제 Mac의 빌드가 필요하다.

## 이용자에게 적용되는 흐름

- Windows: 기존 2.2.6부터 GitHub Release의 latest.yml을 읽고 새 EXE를 자동 다운로드한다. 다운로드가 끝나면 런처 종료 시 설치하고, 업데이트 화면의 설치 버튼으로도 조용히 설치·재시작할 수 있다. 2.2.7에는 배포 모드의 구버전 정리 기능이 포함된다.
- macOS: 기존 2.2.6에는 앱 교체 코드가 없으므로 2.2.7을 한 번 DMG로 설치해야 한다. **2.2.7 이후부터** 다음 버전의 같은 CPU용 DMG를 자동 다운로드·검증·준비하고 Cmd+Q로 런처를 종료할 때 교체한다. 설치 버튼은 종료·교체 후 런처를 다시 연다. 다운로드 완료만으로 실행 중인 런처나 게임을 강제 종료하지 않는다.
- 게임의 모드 다운로드는 기존 게임 시작 흐름을 따른다. 이전 모드 정리는 새 배포 파일 검증에 성공했을 때 동작한다. 기록이 없는 과거 누적 파일과 사용자가 넣은 모드는 추측해서 삭제하지 않는다. 자세한 범위는 MANAGED_MODS_KO.md 참조.

## 맥 설치 검증 및 실패 처리

현재 무료 ad-hoc 서명을 유지한다. electron-updater의 Developer ID 기반 Squirrel 설치 대신 자체 DMG 교체 경로를 사용한다. GitHub API의 해당 Release asset SHA-256과 크기를 검증하고, read-only로 마운트한 앱의 ID(helioslauncher), 버전, 실행 파일 이름, CPU와 codesign 검증을 통과해야 설치를 준비한다. GitHub digest가 없는 구형 자산은 수동 다운로드만 제공한다.

앱은 실제 쓰기 가능한 Applications 또는 사용자 Applications 폴더에 설치해야 한다. DMG의 /Volumes 및 AppTranslocation에서 실행하면 자동 교체하지 않는다. 읽기 전용 설치 폴더도 자동 권한 상승 없이 실패 안내·재시도를 제공한다. 필요하면 쓰기 가능한 사용자 응용 프로그램 폴더로 옮긴다.

다운로드 및 다음 앱은 설치 폴더와 같은 파일 시스템의 고정 .churworld-update-… 폴더 하나에서 준비한다. 설치 도우미는 런처 PID 종료를 기다리고, 기존 앱의 파일 정체성과 버전 및 새 앱 서명을 다시 확인한다. 기존 앱을 임시 백업으로 이동한 뒤 새 앱으로 교체하며 실패 시 원래 앱을 복구한다. 정상 완료 후 임시 DMG·백업을 제거하므로 성공한 업데이트가 계속 누적되지 않는다. 비정상 종료로 마운트 또는 교체 백업이 남으면 임의 삭제하지 않고 중단한다. 앱 교체 사이에 전원 차단 등 강제 중단이 있으면 이전 앱이 해당 폴더의 previous.app에 남을 수 있으므로 복구가 필요하다.

작업 폴더 소유 토큰·경로·잠금으로 다른 업데이트와 경합하지 않게 한다. 심볼릭 링크로 바뀐 앱 루트·작업 폴더는 거부한다. 사용자 게임 디렉터리·모드·설정·세이브·계정 파일은 앱 교체 대상으로 포함하지 않는다. 시스템 보호 설정 변경, quarantine 속성 제거, 관리자 권한 요청, 다운로드한 앱의 재서명은 수행하지 않는다. macOS의 추가 확인이 나타나면 운영체제의 정상 확인 절차가 필요하다.

업데이트 오류 메시지는 설정의 업데이트 버튼 도움말과 로그에 남는다. 설치 도우미 로그는 Electron userData의 launcher-update.log이며 각 설치 시 덮어쓴다. 로그에 계정·토큰은 기록하지 않는다.

## 배포 파일

Windows용 새 정식 v2.2.7 Release에 아래 세 파일을 **같은 빌드 결과로** 올린다. 이전 v2.2.6 자산을 덮어쓰지 않는다.

1. ChurWorld-Launcher-setup-2.2.7.exe
2. ChurWorld-Launcher-setup-2.2.7.exe.blockmap
3. latest.yml

Mac은 새 launcher-source.zip과 .github/workflows/macos.yml을 배포 저장소의 해당 파일에 반영하고, 사용자가 Actions를 실행한다. 두 CPU의 빌드·서명·실제 파일 교체 fixture 테스트가 통과한 DMG를 같은 v2.2.7 Release에 추가한다. 첫 배포에는 양쪽 DMG를 모두 준비한다. GitHub가 업로드 완료한 asset의 digest를 제공하므로 별도 latest-mac.yml/ZIP/만료되는 서명 URL이 필요하지 않다. DMG는 고정 releases/download/v2.2.7/… 주소를 공유한다.

로컬 파일 준비는 커밋·push·Actions 실행·Release 게시와 다르다. 현재 게시하지 않았으며 이용자 설치 버전에 자동 전달된 상태도 아니다.

## 검증

Node 22에서 node --test tools/tests/*.test.js를 실행한다. Windows에서는 기존 모드 정리 및 새 자동 다운로드·실패·동시 실행·IPC 테스트를 실행한다. native macOS 세 테스트는 Windows에서 명시적으로 건너뛰며 실제 Mac/Actions에서 실행한다. 이 테스트는 임시 모의 .app과 로컬 DMG만 만들고 실제 런처·게임·운영 서버는 시작하지 않는다. 실제 사용자 Mac의 Gatekeeper·설치 권한·게임 접속 검증은 별도다.

macOS 기본 전제 참고: https://www.electron.build/v26/docs/features/auto-update/
