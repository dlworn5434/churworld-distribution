'use strict'

// Operator-only tool. Never embed this private vault in an application or ZIP.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const {spawnSync} = require('node:child_process')
const PREFIX = Buffer.from('ChurWorld signed manifest v1\n')
const options = new Map()
for(let i = 3; i < process.argv.length; i += 2) {
    if(!process.argv[i].startsWith('--') || !process.argv[i + 1]) throw new Error('Expected --option value.')
    options.set(process.argv[i].slice(2), process.argv[i + 1])
}
const operation = process.argv[2]
const vault = path.resolve(options.get('key-dir') || path.join(process.env.LOCALAPPDATA || '', 'ChurWorldSigning'))
const keyFile = path.join(vault, 'release-key.dpapi.json')
function powershell(script, input, extraEnv = {}) {
    const executable = path.join(process.env.SystemRoot || 'C:/Windows', 'System32/WindowsPowerShell/v1.0/powershell.exe')
    const environment = {...process.env, ...extraEnv}
    // PowerShell 7 module paths cannot be inherited by Windows PowerShell 5.1.
    delete environment.PSModulePath
    const result = spawnSync(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script], {
        input, encoding:'utf8', windowsHide:true, timeout:20000,
        env:environment, maxBuffer:1024 * 1024
    })
    if(result.error || result.status !== 0) throw new Error('Windows key protection operation failed. No plaintext key was saved.')
    return result.stdout.trim()
}
function protectDirectory() {
    fs.mkdirSync(vault, {recursive:true})
    const info = fs.lstatSync(vault)
    if(!info.isDirectory() || info.isSymbolicLink() || fs.realpathSync(vault).toLowerCase() !== vault.toLowerCase()) throw new Error('Unsafe key directory.')
    powershell("$ErrorActionPreference='Stop'; $p=$env:CHURU_SIGNING_VAULT; $sid=[System.Security.Principal.WindowsIdentity]::GetCurrent().User; $acl=New-Object System.Security.AccessControl.DirectorySecurity; $acl.SetAccessRuleProtection($true,$false); $rule=New-Object System.Security.AccessControl.FileSystemAccessRule($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow'); $acl.AddAccessRule($rule); Set-Acl -LiteralPath $p -AclObject $acl", '', {CHURU_SIGNING_VAULT:vault})
}
function dpapi(bytes, decrypt) {
    const method = decrypt ? 'Unprotect' : 'Protect'
    const script = "$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.Security; $data=[Convert]::FromBase64String([Console]::In.ReadToEnd()); $entropy=[Text.Encoding]::UTF8.GetBytes('ChurWorld-release-signing-key-v1'); $out=[System.Security.Cryptography.ProtectedData]::" + method + "($data,$entropy,[System.Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Convert]::ToBase64String($out)); [Array]::Clear($data,0,$data.Length); [Array]::Clear($out,0,$out.Length)"
    return Buffer.from(powershell(script, bytes.toString('base64')), 'base64')
}
function writeExclusive(file, bytes) {
    const target = path.resolve(file)
    fs.mkdirSync(path.dirname(target), {recursive:true})
    const fd = fs.openSync(target, 'wx', 0o600)
    try { fs.writeFileSync(fd, bytes); fs.fsyncSync(fd) } finally { fs.closeSync(fd) }
}
function readVault() {
    const info = fs.lstatSync(keyFile)
    if(!info.isFile() || info.isSymbolicLink() || info.size > 16384) throw new Error('Unsafe signing key file.')
    const value = JSON.parse(fs.readFileSync(keyFile, 'utf8'))
    if(value.schema !== 1 || value.protection !== 'Windows-DPAPI-CurrentUser' || !value.key?.publicKeySpki || !value.ciphertext) throw new Error('Invalid signing key vault.')
    return value
}
function publicTrust(value) { return {schema:1, keys:[value.key]} }
function reserveSequence(manifest, payload) {
    // Prevent an operator from publishing two different payloads under the same
    // sequence. This local ledger is independent of the repository checkout.
    const ledgerFile = path.join(vault, 'release-sequences.json')
    const lockFile = path.join(vault, 'release-sequences.lock')
    const lock = fs.openSync(lockFile, 'wx', 0o600)
    const temporary = path.join(vault, `release-sequences.${crypto.randomBytes(12).toString('hex')}.tmp`)
    try {
        let ledger = {schema:1, purposes:{}}
        if(fs.existsSync(ledgerFile)) {
            const stat = fs.lstatSync(ledgerFile)
            if(!stat.isFile() || stat.isSymbolicLink() || stat.size > 16384) throw new Error('Unsafe signing sequence ledger.')
            ledger = JSON.parse(fs.readFileSync(ledgerFile, 'utf8'))
            if(ledger.schema !== 1 || !ledger.purposes || typeof ledger.purposes !== 'object') throw new Error('Invalid signing sequence ledger.')
        }
        const digest = crypto.createHash('sha256').update(payload).digest('hex')
        const previous = ledger.purposes[manifest.purpose]
        if(previous && (!Number.isSafeInteger(previous.sequence) || !/^[a-f0-9]{64}$/.test(previous.digest)
            || !Number.isFinite(Date.parse(previous.issuedAt)))) throw new Error('Invalid previous signing sequence.')
        if(previous && (manifest.sequence < previous.sequence || (manifest.sequence === previous.sequence && digest !== previous.digest)
            || Date.parse(manifest.issuedAt) < Date.parse(previous.issuedAt))) throw new Error('Signing sequence rollback or conflicting payload refused. Use a new sequence.')
        ledger.purposes[manifest.purpose] = {sequence:manifest.sequence, digest, issuedAt:manifest.issuedAt}
        writeExclusive(temporary, JSON.stringify(ledger, null, 2))
        fs.renameSync(temporary, ledgerFile)
    } finally {
        if(fs.existsSync(temporary)) fs.unlinkSync(temporary)
        fs.closeSync(lock)
        fs.unlinkSync(lockFile)
    }
}
function main() {
    if(process.platform !== 'win32') throw new Error('This operator key vault requires Windows DPAPI. Public verification works cross-platform.')
    if(operation === 'init') {
        if(fs.existsSync(keyFile)) throw new Error('Signing key already exists; refusing to replace it.')
        const id = options.get('id')
        if(!/^[a-z0-9][a-z0-9-]{2,63}$/.test(id || '')) throw new Error('A safe --id is required.')
        if(!options.get('public-out')) throw new Error('--public-out is required.')
        protectDirectory()
        const pair = crypto.generateKeyPairSync('ed25519')
        const privateDer = pair.privateKey.export({type:'pkcs8', format:'der'})
        const now = new Date()
        const until = new Date(now); until.setUTCFullYear(until.getUTCFullYear() + 2)
        const key = {id, algorithm:'Ed25519', publicKeySpki:pair.publicKey.export({type:'spki', format:'der'}).toString('base64'), purposes:['distribution', 'launcher-update'], notBefore:new Date(now.getTime() - 300000).toISOString(), notAfter:until.toISOString()}
        let protectedBytes
        try { protectedBytes = dpapi(privateDer, false) } finally { privateDer.fill(0) }
        const value = {schema:1, protection:'Windows-DPAPI-CurrentUser', createdAt:now.toISOString(), key, ciphertext:protectedBytes.toString('base64')}
        const recovered = dpapi(protectedBytes, true)
        try {
            const check = crypto.createPrivateKey({key:recovered, type:'pkcs8', format:'der'})
            if(crypto.createPublicKey(check).export({type:'spki', format:'der'}).toString('base64') !== key.publicKeySpki) throw new Error('Signing key recovery verification failed.')
        } finally { recovered.fill(0) }
        writeExclusive(keyFile, JSON.stringify(value, null, 2))
        writeExclusive(options.get('public-out'), JSON.stringify(publicTrust(value), null, 2))
        console.log(JSON.stringify({operation, keyId:id, encryptedVault:keyFile, publicConfig:path.resolve(options.get('public-out'))}))
    } else if(operation === 'export-public') {
        if(!options.get('out')) throw new Error('--out is required.')
        const value = readVault()
        writeExclusive(options.get('out'), JSON.stringify(publicTrust(value), null, 2))
        console.log(JSON.stringify({operation, keyId:value.key.id, file:path.resolve(options.get('out'))}))
    } else if(operation === 'sign') {
        if(!options.get('input') || !options.get('out')) throw new Error('--input and --out are required.')
        const value = readVault()
        const input = path.resolve(options.get('input'))
        const stat = fs.lstatSync(input)
        if(!stat.isFile() || stat.isSymbolicLink() || stat.size > 2 * 1024 * 1024) throw new Error('Unsafe or excessive signing payload.')
        const payload = fs.readFileSync(input)
        const manifest = JSON.parse(payload.toString('utf8'))
        if(manifest.schema !== 1 || !value.key.purposes.includes(manifest.purpose) || !Number.isSafeInteger(manifest.sequence) || manifest.sequence < 1) throw new Error('Invalid manifest purpose or sequence.')
        const now = Date.now(), issued = Date.parse(manifest.issuedAt), expires = Date.parse(manifest.expiresAt)
        if(!Number.isFinite(issued) || !Number.isFinite(expires) || issued > now + 300000 || expires <= now || expires <= issued || expires - issued > 30 * 86400000 || now < Date.parse(value.key.notBefore) || expires > Date.parse(value.key.notAfter)) throw new Error('Invalid manifest or signing key lifetime (maximum 30 days).')
        const privateDer = dpapi(Buffer.from(value.ciphertext, 'base64'), true)
        let signature
        try {
            const privateKey = crypto.createPrivateKey({key:privateDer, type:'pkcs8', format:'der'})
            const publicKey = crypto.createPublicKey(privateKey)
            if(publicKey.export({type:'spki', format:'der'}).toString('base64') !== value.key.publicKeySpki) throw new Error('Signing key metadata mismatch.')
            signature = crypto.sign(null, Buffer.concat([PREFIX, payload]), privateKey)
            if(!crypto.verify(null, Buffer.concat([PREFIX, payload]), publicKey, signature)) throw new Error('Signature self-verification failed.')
        } finally { privateDer.fill(0) }
        const envelope = {schema:1, keyId:value.key.id, payload:payload.toString('base64'), signature:signature.toString('base64')}
        // The operator and application must accept exactly the same schema,
        // source URLs, filenames, key lifetime and platform constraints.
        require('../app/assets/js/trusted-manifest').verifyEnvelope(envelope, {purpose:manifest.purpose, keys:publicTrust(value), now})
        // Reserve before output: if output fails, an identical retry remains
        // possible but a conflicting payload never receives this sequence.
        reserveSequence(manifest, payload)
        writeExclusive(options.get('out'), JSON.stringify(envelope, null, 2))
        console.log(JSON.stringify({operation, keyId:value.key.id, purpose:manifest.purpose, sequence:manifest.sequence, output:path.resolve(options.get('out'))}))
    } else throw new Error('Use init, export-public, or sign. Private key export is deliberately unavailable.')
}
try { main() } catch(error) { console.error(error.message); process.exitCode = 1 }
