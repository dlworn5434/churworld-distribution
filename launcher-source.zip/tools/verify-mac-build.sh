#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

arch="${1:?Specify arm64 or x64}"
case "$arch" in
  arm64) app_dir='dist/mac-arm64'; binary_arch='arm64' ;;
  x64) app_dir='dist/mac'; binary_arch='x86_64' ;;
  *) echo 'Unsupported architecture' >&2; exit 1 ;;
esac
app="$app_dir/ChurWorld Launcher.app"
version="$(node -p 'require("./package.json").version')"
dmg="dist/ChurWorld-Launcher-setup-$version-$arch.dmg"

test -s "$dmg"
test -s "$app/Contents/Resources/app.asar"
test -s "$app/Contents/Resources/icon.icns"
codesign --verify --deep --strict --verbose=2 "$app"
lipo "$app/Contents/MacOS/ChurWorld Launcher" -verify_arch "$binary_arch"
hdiutil verify "$dmg"
shasum -a 256 "$dmg"
echo 'Package checks passed. Minecraft login and game launch still require a real Mac test.'
