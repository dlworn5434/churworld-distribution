const fs = require('node:fs')
const path = require('node:path')
const AdmZip = require('adm-zip')

const root = path.resolve(__dirname, '..')
const output = path.join(root, 'dist', 'mac-source', 'launcher-source.zip')
const archive = new AdmZip()
const selected = []

function add(relative) {
    const absolute = path.join(root, relative)
    const stat = fs.lstatSync(absolute)
    if (stat.isSymbolicLink()) throw new Error(`Do not export symlinks: ${relative}`)
    if (stat.isDirectory()) {
        for (const name of fs.readdirSync(absolute).sort()) {
            if (name.startsWith('.') || name.includes('.bak.') || name.endsWith('.log')) continue
            add(path.posix.join(relative, name))
        }
    } else {
        archive.addFile(relative, fs.readFileSync(absolute))
        selected.push(relative)
    }
}

// Export only the distributable app and its build inputs. Never bundle .git,
// installed dependencies, account settings, backups or old release artifacts.
for (const relative of [
    'app', 'build', 'libraries', 'index.js', 'package.json', 'package-lock.json',
    'electron-builder.yml', 'LICENSE.txt', 'tools/tests', 'tools/build-mac.command',
    'tools/verify-mac-build.sh', 'tools/export-mac-source.cjs', 'docs/MACOS_KO.md'
]) add(relative)

fs.mkdirSync(path.dirname(output), { recursive: true })
archive.writeZip(output)
console.log(`Exported ${selected.length} files (${fs.statSync(output).size} bytes): ${output}`)
