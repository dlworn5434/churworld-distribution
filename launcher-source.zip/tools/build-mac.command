#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ "$(uname -s)" != 'Darwin' ]]; then
    echo 'This build must run on macOS.' >&2
    exit 1
fi
if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
    echo 'Install Node.js 22 LTS from https://nodejs.org/ first.' >&2
    exit 1
fi
if [[ "$(node -p 'process.versions.node.split(".")[0]')" != '22' ]]; then
    echo 'Please select Node.js 22 before building.' >&2
    exit 1
fi

export CSC_IDENTITY_AUTO_DISCOVERY=false
npm ci
node --test tools/tests/*.test.js
npm run dist:mac
bash tools/verify-mac-build.sh arm64
bash tools/verify-mac-build.sh x64
open dist
