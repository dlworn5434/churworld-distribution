// Build a bundled migration catalogue from this distribution repository's
// reachable main history. No network, checkout changes or player file access.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { execFileSync } = require('node:child_process')

const [repository, output, reportPath] = process.argv.slice(2)
if(!repository || !output || !reportPath) throw new Error('Usage: node export-managed-mod-history.cjs <distribution-repo> <catalogue.json> <audit.json>')
const git = (...args) => execFileSync('git', ['-C', repository, ...args], { maxBuffer: 128 * 1024 * 1024, windowsHide: true })
const head = git('rev-parse', 'HEAD').toString().trim()
const commits = git('rev-list', head, '--', 'distribution.json').toString().trim().split(/\r?\n/)
const blobs = new Map()
const records = new Map()
const skipped = []
let definitions = 0
for(const commit of commits) {
    const tree = new Map(git('ls-tree', '-r', commit, '--', 'files/mods').toString().trim().split(/\r?\n/).filter(Boolean).map(line => {
        const match = /^100644 blob ([a-f0-9]{40})\t(.+)$/.exec(line)
        return match ? [match[2], match[1]] : ['', '']
    }))
    let distribution
    try { distribution = JSON.parse(git('show', `${commit}:distribution.json`).toString().replace(/^\uFEFF/, '')) }
    catch { skipped.push({ commit, reason: 'missing or invalid manifest' }); continue }
    for(const server of distribution.servers || []) {
        if(typeof server.id !== 'string' || !server.id) continue
        const visit = modules => {
            for(const module of modules || []) {
                if(module.type === 'FabricMod') {
                    definitions++
                    const artifact = module.artifact || {}
                    // Historical filenames are explicit in these manifests.
                    // Never derive a deletion path from a URL or a name prefix.
                    const relative = artifact.path
                    if(typeof relative !== 'string' || !/\.jar$/i.test(relative) || relative.split('/').some(p => !p || p === '.' || p === '..' || /[:\\\0]/.test(p))) {
                        skipped.push({ commit, id: module.id, reason: 'no safe explicit path' }); continue
                    }
                    const file = `files/mods/${relative}`
                    let url
                    try { url = new URL(artifact.url) } catch { continue }
                    if(url.origin !== 'https://raw.githubusercontent.com' || decodeURIComponent(url.pathname) !== `/dlworn5434/churworld-distribution/main/${file}`) {
                        skipped.push({ commit, file, reason: 'different artifact origin/path' }); continue
                    }
                    const blob = tree.get(file)
                    if(!blob) { skipped.push({ commit, file, reason: 'artifact absent in same commit' }); continue }
                    if(!blobs.has(blob)) {
                        const bytes = git('cat-file', 'blob', blob)
                        blobs.set(blob, {
                            size: bytes.length,
                            md5: crypto.createHash('md5').update(bytes).digest('hex'),
                            sha256: crypto.createHash('sha256').update(bytes).digest('hex')
                        })
                    }
                    const actual = blobs.get(blob)
                    if(actual.size !== artifact.size || actual.md5 !== String(artifact.MD5).toLowerCase()) {
                        skipped.push({ commit, file, reason: 'manifest hash/size differs from Git blob' }); continue
                    }
                    const key = `${relative}:${actual.sha256}`
                    if(!records.has(key)) records.set(key, { path: `mods/fabric/${relative}`, ...actual, servers: [], evidenceCommit: commit, evidenceBlob: blob })
                    const record = records.get(key)
                    if(!record.servers.includes(server.id)) record.servers.push(server.id)
                }
                visit(module.subModules)
            }
        }
        visit(server.modules)
    }
}
const entries = [...records.values()].sort((a, b) => a.path.localeCompare(b.path) || a.sha256.localeCompare(b.sha256))
for(const record of entries) record.servers.sort()
const catalogue = { version: 1, repository: 'dlworn5434/churworld-distribution', head, records: entries }
fs.mkdirSync(path.dirname(output), { recursive: true })
fs.writeFileSync(output, `${JSON.stringify(catalogue, null, 2)}\n`)
const report = { head, commits: commits.length, definitions, uniqueBlobs: blobs.size, records: entries.length, skipped, catalogueSha256: crypto.createHash('sha256').update(fs.readFileSync(output)).digest('hex') }
fs.writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`)
console.log(JSON.stringify({ ...report, skipped: skipped.length, picturedVersions: entries.filter(x => /hybridevents-fabric-0\.26\.(0|3|6|8|9)\.jar$/.test(x.path)) }, null, 2))
