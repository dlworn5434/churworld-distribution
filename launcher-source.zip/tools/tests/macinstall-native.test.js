// These tests exercise real macOS tools against disposable fixture apps only.
// They never launch the launcher, Minecraft, or a user's installed application.
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const { execFile, spawn } = require('node:child_process')
const { promisify } = require('node:util')
const { MacAutoUpdater } = require('../../app/assets/js/macautoupdater')
const run = promisify(execFile)
const native = { skip: process.platform !== 'darwin' }

async function fixture(t) {
    const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'chur-mac-native-')))
    let engine
    t.after(() => {
        assert.equal(path.dirname(root), fs.realpathSync(os.tmpdir()))
        assert.ok(path.basename(root).startsWith('chur-mac-native-'))
        // A failed unmount must remain intact for diagnosis, never rm a mount.
        if(engine && fs.existsSync(path.join(engine.work, 'mounted'))) return
        fs.rmSync(root, { recursive: true })
    })
    const installed = path.join(root, 'Applications', 'ChurWorld Launcher.app')
    const payload = path.join(root, 'payload', 'ChurWorld Launcher.app')
    async function app(directory, version) {
        fs.mkdirSync(path.join(directory, 'Contents', 'MacOS'), { recursive: true })
        fs.writeFileSync(path.join(directory, 'Contents', 'Info.plist'), `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>CFBundleIdentifier</key><string>helioslauncher</string><key>CFBundleName</key><string>ChurWorld Launcher</string><key>CFBundleExecutable</key><string>ChurWorld Launcher</string><key>CFBundleShortVersionString</key><string>${version}</string><key>CFBundleVersion</key><string>${version}</string><key>CFBundlePackageType</key><string>APPL</string></dict></plist>`)
        fs.copyFileSync('/usr/bin/true', path.join(directory, 'Contents', 'MacOS', 'ChurWorld Launcher'))
        await run('/usr/bin/codesign', ['--force', '--sign', '-', directory])
    }
    await app(installed, '2.2.7')
    await app(payload, '2.2.8')
    const dmg = path.join(root, 'fixture.dmg')
    await run('/usr/bin/hdiutil', ['create', '-srcfolder', path.dirname(payload), '-format', 'UDZO', '-fs', 'HFS+', dmg], { timeout: 60000 })
    const data = fs.readFileSync(dmg)
    const info = {
        version: '2.2.8', arch: process.arch, size: data.length,
        digest: `sha256:${crypto.createHash('sha256').update(data).digest('hex')}`,
        darwindownload: `https://github.com/dlworn5434/churworld-distribution/releases/download/v2.2.8/ChurWorld-Launcher-setup-2.2.8-${process.arch}.dmg`
    }
    engine = new MacAutoUpdater({ appPath: installed, currentVersion: '2.2.7', arch: process.arch,
        logPath: path.join(root, 'update.log'), download: async (_info, dest) => fs.copyFileSync(dmg, dest) })
    await engine.prepare(info, () => {})
    const dead = spawn('/usr/bin/true')
    await new Promise((resolve, reject) => { dead.once('exit', resolve); dead.once('error', reject) })
    const args = [path.join(engine.work, 'install.sh'), String(dead.pid), installed, engine.work, engine.token,
        info.version, '2.2.7', process.arch, engine.identity, '0']
    return { engine, installed, args }
}

test('native macOS: verified DMG is mounted, staged, detached and installed after parent exit', native, async t => {
    const { engine, installed, args } = await fixture(t)
    assert.equal(await engine.plist(installed, 'CFBundleShortVersionString'), '2.2.7')
    await run('/bin/bash', args, { timeout: 15000 })
    assert.equal(await engine.plist(installed, 'CFBundleShortVersionString'), '2.2.8')
    await engine.verifyApp(installed, '2.2.8')
    assert.equal(fs.existsSync(engine.work), false)
})

test('native macOS: a changed installation is never overwritten', native, async t => {
    const { engine, installed, args } = await fixture(t)
    args[args.length - 2] = '0:0'
    await assert.rejects(run('/bin/bash', args, { timeout: 15000 }))
    assert.equal(await engine.plist(installed, 'CFBundleShortVersionString'), '2.2.7')
})

test('native macOS: staged signature tampering cannot replace the installed app', native, async t => {
    const { engine, installed, args } = await fixture(t)
    fs.appendFileSync(path.join(engine.work, 'next.app', 'Contents', 'Info.plist'), '\n<!-- changed after staging -->')
    await assert.rejects(run('/bin/bash', args, { timeout: 15000 }))
    assert.equal(await engine.plist(installed, 'CFBundleShortVersionString'), '2.2.7')
})
