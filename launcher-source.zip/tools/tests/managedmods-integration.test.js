const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const { EventEmitter } = require('node:events')

const root = path.resolve(__dirname, '../..')
const quiet = { info() {}, warn() {}, error() {} }

function distributionHarness({ captureFails = false, dev = false } = {}) {
    const events = []
    const previous = { servers: [{ id: 'life', modules: [] }] }
    class API {
        constructor() { this.commonDir = '/fixture/common'; this.instanceDir = '/fixture/instances' }
        isDevMode() { return dev }
        async pullLocal() { events.push('read-old-cache'); return previous }
        async writeDistributionToDisk(value) { events.push('write-new-cache'); this.value = value }
    }
    class Store {
        constructor(directory, options) {
            this.commonDirectory = directory
            assert.equal(options.history, dependencies['./managed-mod-history.json'])
        }
        async remember(distribution) {
            events.push('record-old-files')
            assert.equal(distribution.raw, previous)
            if(captureFails) throw new Error('cannot write ledger')
        }
        async launch(distribution, serverId, spawn, options) {
            events.push(options.allowCleanup ? 'cleanup-and-launch' : 'launch-without-cleanup')
            return spawn()
        }
    }
    const dependencies = {
        'helios-core/common': { DistributionAPI: API, HeliosDistribution: class { constructor(raw) { this.raw = raw } } },
        'helios-core': { LoggerUtil: { getLogger: () => quiet } },
        './configmanager': { getLauncherDirectory: () => '/fixture/launcher', getCommonDirectory: () => '/fixture/common' },
        './managedmods': { ManagedModStore: Store },
        './managed-mod-history.json': { version: 1, records: [] }
    }
    const context = { exports: {}, require: name => dependencies[name] }
    vm.runInNewContext(fs.readFileSync(path.join(root, 'app/assets/js/distromanager.js'), 'utf8'), context)
    return { events, ...context.exports }
}

test('initial remote preload records old ownership before replacing the cached distribution', async () => {
    const h = distributionHarness()
    const current = { servers: [] }
    await h.DistroAPI.writeDistributionToDisk(current)
    assert.deepEqual(h.events, ['read-old-cache', 'record-old-files', 'write-new-cache'])
    assert.equal(h.DistroAPI.value, current)
})

test('inventory failure does not prevent downloading a new distribution', async () => {
    const h = distributionHarness({ captureFails: true })
    await h.DistroAPI.writeDistributionToDisk({ servers: [] })
    assert.deepEqual(h.events, ['read-old-cache', 'record-old-files', 'write-new-cache'])
})

test('development index is never adopted as production ownership or pruned', async () => {
    const h = distributionHarness({ dev: true })
    await h.DistroAPI.writeDistributionToDisk({ servers: [] })
    await h.launchWithManagedMods({}, 'life', () => 'process')
    assert.deepEqual(h.events, ['write-new-cache', 'launch-without-cleanup'])
})

function landingHarness({ needsDownload = true, corrupt = false, downloadFails = false, verifyFails = false, login = true } = {}) {
    const events = []
    const server = { rawServer: { id: 'life', minecraftVersion: '1.21.4' } }
    const distro = { getServerById: () => server, rawDistribution: {} }
    const child = Object.assign(new EventEmitter(), { stdout: new EventEmitter(), stderr: new EventEmitter() })
    let checks = 0
    class Repair {
        spawnReceiver() { events.push('worker-start') }
        destroyReceiver() { events.push('worker-stop') }
        childProcess = new EventEmitter()
        async verifyFiles() {
            events.push('verify')
            if(verifyFails) throw new Error('verification failed')
            return checks++ === 0 ? (needsDownload ? 1 : 0) : (corrupt ? 1 : 0)
        }
        async download() {
            events.push('download')
            if(downloadFails) throw new Error('network failure')
        }
    }
    class Builder {
        build() { events.push('spawn'); return child }
    }
    const context = {
        DistroAPI: { refreshDistributionOrFallback: async () => distro, isDevMode: () => false },
        ConfigManager: {
            getSelectedServer: () => 'life', getSelectedAccount: () => ({ displayName: 'fixture' }),
            getCommonDirectory: () => '/fixture/common', getInstanceDirectory: () => '/fixture/instances',
            getLauncherDirectory: () => '/fixture/launcher'
        },
        LoggerUtil: { getLogger: () => quiet }, loggerLanding: quiet,
        Lang: { queryJS: value => value },
        onDistroRefresh() {}, setLaunchDetails() {}, toggleLaunchArea() {},
        setLaunchPercentage() {}, setDownloadPercentage() {},
        showLaunchFailure() { events.push('failure') },
        FullRepair: Repair,
        MojangIndexProcessor: class { async getVersionJson() { return {} } },
        DistributionIndexProcessor: class { async loadModLoaderVersionJson() { return {} } },
        ProcessBuilder: Builder,
        beginManagedUpdate: async () => {
            events.push('update-start')
            return { id: 'test-update', finish: () => events.push('update-stop') }
        },
        launchWithManagedMods: async (distribution, id, start, update) => {
            assert.equal(distribution, distro)
            assert.equal(id, 'life')
            assert.equal(update.id, 'test-update')
            events.push('cleanup')
            return start()
        },
        remote: { getCurrentWindow: () => ({ setProgressBar() {} }), app: { getVersion: () => '2.2.6' } },
        GAME_LAUNCH_REGEX: /never/, MIN_LINGER: 0, hasRPC: false, proc: null
    }
    const source = fs.readFileSync(path.join(root, 'app/assets/js/scripts/landing.js'), 'utf8').replace(/\r\n/g, '\n')
    const start = source.indexOf('async function dlAsync(')
    const end = source.indexOf('\n/**\n * News Loading', start)
    assert.ok(start >= 0 && end > start)
    vm.runInNewContext(source.slice(start, end), context)
    return { events, run: () => context.dlAsync(login) }
}

test('actual launch flow rechecks downloaded content before cleanup, then spawns', async () => {
    const h = landingHarness()
    await h.run()
    assert.deepEqual(h.events, ['update-start', 'worker-start', 'verify', 'download', 'verify', 'worker-stop', 'cleanup', 'spawn', 'update-stop'])
})

test('already valid installations are cleaned after verification without a download', async () => {
    const h = landingHarness({ needsDownload: false })
    await h.run()
    assert.deepEqual(h.events, ['update-start', 'worker-start', 'verify', 'worker-stop', 'cleanup', 'spawn', 'update-stop'])
})

for(const [name, options] of [
    ['download fails', { downloadFails: true }],
    ['same-size corrupted download fails hash validation', { corrupt: true }],
    ['initial validation fails', { verifyFails: true }]
]) {
    test(`${name}: no cleanup and no game process`, async () => {
        const h = landingHarness(options)
        await h.run()
        assert.ok(h.events.includes('failure'))
        assert.ok(h.events.includes('worker-stop'))
        assert.equal(h.events.includes('cleanup'), false)
        assert.equal(h.events.includes('spawn'), false)
        assert.equal(h.events.at(-1), 'update-stop')
    })
}

test('validation-only mode does not delete mods or launch a game', async () => {
    const h = landingHarness({ login: false })
    await h.run()
    assert.deepEqual(h.events, ['worker-start', 'verify', 'download', 'verify', 'worker-stop'])
})

function processProbe(platform, output, failure = false) {
    const calls = []
    const source = fs.readFileSync(path.join(root, 'app/assets/js/managedmods.js'), 'utf8')
    const context = {
        module: { exports: {} },
        process: { platform, env: { SystemRoot: 'C:\\Windows' } },
        console,
        require: name => {
            if(name === 'node:path') return platform === 'win32' ? path.win32 : path.posix
            if(name === 'node:child_process') return {
                execFile: (executable, args, options, callback) => {
                    calls.push({ executable, args, options })
                    callback(failure ? new Error('process list unavailable') : null, { stdout: output })
                }
            }
            return require(name)
        }
    }
    vm.runInNewContext(source, context)
    const store = new context.module.exports.ManagedModStore(platform === 'win32' ? 'C:\\fixture' : '/fixture')
    return { calls, run: () => store.isJavaRunning() }
}

test('Windows legacy Java guard uses hidden tasklist with names only', async () => {
    const h = processProbe('win32', '"javaw.exe","123","Console","1","20 K"\r\n')
    assert.equal(await h.run(), true)
    assert.equal(h.calls[0].options.windowsHide, true)
    assert.deepEqual(Array.from(h.calls[0].args), ['/FO', 'CSV', '/NH'])
})

test('macOS/Linux process-name guards recognize both Java executable names and paths', async () => {
    for(const platform of ['darwin', 'linux']) {
        assert.equal(await processProbe(platform, '/Library/Java/Contents/Home/bin/java\n').run(), true)
        assert.equal(await processProbe(platform, 'java\n').run(), true)
        assert.equal(await processProbe(platform, '/Applications/ChurWorld Launcher\nnode\n').run(), false)
    }
})

test('inaccessible process list conservatively postpones all deletion', async () => {
    assert.equal(await processProbe('win32', '', true).run(), true)
    assert.equal(await processProbe('darwin', '', true).run(), true)
})
