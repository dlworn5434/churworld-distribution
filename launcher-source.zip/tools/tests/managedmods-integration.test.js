const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const { EventEmitter } = require('node:events')

const root = path.resolve(__dirname, '../..')
const quiet = { info() {}, warn() {}, error() {} }

function distributionHarness({ captureFails = false, dev = false } = {}) {
    const events = []
    const previous = { servers: [{ id: 'life', modules: [] }] }
    const current = { servers: [{ id: 'life', modules: [] }], version: 'new-signed-fixture' }
    class API {
        constructor() { this.launcherDirectory = '/fixture/launcher'; this.commonDir = '/fixture/common'; this.instanceDir = '/fixture/instances' }
        isDevMode() { return dev }
        async pullLocal() { events.push('read-old-cache'); return previous }
        async writeDistributionToDisk(value) { events.push('write-new-cache'); this.value = value }
    }
    class Store {
        constructor(directory, options) {
            this.commonDirectory = directory
            assert.equal(options.history, dependencies['./managed-mod-history.json'])
        }
        async remember(distribution) {
            events.push('record-old-files')
            assert.equal(JSON.stringify(distribution.raw), JSON.stringify(previous))
            if(captureFails) throw new Error('cannot write ledger')
        }
        async launch(distribution, serverId, spawn, options) {
            events.push(options.allowCleanup ? 'cleanup-and-launch' : 'launch-without-cleanup')
            return spawn()
        }
    }
    const dependencies = {
        'helios-core/common': { DistributionAPI: API, HeliosDistribution: class {
            constructor(raw) { this.raw = raw; this.rawDistribution = raw }
            getServerById() { return { modules: [] } }
        } },
        'helios-core': { LoggerUtil: { getLogger: () => quiet } },
        './configmanager': { getLauncherDirectory: () => '/fixture/launcher', getCommonDirectory: () => '/fixture/common' },
        './managedmods': { ManagedModStore: Store },
        './managed-mod-history.json': { version: 1, records: [] },
        './trusted-cache': { TrustedCache: class {
            read() { events.push('read-old-cache'); return { payload: { distribution: previous }, envelope: {} } }
            async refresh() { events.push('write-new-cache'); return { payload: { distribution: current }, envelope: {} } }
            verify() { return true }
        } },
        './trusted-manifest': require('../../app/assets/js/trusted-manifest'),
        './secure-download': require('../../app/assets/js/secure-download')
    }
    const context = { exports: {}, process, require: name => dependencies[name] || require(name) }
    vm.runInNewContext(fs.readFileSync(path.join(root, 'app/assets/js/distromanager.js'), 'utf8'), context)
    return { events, ...context.exports }
}

test('initial remote preload records old ownership before replacing the cached distribution', async () => {
    const h = distributionHarness()
    const current = await h.DistroAPI.refreshDistributionOrFallback()
    assert.deepEqual(h.events, ['read-old-cache', 'record-old-files', 'write-new-cache'])
    assert.equal(current.rawDistribution.version, 'new-signed-fixture')
    await assert.rejects(h.DistroAPI.writeDistributionToDisk({ servers: [] }), { code: 'TRUST_UNSIGNED_CACHE_DISABLED' })
})

test('inventory failure does not prevent downloading a new distribution', async () => {
    const h = distributionHarness({ captureFails: true })
    await h.DistroAPI.refreshDistributionOrFallback()
    assert.deepEqual(h.events, ['read-old-cache', 'record-old-files', 'write-new-cache'])
})

test('development index is never adopted as production ownership or pruned', async () => {
    const h = distributionHarness({ dev: true })
    const current = await h.DistroAPI.refreshDistributionOrFallback()
    await h.launchWithManagedMods(current, 'life', () => 'process')
    assert.deepEqual(h.events.filter(event => event !== 'read-old-cache'), ['write-new-cache', 'launch-without-cleanup'])
    await assert.rejects(h.launchWithManagedMods({}, 'life', () => 'unapproved'), { code: 'TRUST_DISTRIBUTION_NOT_APPROVED' })
})

function landingHarness({ needsDownload = true, corrupt = false, downloadFails = false, verifyFails = false, login = true } = {}) {
    const events = []
    const server = { rawServer: { id: 'life', minecraftVersion: '1.21.4' } }
    const distro = { getServerById: () => server, rawDistribution: {} }
    const child = Object.assign(new EventEmitter(), { stdout: new EventEmitter(), stderr: new EventEmitter() })
    let checks = 0
    class Repair {
        spawnReceiver() { events.push('worker-start') }
        destroyReceiver() { events.push('worker-stop') }
        childProcess = new EventEmitter()
        async verifyFiles() {
            events.push('verify')
            if(verifyFails) throw new Error('verification failed')
            return checks++ === 0 ? (needsDownload ? 1 : 0) : (corrupt ? 1 : 0)
        }
        async getLaunchMetadata() { return {vanilla:{},mod:{}} }
        async download() {
            events.push('download')
            if(downloadFails) throw new Error('network failure')
        }
    }
    class Builder {
        build() { events.push('spawn'); return child }
    }
    const context = {
        DistroAPI: { refreshDistributionOrFallback: async () => distro, isDevMode: () => false },
        ConfigManager: {
            getSelectedServer: () => 'life', getSelectedAccount: () => ({ uuid: 'fixture-account', displayName: 'fixture' }),
            getAuthRevision: () => 0,
            getCommonDirectory: () => '/fixture/common', getInstanceDirectory: () => '/fixture/instances',
            getLauncherDirectory: () => '/fixture/launcher'
        },
        LoggerUtil: { getLogger: () => quiet }, loggerLanding: quiet,
        AuthManager: { validateSelected: async () => true },
        Lang: { queryJS: value => value },
        onDistroRefresh() {}, setLaunchDetails() {}, toggleLaunchArea() {},
        setLaunchPercentage() {}, setDownloadPercentage() {},
        showLaunchFailure() { events.push('failure') },
        FullRepair: Repair,
        MojangIndexProcessor: class { async getVersionJson() { return {} } },
        DistributionIndexProcessor: class { async loadModLoaderVersionJson() { return {} } },
        ProcessBuilder: Builder,
        beginManagedUpdate: async () => {
            events.push('update-start')
            return { id: 'test-update', finish: () => events.push('update-stop') }
        },
        launchWithManagedMods: async (distribution, id, start, update) => {
            assert.equal(distribution, distro)
            assert.equal(id, 'life')
            assert.equal(update.id, 'test-update')
            events.push('cleanup')
            return start()
        },
        remote: { getCurrentWindow: () => ({ setProgressBar() {} }), app: { getVersion: () => '2.2.6' } },
        GAME_LAUNCH_REGEX: /never/, MIN_LINGER: 0, hasRPC: false, proc: null
    }
    context.ConfigManager.getDataDirectory = () => '/fixture'
    context.ConfigManager.getSelectedDestination = () => 'life'
    context.DistroAPI.prepareServerFiles = async () => {}
    context.DistroAPI.isOfflineOnly = () => false
    if(!login) context.AuthManager.validateSelected = async () => false
    const module={exports:{}}
    const imports = {'helios-core/dl':{},'helios-core/common':{},'helios-core/java':{},'helios-core':{LoggerUtil:{getLogger:()=>quiet}},
        './trusted-repair':{TrustedRepair:Repair},'./configmanager':context.ConfigManager,'./authmanager':context.AuthManager,
        './processbuilder':Builder,'./discordwrapper':{},'./auth-errors':{AuthError:class extends Error{constructor(code){super(code);this.code=code}}},
        './langloader':context.Lang,'./configuration-sync':{syncModConfigurations(){},ensureJavaSettings(){}}}
    vm.runInNewContext(fs.readFileSync(path.join(root,'app/assets/js/game-service.js'),'utf8'),
        {module,exports:module.exports,require:id=>Object.hasOwn(imports,id)?imports[id]:require(id),process,console})
    const game=module.exports.createGameService({distribution:{DistroAPI:context.DistroAPI,beginManagedUpdate:context.beginManagedUpdate,
        launchWithManagedMods:context.launchWithManagedMods},version:'fixture',emit(){},approvedPaths:new Set()})
    return {events,run:async()=>{try{await game.launch()}catch{events.push('failure')}}}

}

test('actual launch flow rechecks downloaded content before cleanup, then spawns', async () => {
    const h = landingHarness()
    await h.run()
    assert.deepEqual(h.events, ['update-start', 'worker-start', 'verify', 'download', 'verify', 'worker-stop', 'cleanup', 'spawn', 'update-stop'])
})

test('already valid installations are cleaned after verification without a download', async () => {
    const h = landingHarness({ needsDownload: false })
    await h.run()
    assert.deepEqual(h.events, ['update-start', 'worker-start', 'verify', 'worker-stop', 'cleanup', 'spawn', 'update-stop'])
})

for(const [name, options] of [
    ['download fails', { downloadFails: true }],
    ['same-size corrupted download fails hash validation', { corrupt: true }],
    ['initial validation fails', { verifyFails: true }]
]) {
    test(`${name}: no cleanup and no game process`, async () => {
        const h = landingHarness(options)
        await h.run()
        assert.ok(h.events.includes('failure'))
        assert.ok(h.events.includes('worker-stop'))
        assert.equal(h.events.includes('cleanup'), false)
        assert.equal(h.events.includes('spawn'), false)
        assert.equal(h.events.at(-2), 'update-stop')
    })
}

test('missing authentication never starts repair, deletes mods or launches a game', async () => {
    const h = landingHarness({ login: false })
    await h.run()
    assert.deepEqual(h.events, ['failure'])
})

function processProbe(platform, output, failure = false) {
    const calls = []
    const source = fs.readFileSync(path.join(root, 'app/assets/js/managedmods.js'), 'utf8')
    const context = {
        module: { exports: {} },
        process: { platform, env: { SystemRoot: 'C:\\Windows' } },
        console,
        require: name => {
            if(name === 'node:path') return platform === 'win32' ? path.win32 : path.posix
            if(name === 'node:child_process') return {
                execFile: (executable, args, options, callback) => {
                    calls.push({ executable, args, options })
                    callback(failure ? new Error('process list unavailable') : null, { stdout: output })
                }
            }
            return require(name)
        }
    }
    vm.runInNewContext(source, context)
    const store = new context.module.exports.ManagedModStore(platform === 'win32' ? 'C:\\fixture' : '/fixture')
    return { calls, run: () => store.isJavaRunning() }
}

test('Windows legacy Java guard uses hidden tasklist with names only', async () => {
    const h = processProbe('win32', '"javaw.exe","123","Console","1","20 K"\r\n')
    assert.equal(await h.run(), true)
    assert.equal(h.calls[0].options.windowsHide, true)
    assert.deepEqual(Array.from(h.calls[0].args), ['/FO', 'CSV', '/NH'])
})

test('macOS/Linux process-name guards recognize both Java executable names and paths', async () => {
    for(const platform of ['darwin', 'linux']) {
        assert.equal(await processProbe(platform, '/Library/Java/Contents/Home/bin/java\n').run(), true)
        assert.equal(await processProbe(platform, 'java\n').run(), true)
        assert.equal(await processProbe(platform, '/Applications/ChurWorld Launcher\nnode\n').run(), false)
    }
})

test('inaccessible process list conservatively postpones all deletion', async () => {
    assert.equal(await processProbe('win32', '', true).run(), true)
    assert.equal(await processProbe('darwin', '', true).run(), true)
})
