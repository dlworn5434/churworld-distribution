const assert = require('node:assert/strict')
const test = require('node:test')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')

function loadUpdater(platform, checkMacUpdate){
    const sent = []
    const handlers = new Map()
    const updater = {
        allowPrerelease: false,
        checks: 0,
        installs: 0,
        on(){},
        async checkForUpdates(){ this.checks++; return 'windows-update' },
        quitAndInstall(){ this.installs++ }
    }
    const dependencies = {
        '@electron/remote/main': { initialize(){} },
        electron: {
            app: { getVersion: () => '2.2.6' },
            ipcMain: { on: (name, handler) => handlers.set(name, handler) }
        },
        'electron-updater': { autoUpdater: updater },
        'ejs-electron': {},
        './app/assets/js/isdev': false,
        './app/assets/js/ipcconstants': {},
        './app/assets/js/langloader': { setupLanguage(){} },
        './app/assets/js/macupdates': { checkMacUpdate }
    }
    const context = {
        require: name => Object.hasOwn(dependencies, name) ? dependencies[name] : require(name),
        process: { platform, arch: 'arm64' },
        console,
        __dirname: path.resolve(__dirname, '../..')
    }
    const source = fs.readFileSync(path.join(context.__dirname, 'index.js'), 'utf8')
    vm.runInNewContext(source.split('// Redirect distribution index event')[0], context)
    const event = { sender: { isDestroyed: () => false, send: (...args) => sent.push(args) } }
    return { context, updater, sent, event, dispatch: arg => handlers.get('autoUpdateAction')(event, arg) }
}

test('macOS uses DMG checker once during concurrent checks and never auto-installs', async () => {
    let complete
    let checks = 0
    const mac = loadUpdater('darwin', () => {
        checks++
        return new Promise(resolve => { complete = resolve })
    })
    const pending = mac.context.checkLauncherUpdates(mac.event)
    await mac.context.checkLauncherUpdates(mac.event)
    assert.equal(checks, 1)
    const info = { version: '2.2.7', darwindownload: 'https://github.com/example.dmg' }
    complete(info)
    await pending
    assert.equal(mac.updater.checks, 0)
    assert.deepEqual(mac.sent.map(message => message[1]), ['checking-for-update', 'update-available'])
    assert.equal(mac.sent[1][2], info)
    mac.dispatch('installUpdateNow')
    assert.equal(mac.updater.installs, 0)
})

test('macOS check failure is reported through IPC and permits a later retry', async () => {
    let fail = true
    const mac = loadUpdater('darwin', async () => {
        if(fail){
            throw Object.assign(new Error('No network'), { code: 'ENETUNREACH' })
        }
        return null
    })
    mac.dispatch('checkForUpdate')
    await new Promise(setImmediate)
    assert.equal(mac.sent.at(-1)[1], 'realerror')
    assert.equal(mac.sent.at(-1)[2].code, 'ENETUNREACH')
    fail = false
    mac.dispatch('checkForUpdate')
    await new Promise(setImmediate)
    assert.equal(mac.sent.at(-1)[1], 'update-not-available')
    assert.equal(mac.updater.checks, 0)
})

test('Windows retains electron-updater checking and installation', async () => {
    const windows = loadUpdater('win32', () => { throw new Error('Mac checker called on Windows') })
    assert.equal(await windows.context.checkLauncherUpdates(windows.event), 'windows-update')
    assert.equal(windows.updater.checks, 1)
    windows.dispatch('installUpdateNow')
    assert.equal(windows.updater.installs, 1)
})
