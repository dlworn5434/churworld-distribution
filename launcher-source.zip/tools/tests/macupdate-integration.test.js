const assert = require('node:assert/strict')
const test = require('node:test')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')

function loadUpdater(platform, checkMacUpdate){
    const sent = []
    const handlers = new Map()
    const updater = {
        allowPrerelease: false,
        checks: 0,
        installs: 0,
        on(){},
        async checkForUpdates(){ this.checks++; return 'windows-update' },
        quitAndInstall(...args){ this.installs++; this.installArguments = args }
    }
    const lifecycle = new Map()
    const macEngine = {
        ready: null, preparations: 0, installs: [],
        async prepare(info, notify) {
            this.preparations++
            notify('update-available', { ...info, automatic: true })
            this.ready = { ...info, automatic: true }
            notify('update-downloaded', this.ready)
        },
        async install(relaunch) { this.installs.push(relaunch); return Boolean(this.ready) }
    }
    const application = { getVersion: () => '2.2.7', getPath: () => '/fixture/user-data', quitCalls: 0,
        on: (name, handler) => lifecycle.set(name, handler), quit() { this.quitCalls++ } }
    const dependencies = {
        '@electron/remote/main': { initialize(){} },
        electron: {
            app: application,
            ipcMain: { on: (name, handler) => handlers.set(name, handler) }
        },
        'electron-updater': { autoUpdater: updater },
        'ejs-electron': {},
        './app/assets/js/isdev': false,
        './app/assets/js/ipcconstants': {},
        './app/assets/js/langloader': { setupLanguage(){} },
        './app/assets/js/macupdates': { checkMacUpdate },
        './app/assets/js/macautoupdater': { MacAutoUpdater: function() { return macEngine } }
    }
    const context = {
        require: name => Object.hasOwn(dependencies, name) ? dependencies[name] : require(name),
        process: { platform, arch: 'arm64', execPath: '/Applications/ChurWorld Launcher.app/Contents/MacOS/ChurWorld Launcher' },
        console,
        __dirname: path.resolve(__dirname, '../..')
    }
    const source = fs.readFileSync(path.join(context.__dirname, 'index.js'), 'utf8')
    vm.runInNewContext(source.split('// Redirect distribution index event')[0], context)
    const event = { sender: { isDestroyed: () => false, send: (...args) => sent.push(args) } }
    return { context, updater, sent, event, macEngine, application, lifecycle, dispatch: arg => handlers.get('autoUpdateAction')(event, arg) }
}

test('macOS automatically prepares verified DMG once and offers restart installation', async () => {
    let complete
    let checks = 0
    const mac = loadUpdater('darwin', () => {
        checks++
        return new Promise(resolve => { complete = resolve })
    })
    const pending = mac.context.checkLauncherUpdates(mac.event)
    await mac.context.checkLauncherUpdates(mac.event)
    assert.equal(checks, 1)
    const info = { version: '2.2.8', digest: `sha256:${'a'.repeat(64)}`, darwindownload: 'https://github.com/example.dmg' }
    complete(info)
    await pending
    assert.equal(mac.updater.checks, 0)
    assert.deepEqual(mac.sent.map(message => message[1]), ['checking-for-update', 'update-available', 'update-downloaded'])
    assert.equal(mac.macEngine.preparations, 1)
    await mac.context.checkLauncherUpdates(mac.event)
    assert.equal(checks, 1)
    mac.dispatch('installUpdateNow')
    await new Promise(setImmediate)
    assert.equal(mac.updater.installs, 0)
    assert.deepEqual(mac.macEngine.installs, [true])
    assert.equal(mac.application.quitCalls, 1)
})

test('macOS check failure is reported through IPC and permits a later retry', async () => {
    let fail = true
    const mac = loadUpdater('darwin', async () => {
        if(fail){
            throw Object.assign(new Error('No network'), { code: 'ENETUNREACH' })
        }
        return null
    })
    mac.dispatch('checkForUpdate')
    await new Promise(setImmediate)
    assert.equal(mac.sent.at(-1)[1], 'realerror')
    assert.equal(mac.sent.at(-1)[2].code, 'ENETUNREACH')
    fail = false
    mac.dispatch('checkForUpdate')
    await new Promise(setImmediate)
    assert.equal(mac.sent.at(-1)[1], 'update-not-available')
    assert.equal(mac.updater.checks, 0)
})

test('Windows retains electron-updater checking and installation', async () => {
    const windows = loadUpdater('win32', () => { throw new Error('Mac checker called on Windows') })
    assert.equal(await windows.context.checkLauncherUpdates(windows.event), 'windows-update')
    assert.equal(windows.updater.checks, 1)
    windows.dispatch('installUpdateNow')
    assert.equal(windows.updater.installs, 1)
    assert.deepEqual(windows.updater.installArguments, [true, true])
    windows.dispatch('initAutoUpdater')
    assert.equal(windows.updater.autoDownload, true)
    assert.equal(windows.updater.autoInstallOnAppQuit, true)
})

test('macOS installs a ready update on normal quit without reopening the app', async () => {
    const mac = loadUpdater('darwin', async () => ({ version: '2.2.8', digest: `sha256:${'a'.repeat(64)}` }))
    await mac.context.checkLauncherUpdates(mac.event)
    let prevented = 0
    mac.lifecycle.get('before-quit')({ preventDefault() { prevented++ } })
    await new Promise(setImmediate)
    assert.equal(prevented, 1)
    assert.deepEqual(mac.macEngine.installs, [false])
    assert.equal(mac.application.quitCalls, 1)
    mac.lifecycle.get('before-quit')({ preventDefault() { prevented++ } })
    assert.equal(prevented, 1)
})

test('macOS legacy assets without a GitHub digest remain manual and never download automatically', async () => {
    const mac = loadUpdater('darwin', async () => ({ version: '2.2.8', darwindownload: 'https://github.com/example.dmg' }))
    await mac.context.checkLauncherUpdates(mac.event)
    assert.equal(mac.macEngine.preparations, 0)
    assert.equal(mac.sent.at(-1)[1], 'update-available')
    mac.dispatch('installUpdateNow')
    await new Promise(setImmediate)
    assert.equal(mac.application.quitCalls, 0)
})

test('failed macOS installer preparation reports an error and does not trap the user on quit', async () => {
    const mac = loadUpdater('darwin', async () => ({ version: '2.2.8', digest: `sha256:${'a'.repeat(64)}` }))
    await mac.context.checkLauncherUpdates(mac.event)
    mac.macEngine.install = async () => { throw new Error('cannot spawn helper') }
    mac.lifecycle.get('before-quit')({ preventDefault() {} })
    await new Promise(setImmediate)
    assert.equal(mac.sent.at(-1)[1], 'realerror')
    assert.equal(mac.application.quitCalls, 1)
})
