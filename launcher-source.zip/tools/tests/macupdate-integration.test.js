const assert = require('node:assert/strict'), test = require('node:test'), fs = require('node:fs'), path = require('node:path'), vm = require('node:vm')
const {EventEmitter} = require('node:events')
// Actual main entry, with synthetic windows, crypto/storage stubs and no network/install execution.
function loadUpdater(platform, options={}) {
    const sent=[], lifecycle=new Map(), windows=[], installs=[], codes=[]
    const info={version:'2.2.11',artifact:{name:'ChurWorld-setup-2.2.11.exe',size:42},releaseName:'fixture',releaseNotes:'fixture'}
    const state={checks:0,downloads:0,verifies:0,invalid:false}
    const application={getVersion:()=> '2.2.10',getPath:()=>'/fixture/user-data',requestSingleInstanceLock:()=>true,
        on:(name,handler)=>lifecycle.set(name,handler),disableHardwareAcceleration(){},quitCalls:0,quit(){this.quitCalls++}}
    const macEngine={ready:null,preparations:0,installs:[],async verifyReady(){if(state.invalid)throw {code:'TRUST_MANIFEST_EXPIRED'};return true},
        async invalidateReady(){this.ready=null},async prepare(value,notify){assert.equal(value,info);this.preparations++;notify('update-available',value);this.ready=value;notify('update-downloaded',value)},
        async install(relaunch){await this.verifyReady();this.installs.push(relaunch);return Boolean(this.ready)}}
    class Window extends EventEmitter {constructor(config){super();this.config=config;this.webContents=new EventEmitter();this.webContents.setWindowOpenHandler=fn=>this.openHandler=fn;windows.push(this)}
        isDestroyed(){return this.closed||false}close(){if(this.closed)return;this.closed=true;this.emit('closed')}removeMenu(){}async loadURL(value){this.url=value}}
    const dependencies={electron:{app:application,BrowserWindow:Window,ipcMain:{on(){assert.fail('Legacy raw IPC must not be registered at module load')},handle(){}},dialog:{}},
        fs:{mkdirSync(){}},'node:child_process':{spawn(file,args,opts){installs.push({file,args,opts});const child=new EventEmitter();child.unref=()=>{};queueMicrotask(()=>child.emit('spawn'));return child}},
        'ejs-electron':{},'./app/assets/js/isdev':false,'./app/assets/js/ipcconstants':{AZURE_CLIENT_ID:'synthetic-public-id'},
        './app/assets/js/langloader':{setupLanguage(){},queryJS:x=>x},
        './app/assets/js/macupdates':{checkMacUpdate:async()=>{state.checks++;if(options.check)return options.check(info);return info}},
        './app/assets/js/macautoupdater':{MacAutoUpdater:function(){return macEngine}},
        './app/assets/js/trusted-updates':{getTrustedUpdate:async()=>{state.checks++;if(options.check)return options.check(info);return info},
            downloadTrustedUpdate:async(value)=>{assert.equal(value,info);state.downloads++},
            verifyTrustedUpdate:async(value)=>{assert.equal(value,info);state.verifies++;if(state.invalid)throw {code:'TRUST_FILE_HASH'}}},
        './app/assets/js/renderer-policy':require('../../app/assets/js/renderer-policy'),
        './app/assets/js/authmanager':{addMicrosoftAccount:async code=>codes.push(code)},
        './app/assets/js/protectedconfig':{ProtectedConfigStore:function(){assert.fail('No account storage permitted')}},
        './app/assets/js/credentialcrypto':{prepareCredentialCrypto:()=>assert.fail('No OS credentials permitted')},
        './app/assets/js/configdefaults':()=>assert.fail('No real profile permitted')}
    const context=vm.createContext({process:{platform,argv:[],arch:'arm64',execPath:'/Applications/Fixture.app/Contents/MacOS/Fixture'},console,
        __dirname:path.resolve(__dirname,'../..'),URL,setTimeout,clearTimeout,setImmediate,queueMicrotask})
    context.require=name=>Object.hasOwn(dependencies,name)?dependencies[name]:require(name)
    vm.runInContext(fs.readFileSync(path.join(context.__dirname,'launcher-main.js'),'utf8'),context)
    context.testWindow={isDestroyed:()=>false,webContents:{send:(...args)=>sent.push(args)}}
    vm.runInContext('win = testWindow',context)
    return {context,sent,macEngine,application,lifecycle,state,info,installs,windows,codes}
}
test('macOS only prepares approved signed update, deduplicates and rechecks ready file',async()=>{
    let resolve;const h=loadUpdater('darwin',{check:()=>new Promise(r=>resolve=r)})
    const first=h.context.checkLauncherUpdates();await h.context.checkLauncherUpdates();assert.equal(h.state.checks,1)
    resolve(h.info);await first;assert.equal(h.macEngine.preparations,1)
    await h.context.checkLauncherUpdates();assert.equal(h.state.checks,1)
    assert.deepEqual(h.sent.slice(0,3).map(x=>x[1].type),['checking-for-update','update-available','update-downloaded'])
    await h.context.installLauncherUpdate();assert.deepEqual(h.macEngine.installs,[true]);assert.equal(h.application.quitCalls,1)
})
test('metadata failure reports a safe code and a later check retries',async()=>{
    let fail=true;const h=loadUpdater('darwin',{check:()=>{if(fail)throw {code:'TRUST_SIGNATURE_INVALID',message:'PRIVATE_BODY'};return null}})
    await h.context.checkLauncherUpdates();assert.equal(h.sent.at(-1)[1].type,'realerror');assert.equal(h.sent.at(-1)[1].info.code,'TRUST_SIGNATURE_INVALID')
    assert.equal(JSON.stringify(h.sent).includes('PRIVATE_BODY'),false);assert.equal(h.macEngine.preparations,0)
    fail=false;await h.context.checkLauncherUpdates();assert.equal(h.sent.at(-1)[1].type,'update-not-available')
})
test('Windows downloads signed approved identity and verifies immediately before hidden NSIS spawn',async()=>{
    const h=loadUpdater('win32');await h.context.checkLauncherUpdates();assert.equal(h.state.downloads,1);assert.equal(h.state.verifies,1)
    await h.context.installLauncherUpdate();assert.equal(h.state.verifies,2);assert.equal(h.installs.length,1)
    assert.equal(h.installs[0].opts.shell,false);assert.equal(h.installs[0].opts.windowsHide,true);assert.equal(h.installs[0].opts.detached,true)
    assert.deepEqual(Array.from(h.installs[0].args),['/S','--updated','--force-run']);assert.equal(h.application.quitCalls,1)
})
for(const platform of ['win32','darwin'])test(platform+' rejected ready candidate is invalidated so later update can retry',async()=>{
    const h=loadUpdater(platform);await h.context.checkLauncherUpdates();h.state.invalid=true;await assert.rejects(h.context.installLauncherUpdate())
    assert.equal(h.installs.length,0);assert.equal(h.application.quitCalls,0)
    h.state.invalid=false;await h.context.checkLauncherUpdates();assert.equal(h.state.checks,2)
    assert.equal(platform==='darwin'?h.macEngine.preparations:h.state.downloads,2)
})
for(const platform of ['win32','darwin'])test(platform+' normal quit installs ready update without reopening',async()=>{
    const h=loadUpdater(platform);await h.context.checkLauncherUpdates();let prevented=0
    h.lifecycle.get('before-quit')({preventDefault(){prevented++}});await new Promise(setImmediate)
    assert.equal(prevented,1);assert.equal(h.application.quitCalls,1)
    if(platform==='darwin')assert.deepEqual(h.macEngine.installs,[false]);else assert.deepEqual(Array.from(h.installs[0].args),['/S','--updated'])
})
test('OAuth uses isolated window and state; code exchange stays in main and result is boolean',async()=>{
    const h=loadUpdater('win32'), pending=h.context.openOAuth(), child=h.windows[0], state=new URL(child.url).searchParams.get('state')
    assert.equal(state.length,64);assert.equal(child.config.webPreferences.nodeIntegration,false);assert.equal(child.config.webPreferences.contextIsolation,true);assert.equal(child.config.webPreferences.sandbox,true)
    child.webContents.emit('will-redirect',{preventDefault(){}},'https://login.microsoftonline.com/common/oauth2/nativeclient?state='+state+'&code=FAKE_TEST_CODE')
    assert.equal(await pending,true);assert.deepEqual(h.codes,['FAKE_TEST_CODE']);assert.equal(JSON.stringify(h.sent).includes('FAKE_TEST_CODE'),false)
})
test('wrong OAuth state and cancelled window never exchange code',async()=>{
    const h=loadUpdater('win32');const first=h.context.openOAuth();h.windows[0].webContents.emit('did-navigate',{preventDefault(){}},'https://login.microsoftonline.com/common/oauth2/nativeclient?state=wrong&code=FAKE_TEST_CODE')
    await assert.rejects(first,e=>e.code==='AUTH_STATE_CHANGED');assert.deepEqual(h.codes,[])
    const second=h.context.openOAuth();h.windows[1].close();await assert.rejects(second,e=>e.code==='AUTH_STATE_CHANGED');assert.deepEqual(h.codes,[])
})
