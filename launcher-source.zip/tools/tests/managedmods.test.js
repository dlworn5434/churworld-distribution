const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const crypto = require('node:crypto')
const { EventEmitter } = require('node:events')
const { ManagedModStore } = require('../../app/assets/js/managedmods')

function fixture(t, options = {}) {
    const temp = fs.realpathSync(os.tmpdir())
    const root = fs.mkdtempSync(path.join(temp, 'churworld-managedmods-test-'))
    t.after(() => {
        const resolved = path.resolve(root)
        assert.equal(path.dirname(resolved), temp)
        assert.match(path.basename(resolved), /^churworld-managedmods-test-/)
        fs.rmSync(resolved, { recursive: true, force: true })
    })
    const common = path.join(root, 'common')
    const active = new Set()
    const messages = []
    const store = new ManagedModStore(common, {
        isProcessAlive: pid => pid === process.pid || active.has(pid),
        isJavaRunning: async () => false,
        logger: { info: message => messages.push(message), warn: message => messages.push(message) },
        ...options
    })
    function mod(name, contents = name, { write = true, type = 'FabricMod', nested = [] } = {}) {
        const file = path.join(common, 'mods', 'fabric', name)
        if(write) {
            fs.mkdirSync(path.dirname(file), { recursive: true })
            fs.writeFileSync(file, contents)
        }
        return {
            rawModule: { type, artifact: { MD5: crypto.createHash('md5').update(contents).digest('hex'), size: Buffer.byteLength(contents) } },
            getPath: () => file,
            subModules: nested
        }
    }
    function distro(modules, others = []) {
        return { servers: [{ rawServer: { id: 'life' }, modules }, ...others] }
    }
    function spawn(pid = 34567) {
        active.add(pid)
        return Object.assign(new EventEmitter(), { pid })
    }
    function close(child) {
        active.delete(child.pid)
        child.emit('close', 0)
    }
    async function clean(distribution, serverId = 'life') {
        const child = await store.launch(distribution, serverId, spawn)
        close(child)
    }
    return { root, common, store, active, messages, mod, distro, spawn, close, clean }
}

test('verified previous JAR is removed after a new version is verified; unrelated files survive', async t => {
    const f = fixture(t)
    const old = f.mod('hud-1.2.2.jar')
    const personal = f.mod('personal.jar')
    const unknown = f.mod('hud-0.9.jar')
    const settings = path.join(f.root, 'instances', 'life', 'options.txt')
    fs.mkdirSync(path.dirname(settings), { recursive: true })
    fs.writeFileSync(settings, 'personal settings')
    await f.store.remember(f.distro([old]))
    const latest = f.mod('hud-1.2.6.jar')
    await f.clean(f.distro([latest]))
    assert.equal(fs.existsSync(old.getPath()), false)
    for(const module of [personal, unknown, latest]) assert.equal(fs.existsSync(module.getPath()), true)
    assert.equal(fs.readFileSync(settings, 'utf8'), 'personal settings')
    assert.ok(f.messages.some(message => message.includes('1 files')))
})

test('managed ownership persists across launcher restarts and several updates', async t => {
    const f = fixture(t)
    const first = f.mod('first.jar')
    await f.clean(f.distro([first]))
    const restarted = new ManagedModStore(f.common, { isProcessAlive: () => false, isJavaRunning: async () => false, logger: { info() {}, warn() {} } })
    const second = f.mod('second.jar')
    let child = await restarted.launch(f.distro([second]), 'life', f.spawn)
    f.close(child)
    assert.equal(fs.existsSync(first.getPath()), false)
    const third = f.mod('third.jar')
    child = await restarted.launch(f.distro([third]), 'life', f.spawn)
    f.close(child)
    assert.equal(fs.existsSync(second.getPath()), false)
    assert.equal(fs.existsSync(third.getPath()), true)
})

test('missing or same-sized corrupt new mod prevents deletion of every old mod', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const missing = f.mod('new.jar', 'right', { write: false })
    await f.clean(f.distro([missing]))
    assert.equal(fs.existsSync(old.getPath()), true)
    fs.writeFileSync(missing.getPath(), 'wrong')
    await f.clean(f.distro([missing]))
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('user-modified previously managed file is preserved', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar', 'first')
    await f.store.remember(f.distro([old]))
    fs.writeFileSync(old.getPath(), 'other')
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.readFileSync(old.getPath(), 'utf8'), 'other')
})

test('same filename replacement stays intact', async t => {
    const f = fixture(t)
    const old = f.mod('hud.jar', 'first')
    await f.store.remember(f.distro([old]))
    const latest = f.mod('hud.jar', 'second')
    await f.clean(f.distro([latest]))
    assert.equal(fs.readFileSync(latest.getPath(), 'utf8'), 'second')
})

test('all remote servers, including nested optional modules, protect old JARs', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const parent = f.mod('parent.jar', 'parent', { type: 'Library', nested: [old] })
    old.rawModule.required = { value: false, def: false }
    const other = { rawServer: { id: 'tower' }, modules: [parent] }
    await f.clean(f.distro([f.mod('new.jar')], [other]))
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('another server retains its last installed version until it is updated too', async t => {
    const f = fixture(t)
    const old = f.mod('shared-old.jar')
    await f.store.remember(f.distro([old], [{ rawServer: { id: 'tower' }, modules: [old] }]))
    const latest = f.mod('shared-new.jar')
    const current = f.distro([latest], [{ rawServer: { id: 'tower' }, modules: [latest] }])
    await f.clean(current)
    assert.equal(fs.existsSync(old.getPath()), true)
    await f.clean(current, 'tower')
    assert.equal(fs.existsSync(old.getPath()), false)
})

test('pending installed versions are not discarded during repeated index refreshes', async t => {
    const f = fixture(t)
    const old = f.mod('tower-old.jar')
    await f.store.remember(f.distro([], [{ rawServer: { id: 'tower' }, modules: [old] }]))
    const newer = f.mod('tower-new.jar', 'new', { write: false })
    const current = f.distro([f.mod('life.jar')], [{ rawServer: { id: 'tower' }, modules: [newer] }])
    await f.store.remember(current)
    await f.clean(current)
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('removed mod is cleaned while no unknown files are adopted by name', async t => {
    const f = fixture(t)
    const old = f.mod('removed.jar')
    const unknown = f.mod('removed-older.jar')
    await f.store.remember(f.distro([old]))
    await f.clean(f.distro([]))
    assert.equal(fs.existsSync(old.getPath()), false)
    assert.equal(fs.existsSync(unknown.getPath()), true)
})

test('invalid/empty distribution or missing selected server never deletes old mods', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    for(const invalid of [{ servers: [] }, { servers: [{ rawServer: { id: 'life' } }] }, { servers: [{ rawServer: { id: 'other' }, modules: [] }] }]) {
        await f.clean(invalid)
        assert.equal(fs.existsSync(old.getPath()), true)
    }
})

test('conflicting shared definitions fail closed', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const a = f.mod('shared.jar', 'first')
    const b = f.mod('shared.jar', 'other', { write: false })
    await f.clean(f.distro([a], [{ rawServer: { id: 'tower' }, modules: [b] }]))
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('corrupt state is preserved and no old mod is deleted', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    fs.writeFileSync(f.store.statePath, '{corrupt')
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.existsSync(old.getPath()), true)
    assert.equal(fs.readFileSync(f.store.statePath, 'utf8'), '{corrupt')
})

test('state traversal and absolute paths cannot remove files outside the managed root', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const external = path.join(f.root, 'valuable.jar')
    fs.writeFileSync(external, 'valuable')
    const original = JSON.parse(fs.readFileSync(f.store.statePath, 'utf8'))
    for(const unsafe of ['../valuable.jar', external, 'mods/fabric/../../../valuable.jar', 'mods/fabric/x.jar:stream']) {
        const state = structuredClone(original)
        state.records[0].path = unsafe
        fs.writeFileSync(f.store.statePath, JSON.stringify(state))
        await f.clean(f.distro([f.mod('new.jar')]))
        assert.equal(fs.readFileSync(external, 'utf8'), 'valuable')
        assert.equal(fs.existsSync(old.getPath()), true)
    }
})

test('hard-linked old files are preserved', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const other = path.join(f.root, 'linked.jar')
    fs.linkSync(old.getPath(), other)
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.existsSync(old.getPath()), true)
    assert.equal(fs.existsSync(other), true)
})

test('junction/symlink ancestor replacement is never followed for deletion', async t => {
    const f = fixture(t)
    const old = f.mod('nested/old.jar')
    await f.store.remember(f.distro([old]))
    const externalDir = path.join(f.root, 'external')
    fs.renameSync(path.dirname(old.getPath()), externalDir)
    fs.symlinkSync(externalDir, path.dirname(old.getPath()), process.platform === 'win32' ? 'junction' : 'dir')
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.readFileSync(path.join(externalDir, 'old.jar'), 'utf8'), 'nested/old.jar')
})

test('a new launcher sees the durable lease of a still-running game', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    const child = await f.store.launch(f.distro([old]), 'life', f.spawn)
    const newStore = new ManagedModStore(f.common, { isProcessAlive: pid => f.active.has(pid), isJavaRunning: async () => false, logger: { info() {}, warn() {} } })
    const newer = f.mod('new.jar')
    const next = await newStore.launch(f.distro([newer]), 'life', () => f.spawn(45678))
    assert.equal(fs.existsSync(old.getPath()), true)
    f.close(child)
    f.close(next)
    await f.clean(f.distro([newer]))
    assert.equal(fs.existsSync(old.getPath()), false)
})

test('legacy/untracked Java processes defer cleanup until a later launch', async t => {
    let running = true
    const f = fixture(t, { isJavaRunning: async () => running })
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const latest = f.mod('new.jar')
    await f.clean(f.distro([latest]))
    assert.equal(fs.existsSync(old.getPath()), true)
    running = false
    await f.clean(f.distro([latest]))
    assert.equal(fs.existsSync(old.getPath()), false)
})

test('unknown interrupted spawn lease keeps every old file', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    fs.writeFileSync(path.join(f.store.directory, 'game-deadbeef.json'), JSON.stringify({ status: 'pending' }))
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('dead game PID is pruned and does not prevent cleanup', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const lease = path.join(f.store.directory, 'game-deadbeef.json')
    fs.writeFileSync(lease, JSON.stringify({ status: 'running', pid: 54321 }))
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.existsSync(old.getPath()), false)
    assert.equal(fs.existsSync(lease), false)
})

test('spawn is protected by a pending lease and lock before Java starts', async t => {
    const f = fixture(t)
    const current = f.distro([f.mod('current.jar')])
    const child = await f.store.launch(current, 'life', () => {
        assert.ok(fs.existsSync(path.join(f.store.directory, 'maintenance.lock')))
        const leases = fs.readdirSync(f.store.directory).filter(name => name.startsWith('game-'))
        assert.equal(leases.length, 1)
        assert.equal(JSON.parse(fs.readFileSync(path.join(f.store.directory, leases[0]), 'utf8')).status, 'pending')
        return f.spawn()
    })
    assert.equal(fs.existsSync(path.join(f.store.directory, 'maintenance.lock')), false)
    f.close(child)
    assert.equal(fs.readdirSync(f.store.directory).filter(name => name.startsWith('game-')).length, 0)
})

test('synchronous and asynchronous spawn failures release their lease', async t => {
    const f = fixture(t)
    const current = f.distro([f.mod('current.jar')])
    await assert.rejects(f.store.launch(current, 'life', () => { throw new Error('spawn failed') }))
    assert.equal(fs.readdirSync(f.store.directory).filter(name => name.startsWith('game-')).length, 0)
    const child = await f.store.launch(current, 'life', () => new EventEmitter())
    child.emit('error', new Error('spawn failed'))
    assert.equal(fs.readdirSync(f.store.directory).filter(name => name.startsWith('game-')).length, 0)
})

test('another live launcher lock prevents cleanup or spawn', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    f.active.add(54321)
    fs.writeFileSync(path.join(f.store.directory, 'maintenance.lock'), JSON.stringify({ pid: 54321, token: 'other' }))
    let started = false
    await assert.rejects(f.store.launch(f.distro([]), 'life', () => { started = true }), /busy/)
    assert.equal(started, false)
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('dead launcher lock can be recovered without deleting current mods', async t => {
    const f = fixture(t)
    const current = f.mod('current.jar')
    await f.store.remember(f.distro([current]))
    fs.writeFileSync(path.join(f.store.directory, 'maintenance.lock'), JSON.stringify({ pid: 54321, token: 'dead' }))
    await f.clean(f.distro([current]))
    assert.equal(fs.existsSync(current.getPath()), true)
})

test('development launches record sessions but do not prune production mods', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const child = await f.store.launch(f.distro([]), 'life', f.spawn, { allowCleanup: false })
    assert.equal(fs.existsSync(old.getPath()), true)
    assert.ok(fs.readdirSync(f.store.directory).some(name => name.startsWith('game-')))
    f.close(child)
})

test('failed inventory persistence stops deletion before any file is removed', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const original = f.store.writeJSON.bind(f.store)
    t.mock.method(f.store, 'writeJSON', (file, value) => {
        if(file === f.store.statePath) throw new Error('disk full')
        return original(file, value)
    })
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('locked old file is retained and retried on a later successful launch', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const original = fs.unlinkSync
    const mock = t.mock.method(fs, 'unlinkSync', file => {
        if(file === old.getPath()) throw Object.assign(new Error('busy'), { code: 'EBUSY' })
        return original(file)
    })
    const current = f.distro([f.mod('new.jar')])
    await f.clean(current)
    assert.equal(fs.existsSync(old.getPath()), true)
    mock.mock.restore()
    await f.clean(current)
    assert.equal(fs.existsSync(old.getPath()), false)
})

test('file changed after hashing is preserved by the final identity check', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar', 'first')
    await f.store.remember(f.distro([old]))
    const original = f.store.regularFile.bind(f.store)
    let checks = 0
    t.mock.method(f.store, 'regularFile', relative => {
        if(relative.endsWith('/old.jar') && ++checks === 3) fs.writeFileSync(old.getPath(), 'changed')
        return original(relative)
    })
    await f.clean(f.distro([f.mod('new.jar')]))
    assert.equal(fs.readFileSync(old.getPath(), 'utf8'), 'changed')
})

test('a concurrent dead-lock recovery is never bypassed', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    fs.writeFileSync(path.join(f.store.directory, 'lock-recovery.json'), JSON.stringify({ pid: 12345, token: 'other' }))
    let started = false
    await assert.rejects(f.store.launch(f.distro([]), 'life', () => { started = true }), /busy/)
    assert.equal(started, false)
    assert.equal(fs.existsSync(old.getPath()), true)
})

test('no Java process probe is needed when there is nothing eligible for deletion', async t => {
    const f = fixture(t, { isJavaRunning: async () => { throw new Error('unnecessary process probe') } })
    await f.clean(f.distro([f.mod('current.jar')]))
    assert.equal(f.messages.some(message => message.includes('could not complete')), false)
})

test('another download transaction protects old files before its game has started', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const otherUpdate = await f.store.beginUpdate()
    const latest = f.distro([f.mod('new.jar')])
    await f.clean(latest)
    assert.equal(fs.existsSync(old.getPath()), true)
    otherUpdate.finish()
    await f.clean(latest)
    assert.equal(fs.existsSync(old.getPath()), false)
})

test('the finishing update may clean while its own transaction remains protected through spawn', async t => {
    const f = fixture(t)
    const old = f.mod('old.jar')
    await f.store.remember(f.distro([old]))
    const update = await f.store.beginUpdate()
    const child = await f.store.launch(f.distro([f.mod('new.jar')]), 'life', () => {
        assert.ok(fs.existsSync(path.join(f.store.directory, update.id)))
        return f.spawn()
    }, { updateId: update.id })
    assert.equal(fs.existsSync(old.getPath()), false)
    update.finish()
    f.close(child)
})
