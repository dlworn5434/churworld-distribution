const assert = require('node:assert/strict')
const test = require('node:test')
const { selectMacUpdate } = require('../../app/assets/js/macupdates')

function release(version, arches = ['arm64', 'x64'], fields = {}){
    return {
        tag_name: `v${version}`,
        name: `ChurWorld ${version}`,
        body: 'Release notes',
        published_at: '2026-09-18T00:00:00Z',
        draft: false,
        prerelease: false,
        assets: arches.map(arch => ({
            name: `ChurWorld-Launcher-setup-${version}-${arch}.dmg`,
            state: 'uploaded',
            size: 12345,
            browser_download_url: `https://github.com/dlworn5434/churworld-distribution/releases/download/v${version}/ChurWorld-Launcher-setup-${version}-${arch}.dmg`
        })),
        ...fields
    }
}

test('selects the correct architecture without ZIP or update metadata', () => {
    const releases = [release('2.2.7')]
    for(const arch of ['arm64', 'x64']){
        const result = selectMacUpdate(releases, '2.2.6', arch)
        assert.equal(result.version, '2.2.7')
        assert.ok(result.darwindownload.endsWith(`2.2.7-${arch}.dmg`))
    }
})

test('ignores releases missing the current Mac architecture, including Windows-only versions', () => {
    const releases = [release('2.2.9', []), release('2.2.8', ['x64']), release('2.2.7')]
    assert.equal(selectMacUpdate(releases, '2.2.6', 'arm64').version, '2.2.7')
    assert.equal(selectMacUpdate([release('2.2.8', ['x64'])], '2.2.6', 'arm64'), null)
})

test('uses semver ordering, avoids downgrade and ignores draft releases', () => {
    const releases = [release('2.2.9'), release('2.3.0', ['arm64'], { draft: true }), release('2.2.10')]
    assert.equal(selectMacUpdate(releases, '2.2.8', 'arm64').version, '2.2.10')
    assert.equal(selectMacUpdate(releases, '2.2.10', 'arm64'), null)
    assert.equal(selectMacUpdate(releases, '2.3.1', 'arm64'), null)
})

test('prereleases require opt-in including semver prereleases without the API flag', () => {
    const releases = [release('2.3.0-beta.1'), release('2.2.8', ['arm64'], { prerelease: true }), release('2.2.7')]
    assert.equal(selectMacUpdate(releases, '2.2.6', 'arm64').version, '2.2.7')
    assert.equal(selectMacUpdate(releases, '2.2.6', 'arm64', true).version, '2.3.0-beta.1')
})

test('escapes remote release title and notes before rendering HTML', () => {
    const result = selectMacUpdate([release('2.2.7', ['arm64'], {
        name: '<img src=x onerror=alert(1)>',
        body: 'First & second\n<script>alert("x")</script>'
    })], '2.2.6', 'arm64')
    assert.equal(result.releaseName, '&lt;img src=x onerror=alert(1)&gt;')
    assert.equal(result.releaseNotes, 'First &amp; second<br>&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;')
})

test('ignores incomplete, mismatched and foreign download assets', () => {
    for(const changes of [{ state: 'starter' }, { size: 0 }, { name: 'Helios-Launcher.dmg' }, { browser_download_url: 'https://example.com/launcher.dmg' }]){
        const candidate = release('2.2.7', ['arm64'])
        Object.assign(candidate.assets[0], changes)
        assert.equal(selectMacUpdate([candidate], '2.2.6', 'arm64'), null)
    }
})

test('handles empty and malformed release entries and unsupported architectures', () => {
    assert.equal(selectMacUpdate([], '2.2.6', 'arm64'), null)
    assert.equal(selectMacUpdate([null, {}, release('not-a-version')], '2.2.6', 'arm64'), null)
    assert.equal(selectMacUpdate([release('2.2.7')], '2.2.6', 'ia32'), null)
    assert.throws(() => selectMacUpdate({}, '2.2.6', 'arm64'), /Invalid GitHub/)
    assert.throws(() => selectMacUpdate([], 'invalid', 'arm64'), /Invalid current/)
})
