const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const test = require('node:test')
const vm = require('node:vm')

const processBuilderPath = path.resolve(__dirname, '../../app/assets/js/processbuilder.js')
const source = fs.readFileSync(processBuilderPath, 'utf8')

function loadProcessBuilder(arch, packagedIconExists = false){
    const extracted = []
    const loadedArchives = []
    const resourcesPath = path.resolve('/launcher/Contents/Resources')
    const fakeFs = {
        ensureDirSync(){},
        existsSync: candidate => packagedIconExists && candidate === path.join(resourcesPath, 'icon.icns'),
        writeFile: (destination, bytes, callback) => {
            extracted.push({ destination, bytes })
            callback(null)
        }
    }
    const dependencies = {
        './configmanager': {},
        'helios-core': { LoggerUtil: { getLogger: () => ({ error: assert.fail }) } },
        'helios-core/common': {
            isLibraryCompatible: rules => !rules || rules.some(rule => rule.action === 'allow' && rule.os.name === 'osx')
        },
        'fs-extra': fakeFs,
        'adm-zip': class {
            constructor(archive){
                loadedArchives.push(archive)
            }
            getEntries(){
                return [{ entryName: 'libfreetype.dylib', isDirectory: false, getData: () => Buffer.from('native') }]
            }
        }
    }
    const context = {
        module: { exports: {} },
        require: name => Object.hasOwn(dependencies, name) ? dependencies[name] : require(name),
        process: { platform: 'darwin', arch, resourcesPath },
        __dirname: path.dirname(processBuilderPath),
        console
    }
    vm.runInNewContext(source, context, { filename: processBuilderPath })
    return { ProcessBuilder: context.module.exports, extracted, loadedArchives, resourcesPath }
}

function nativeLibrary(classifier){
    return {
        name: `org.lwjgl:lwjgl-freetype:3.3.3:${classifier}`,
        rules: [{ action: 'allow', os: { name: 'osx' } }],
        downloads: { artifact: { path: `freetype-${classifier}.jar` } }
    }
}

for(const [arch, expectedClassifier] of [['x64', 'natives-macos-patch'], ['arm64', 'natives-macos-arm64']]){
    test(`Minecraft 1.21.4 selects the ${arch} freetype native and excludes the other architecture`, () => {
        const { ProcessBuilder, loadedArchives, extracted } = loadProcessBuilder(arch)
        const builder = Object.create(ProcessBuilder.prototype)
        builder.libPath = path.resolve('/libraries')
        builder.vanillaManifest = {
            libraries: [nativeLibrary('natives-macos-arm64'), nativeLibrary('natives-macos-patch')]
        }
        builder._resolveMojangLibraries(path.resolve('/natives'))
        assert.deepEqual(loadedArchives, [path.join(builder.libPath, `freetype-${expectedClassifier}.jar`)])
        assert.equal(extracted.length, 1)
        assert.equal(path.basename(extracted[0].destination), 'libfreetype.dylib')
    })
}

test('Mac game dock uses the packaged ChurWorld icon outside app.asar', () => {
    const { ProcessBuilder, resourcesPath } = loadProcessBuilder('arm64', true)
    assert.deepEqual(Array.from(ProcessBuilder.getMacDockArguments()), [
        '-Xdock:name=ChurWorld Launcher',
        '-Xdock:icon=' + path.join(resourcesPath, 'icon.icns')
    ])
})

test('Mac game dock keeps a development fallback when no packaged icon exists', () => {
    const { ProcessBuilder } = loadProcessBuilder('x64')
    assert.ok(ProcessBuilder.getMacDockArguments()[1].endsWith(path.join('images', 'minecraft.icns')))
})
