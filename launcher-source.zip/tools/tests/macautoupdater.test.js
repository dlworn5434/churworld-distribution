const assert = require('node:assert/strict')
const test = require('node:test')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const { Readable } = require('node:stream')
const { EventEmitter } = require('node:events')
const vm = require('node:vm')
const { createRequire } = require('node:module')
const secure = require('../../app/assets/js/secure-download')
// Native Mac operations are stubs in this suite. Signature/real crypto coverage
// lives in security-update.test.cjs; this boundary admits fixture objects only.
const approved = new WeakSet()
let bodyStream
const sourcePath = path.resolve(__dirname, '../../app/assets/js/macautoupdater.js')
const realRequire = createRequire(sourcePath)
const fixtureModule = { exports: {} }
const fixtureTrust = {
    assertTrustedUpdate(data) {
        if(!approved.has(data)) throw new Error('TRUST_UPDATE_NOT_APPROVED')
        return data.artifact
    },
    async downloadTrustedUpdate(data, destination, progress) {
        fixtureTrust.assertTrustedUpdate(data)
        return secure.downloadFile(data.artifact, destination, progress, { request: (_url, _options, callback) => {
            const request = new EventEmitter()
            request.destroy = error => request.emit('error', error)
            process.nextTick(() => { const response = bodyStream ? bodyStream() : Readable.from([bytes]); response.statusCode = 200; response.headers = {}; callback(response) })
            return request
        } })
    },
    async verifyTrustedUpdate(data, filename) { fixtureTrust.assertTrustedUpdate(data); return secure.verifyFile(data.artifact, filename) }
}
vm.runInNewContext(fs.readFileSync(sourcePath, 'utf8'), { require: name => name === './trusted-updates' ? fixtureTrust : realRequire(name), module: fixtureModule, exports: fixtureModule.exports, __dirname: path.dirname(sourcePath), process, URL, Buffer, setTimeout, clearTimeout, setInterval, clearInterval }, { filename: sourcePath })
const { MacAutoUpdater, validateDownload } = fixtureModule.exports
async function downloadDmg(data, destination, progress, stream) {
    bodyStream = stream
    try { return await fixtureModule.exports.downloadDmg(data, destination, progress) } finally { bodyStream = undefined }
}

const bytes = Buffer.from('verified mock disk image')
const info = {
    version: '2.2.8', arch: 'arm64', size: bytes.length,
    digest: `sha256:${crypto.createHash('sha256').update(bytes).digest('hex')}`,
    darwindownload: 'https://github.com/dlworn5434/churworld-distribution/releases/download/v2.2.8/ChurWorld-Launcher-setup-2.2.8-arm64.dmg'
}
info.artifact = { platform: 'darwin', arch: 'arm64', name: 'ChurWorld-Launcher-setup-2.2.8-arm64.dmg', url: info.darwindownload, size: info.size, sha256: info.digest.slice(7) }
approved.add(info)

function fixture(t, options = {}) {
    const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'chur-mac-update-')))
    const appPath = path.join(root, 'ChurWorld Launcher.app')
    fs.mkdirSync(appPath)
    fs.writeFileSync(path.join(appPath, 'unchanged'), 'old app')
    const calls = []
    const engine = new MacAutoUpdater({
        appPath, currentVersion: '2.2.7', arch: 'arm64', logPath: path.join(root, 'update.log'),
        alive: () => false,
        command: async (command, args) => {
            calls.push([command, args])
            if(options.fail && options.fail(command, args)) throw new Error('mock operation failed')
            if(command.endsWith('PlistBuddy')) {
                const version = args[2].startsWith(appPath + path.sep) ? '2.2.7' : '2.2.8'
                return { stdout: args[1].includes('Identifier') ? 'helioslauncher' : args[1].includes('ShortVersion') ? version : 'ChurWorld Launcher' }
            }
            if(command.endsWith('hdiutil') && args[0] === 'attach') fs.mkdirSync(path.join(args[args.indexOf('-mountpoint') + 1], 'ChurWorld Launcher.app'))
            if(command.endsWith('ditto')) fs.mkdirSync(args[1])
            if(command.endsWith('/file')) return { stdout: 'Mach-O 64-bit executable arm64' }
            if(command === '/bin/bash') return { stdout: 'b'.repeat(64) }
            return { stdout: '' }
        },
        download: async (data, dest, progress) => downloadDmg(data, dest, progress, () => Readable.from([bytes])),
        launch: (_cmd, args) => {
            calls.push(['spawn', args])
            const child = new EventEmitter()
            child.unref = () => calls.push(['unref'])
            setImmediate(() => {
                child.emit('spawn')
                fs.writeFileSync(path.join(engine.work, 'ready-to-quit'), '')
            })
            return child
        }, ...options.overrides
    })
    t.after(() => {
        const checked = fs.realpathSync(root)
        assert.equal(path.dirname(checked), fs.realpathSync(os.tmpdir()))
        assert.ok(path.basename(checked).startsWith('chur-mac-update-'))
        fs.rmSync(checked, { recursive: true })
    })
    return { root, appPath, engine, calls }
}

test('downloads a verified asset, stages it, detaches and only then announces readiness', async t => {
    const { engine, appPath, calls } = fixture(t)
    const notifications = []
    await engine.prepare(info, (...args) => notifications.push(args))
    assert.equal(fs.readFileSync(path.join(appPath, 'unchanged'), 'utf8'), 'old app')
    assert.equal(notifications[0][0], 'update-available')
    assert.equal(notifications.at(-1)[0], 'update-downloaded')
    assert.equal(fs.existsSync(path.join(engine.work, 'mounted')), false)
    assert.equal(calls.filter(([name]) => name.endsWith('codesign')).length, 3)
    assert.equal(await engine.install(true), true)
    const spawned = calls.find(([name]) => name === 'spawn')[1]
    assert.equal(spawned[9], '1')
    assert.equal(spawned[10], 'b'.repeat(64))
    assert.equal(spawned[11], info.artifact.sha256)
    assert.equal(await engine.install(true), false)
})

test('simultaneous checks/downloads stage only once', async t => {
    const { engine, calls } = fixture(t)
    await Promise.all([engine.prepare(info, () => {}), engine.prepare(info, () => {})])
    await engine.prepare(info, () => {})
    assert.equal(calls.filter(([name]) => name.endsWith('ditto')).length, 1)
})

for(const scenario of [
    ['signature failure', name => name.endsWith('codesign')],
    ['architecture check failure', name => name.endsWith('/file')],
    ['copy failure', name => name.endsWith('ditto')],
    ['unmount failure', (name, args) => name.endsWith('hdiutil') && args[0] === 'detach']
]) test(`${scenario[0]} never replaces the installed app`, async t => {
    const { engine, appPath } = fixture(t, { fail: scenario[1] })
    await assert.rejects(engine.prepare(info, () => {}), /mock operation failed/)
    assert.equal(fs.readFileSync(path.join(appPath, 'unchanged'), 'utf8'), 'old app')
    assert.equal(engine.ready, null)
    assert.equal(await engine.install(), false)
    if(scenario[0] === 'unmount failure') assert.ok(fs.existsSync(path.join(engine.work, 'mounted')))
    else assert.equal(fs.existsSync(engine.work), false)
})

test('digest and byte count are verified before mounting or copying', async t => {
    const { engine, appPath, calls } = fixture(t)
    const invalid = { ...info, digest: `sha256:${'a'.repeat(64)}`, artifact: { ...info.artifact, sha256: 'a'.repeat(64) } }
    approved.add(invalid)
    await assert.rejects(engine.prepare(invalid, () => {}), /TRUST_FILE_HASH/)
    assert.equal(calls.some(([name]) => name.endsWith('hdiutil')), false)
    assert.equal(fs.existsSync(engine.work), false)
    assert.ok(fs.existsSync(path.join(appPath, 'unchanged')))
})

test('download rejects truncation, excess bytes, network errors and existing destinations', async t => {
    const { root } = fixture(t)
    await assert.rejects(downloadDmg(info, path.join(root, 'short'), () => {}, () => Readable.from([bytes.subarray(1)])), /TRUST_FILE_SIZE/)
    await assert.rejects(downloadDmg(info, path.join(root, 'long'), () => {}, () => Readable.from([bytes, bytes])), /TRUST_FILE_SIZE/)
    await assert.rejects(downloadDmg(info, path.join(root, 'offline'), () => {}, () => Readable.from((async function*() { yield await Promise.reject(new Error('offline')) })())), /offline/)
    const existing = path.join(root, 'existing')
    fs.writeFileSync(existing, 'keep')
    await assert.rejects(downloadDmg(info, existing, () => {}, () => Readable.from([bytes])), /EEXIST/)
    assert.equal(fs.readFileSync(existing, 'utf8'), 'keep')
})

test('foreign URLs, architectures, invalid checksums and unreasonable sizes are refused', () => {
    for(const change of [
        { darwindownload: info.darwindownload.replace('github.com', 'evil.example') },
        { darwindownload: info.darwindownload.replace('https:', 'http:') },
        { darwindownload: info.darwindownload.replace('2.2.8-arm64', '2.2.8-x64') },
        { darwindownload: info.darwindownload + '?x=1' },
        { digest: undefined }, { digest: 'sha256:no' }, { size: 0 }, { size: 2 ** 40 }, { version: 'bogus' }
    ]) assert.throws(() => validateDownload({ ...info, ...change }, 'arm64'))
    assert.throws(() => validateDownload(info, 'ia32'))
})

test('does not stage a downgrade or overwrite another active updater workspace', async t => {
    const { engine, appPath } = fixture(t)
    await assert.rejects(engine.prepare({ ...info, version: '2.2.7' }, () => {}))
    engine.claimWorkspace()
    engine.alive = () => true
    await assert.rejects(engine.prepare(info, () => {}), /진행 중/)
    assert.ok(fs.existsSync(path.join(appPath, 'unchanged')))
})

test('recovers abandoned downloads but preserves mounted volumes and interrupted-swap backups', async t => {
    const { engine } = fixture(t)
    engine.claimWorkspace()
    fs.writeFileSync(path.join(engine.work, 'partial.dmg'), 'interrupted')
    engine.claimWorkspace()
    assert.equal(fs.existsSync(path.join(engine.work, 'partial.dmg')), false)
    fs.mkdirSync(path.join(engine.work, 'previous.app'))
    assert.throws(() => engine.claimWorkspace(), /복구 대기/)
    fs.rmdirSync(path.join(engine.work, 'previous.app'))
    fs.writeFileSync(path.join(engine.work, 'mounted'), '1')
    assert.throws(() => engine.claimWorkspace(), /디스크/)
})

test('refuses symlinked app roots and foreign workspace markers', async t => {
    const { engine, root, appPath } = fixture(t)
    const alias = path.join(root, 'Alias.app')
    fs.symlinkSync(appPath, alias, process.platform === 'win32' ? 'junction' : 'dir')
    const other = new MacAutoUpdater({ appPath: alias, currentVersion: '2.2.7', arch: 'arm64' })
    assert.throws(() => other.claimWorkspace(), /symbolic link/)
    engine.claimWorkspace()
    fs.writeFileSync(path.join(engine.work, 'owner.json'), JSON.stringify({ appPath: 'foreign', token: engine.token, pid: 123 }))
    assert.throws(() => engine.claimWorkspace(), /복구 대기/)
    assert.throws(() => engine.removeWorkspace(engine.token), /unverified/)
})

test('spawn failure keeps the downloaded update and original app for a retry', async t => {
    const { engine, appPath } = fixture(t, { overrides: { launch: () => {
        const child = new EventEmitter()
        setImmediate(() => child.emit('error', new Error('spawn failure')))
        return child
    } } })
    await engine.prepare(info, () => {})
    await assert.rejects(engine.install(), /spawn failure/)
    assert.equal(engine.installing, false)
    assert.ok(engine.ready)
    assert.ok(fs.existsSync(path.join(appPath, 'unchanged')))
})

test('wrong bundle identity, executable name or CPU is rejected even with a valid download hash', async t => {
    for(const mismatch of ['CFBundleIdentifier', 'CFBundleExecutable', 'architecture']) {
        const { engine, appPath } = fixture(t)
        const original = engine.command
        engine.command = async (command, args, options) => {
            if(command.endsWith('PlistBuddy') && args[1].includes(mismatch)) return { stdout: 'foreign-app' }
            if(command.endsWith('/file') && mismatch === 'architecture') return { stdout: 'Mach-O 64-bit executable x86_64' }
            return original(command, args, options)
        }
        await assert.rejects(engine.prepare(info, () => {}), /mismatch/)
        assert.equal(engine.ready, null)
        assert.ok(fs.existsSync(path.join(appPath, 'unchanged')))
    }
})

test('an incomplete recovery or changed workspace cannot trigger a second cleanup or installer', async t => {
    const { engine, appPath } = fixture(t)
    fs.mkdirSync(`${engine.work}.recovery`)
    assert.throws(() => engine.claimWorkspace(), /EEXIST/)
    fs.rmdirSync(`${engine.work}.recovery`)
    await engine.prepare(info, () => {})
    fs.writeFileSync(path.join(engine.work, 'owner.json'), JSON.stringify({ appPath, token: '0'.repeat(32), pid: process.pid }))
    await assert.rejects(engine.install(), /workspace changed/)
    assert.equal(engine.ready, null)
    assert.equal(engine.approvedInfo, null)
    assert.equal(fs.existsSync(engine.work), true)
})

test('post-download mutation invalidates approval, preserves current app and allows a fresh download', async t => {
    const { engine, appPath, calls } = fixture(t)
    await engine.prepare(info, () => {})
    fs.writeFileSync(path.join(engine.work, 'update.dmg'), Buffer.alloc(bytes.length))
    await assert.rejects(engine.install(), /TRUST_FILE_HASH/)
    assert.equal(engine.ready, null)
    assert.equal(engine.approvedInfo, null)
    assert.equal(fs.existsSync(engine.work), false)
    assert.equal(fs.readFileSync(path.join(appPath, 'unchanged'), 'utf8'), 'old app')
    await engine.prepare(info, () => {})
    assert.ok(engine.ready)
    assert.equal(calls.filter(([name]) => name.endsWith('ditto')).length, 2)
})
