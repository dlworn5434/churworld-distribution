#!/usr/bin/env node
// Offline manifest preparation only. This tool never posts or signs remotely.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { approvedUrl, safeRelative, validateDistribution, verifyEnvelope, isMutable } = require('../app/assets/js/trusted-manifest')
const { safeDestination } = require('../app/assets/js/secure-download')
function hash(bytes, algorithm = 'sha256') { return crypto.createHash(algorithm).update(bytes).digest('hex') }
function prepareDistribution({ source, sequence, issuedAt, expiresAt, sourceCommit, mutable = ['config/xaerohud.txt'] }) {
    if(sourceCommit !== undefined && !/^[a-f0-9]{40}$/.test(sourceCommit)) throw new Error('MANIFEST_SOURCE_COMMIT_INVALID')
    const root = path.resolve(source), distribution = JSON.parse(fs.readFileSync(path.join(root, 'distribution.json'), 'utf8'))
    let count = 0
    const walk = modules => modules.forEach(module => {
        const url = approvedUrl(module.artifact.url), prefix = '/dlworn5434/churworld-distribution/main/'
        if(url.hostname !== 'raw.githubusercontent.com' || !url.pathname.startsWith(prefix)) throw new Error('MANIFEST_SOURCE_NOT_LOCAL')
        const relative = safeRelative(decodeURIComponent(url.pathname.slice(prefix.length)))
        if(!relative.startsWith('files/')) throw new Error('MANIFEST_SOURCE_NOT_FILES')
        const filename = safeDestination(path.join(root, ...relative.split('/')), root)
        const bytes = fs.readFileSync(filename)
        if(sourceCommit) module.artifact.url = `https://raw.githubusercontent.com/dlworn5434/churworld-distribution/${sourceCommit}/${url.pathname.slice(prefix.length)}`
        module.artifact.size = bytes.length
        module.artifact.SHA256 = hash(bytes)
        if(mutable.includes(module.artifact.path)) {
            module.artifact.mutable = true
            if(!isMutable(module)) throw new Error('MANIFEST_MUTABLE_INVALID')
            delete module.artifact.MD5
        } else {
            delete module.artifact.mutable
            module.artifact.MD5 = hash(bytes, 'md5') // Compatibility only; SHA256 is authoritative.
        }
        count++
        if(module.subModules) walk(module.subModules)
    })
    for(const server of distribution.servers) walk(server.modules)
    validateDistribution(distribution)
    return { payload: { schema: 1, purpose: 'distribution', sequence, issuedAt, expiresAt, distribution }, count }
}
function parse(argv) {
    const result = {}
    for(let i = 0; i < argv.length; i += 2) {
        if(!/^--[a-z-]+$/.test(argv[i]) || argv[i + 1] === undefined) throw new Error('Arguments must be --name value pairs.')
        result[argv[i].slice(2)] = argv[i + 1]
    }
    return result
}
function main() {
    const [command, ...rest] = process.argv.slice(2), args = parse(rest)
    if(command === 'distribution') {
        const sequence = Number(args.sequence)
        if(!Number.isSafeInteger(sequence) || sequence < 1 || !args.source || !args.out || !args['issued-at'] || !args['expires-at']) throw new Error('Require --source --out --sequence --issued-at --expires-at.')
        const result = prepareDistribution({ source: args.source, sequence, issuedAt: args['issued-at'], expiresAt: args['expires-at'], sourceCommit: args['source-commit'] })
        fs.writeFileSync(args.out, JSON.stringify(result.payload, null, 2) + '\n', { flag: 'wx', mode: 0o600 })
        console.log(JSON.stringify({ output: path.resolve(args.out), artifacts: result.count, sha256: hash(fs.readFileSync(args.out)), signed: false }))
    } else if(command === 'launcher') {
        // Descriptor JSON contains version, platform/arch/name/url and localFile.
        // Local filenames never enter the signed public payload.
        const input = JSON.parse(fs.readFileSync(args.input, 'utf8'))
        const artifacts = input.artifacts.map(({ localFile, ...item }) => {
            const bytes = fs.readFileSync(localFile)
            return { ...item, size: bytes.length, sha256: hash(bytes) }
        })
        const payload = { schema: 1, purpose: 'launcher-update', sequence: Number(args.sequence), issuedAt: args['issued-at'], expiresAt: args['expires-at'], version: input.version, releaseName: input.releaseName, releaseNotes: input.releaseNotes, artifacts }
        fs.writeFileSync(args.out, JSON.stringify(payload, null, 2) + '\n', { flag: 'wx', mode: 0o600 })
        console.log(JSON.stringify({ output: path.resolve(args.out), artifacts: artifacts.length, signed: false }))
    } else if(command === 'verify' || command === 'status') {
        const keys = JSON.parse(fs.readFileSync(args.keys || path.join(__dirname, '../app/assets/js/security/trust-keys.json'), 'utf8'))
        const result = verifyEnvelope(fs.readFileSync(args.input), { purpose: args.purpose, keys, allowExpired: command === 'status' })
        const daysRemaining = Math.floor((Date.parse(result.payload.expiresAt) - Date.now()) / 86400000)
        console.log(JSON.stringify({ signatureVerified: true, validForNewDownloads: daysRemaining >= 0 && Date.parse(result.payload.expiresAt) > Date.now(), purpose: result.payload.purpose, sequence: result.payload.sequence, expiresAt: result.payload.expiresAt, daysRemaining, renewalRequired: daysRemaining <= 7, digest: result.digest }))
    } else throw new Error('Commands: distribution | launcher | verify | status')
}
if(require.main === module) { try { main() } catch(error) { console.error(error.code || error.message); process.exitCode = 1 } }
module.exports = { prepareDistribution }
