// Verify OS key durability in an isolated Electron process before loading the launcher.
if(process.argv.includes('--churu-credential-key-probe')) {
    const {app, safeStorage} = require('electron')
    require('./app/assets/js/credential-key-probe').runCredentialKeyProbe({app, safeStorage})
} else {
    require('./launcher-main')
}
