const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { execFile, spawn } = require('node:child_process')
const { promisify } = require('node:util')
const { pipeline } = require('node:stream/promises')
const { Transform } = require('node:stream')
const got = require('got')
const semver = require('semver')

const run = promisify(execFile)
const MAX_DMG_SIZE = 1024 * 1024 * 1024

function validateDownload(info, arch) {
    if(!info || !semver.valid(info.version) || !['arm64', 'x64'].includes(arch)) throw new Error('Invalid macOS update.')
    const name = `ChurWorld-Launcher-setup-${info.version}-${arch}.dmg`
    const url = new URL(info.darwindownload)
    if(url.origin !== 'https://github.com' || url.search || url.hash || url.username || url.password
        || semver.valid(decodeURIComponent(url.pathname.split('/')[5] || '')) !== info.version
        || !new RegExp(`^/dlworn5434/churworld-distribution/releases/download/[^/]+/${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`).test(url.pathname)) {
        throw new Error('Unexpected macOS download URL.')
    }
    if(!Number.isSafeInteger(info.size) || info.size <= 0 || info.size > MAX_DMG_SIZE
        || !/^sha256:[a-f0-9]{64}$/i.test(info.digest || '')) {
        throw new Error('GitHub 파일 검증 정보가 아직 없습니다. 잠시 후 다시 확인하세요.')
    }
    return info.digest.slice(7).toLowerCase()
}

async function downloadDmg(info, destination, progress, stream = got.stream) {
    const digest = validateDownload(info, info.arch)
    const hash = crypto.createHash('sha256')
    let bytes = 0
    const meter = new Transform({
        transform(chunk, _encoding, callback) {
            bytes += chunk.length
            if(bytes > info.size) return callback(new Error('Update download exceeds expected size.'))
            hash.update(chunk)
            progress({ percent: bytes * 100 / info.size })
            callback(null, chunk)
        }
    })
    await pipeline(stream(info.darwindownload, {
        timeout: { request: 600000 }, retry: { limit: 0 },
        headers: { 'User-Agent': 'ChurWorld-Launcher-Updater' }
    }), meter, fs.createWriteStream(destination, { flags: 'wx', mode: 0o600 }))
    if(bytes !== info.size || hash.digest('hex') !== digest) throw new Error('macOS update checksum mismatch.')
}

function plainDirectory(directory) {
    const stat = fs.lstatSync(directory)
    if(!stat.isDirectory() || stat.isSymbolicLink() || fs.realpathSync(directory) !== directory) {
        throw new Error('Update directory must not be a symbolic link.')
    }
    return stat
}

function processAlive(pid) {
    if(!Number.isSafeInteger(pid) || pid <= 0) return true
    try { process.kill(pid, 0); return true } catch(error) { return error.code !== 'ESRCH' }
}

class MacAutoUpdater {
    constructor({ appPath, currentVersion, arch, logPath, command = run, download = downloadDmg, launch = spawn, alive = processAlive }) {
        this.appPath = path.resolve(appPath)
        this.parent = path.dirname(this.appPath)
        this.work = path.join(this.parent, `.churworld-update-${crypto.createHash('sha256').update(this.appPath).digest('hex').slice(0, 16)}`)
        this.currentVersion = currentVersion
        this.arch = arch
        this.logPath = logPath
        this.command = command
        this.download = download
        this.launch = launch
        this.alive = alive
        this.ready = null
        this.installing = false
        this.busy = false
    }

    async plist(app, key) {
        const result = await this.command('/usr/libexec/PlistBuddy', ['-c', `Print :${key}`, path.join(app, 'Contents', 'Info.plist')], { timeout: 15000 })
        return result.stdout.trim()
    }

    async verifyApp(app, version) {
        plainDirectory(app)
        if(await this.plist(app, 'CFBundleIdentifier') !== 'helioslauncher'
            || await this.plist(app, 'CFBundleShortVersionString') !== version
            || await this.plist(app, 'CFBundleExecutable') !== 'ChurWorld Launcher') {
            throw new Error('Downloaded app identity or version mismatch.')
        }
        await this.command('/usr/bin/codesign', ['--verify', '--deep', '--strict', app], { timeout: 60000 })
        // file is a system utility; lipo can require Xcode Command Line Tools.
        const binary = await this.command('/usr/bin/file', ['-b', path.join(app, 'Contents', 'MacOS', 'ChurWorld Launcher')], { timeout: 15000 })
        const architecture = this.arch === 'arm64' ? /\barm64e?\b/ : /\bx86_64\b/
        if(!binary.stdout.includes('Mach-O') || !architecture.test(binary.stdout)) throw new Error('Downloaded app CPU architecture mismatch.')
    }

    // A single fixed workspace bounds disk use and serializes other launchers.
    // An interrupted swap keeps its backup for recovery instead of deleting it.
    claimWorkspace() {
        plainDirectory(this.parent)
        const original = plainDirectory(this.appPath)
        if(!this.appPath.endsWith('.app') || /\/Volumes\/|\/AppTranslocation\//.test(this.appPath)) {
            throw new Error('런처를 응용 프로그램 폴더로 옮긴 후 다시 실행하세요.')
        }
        fs.accessSync(this.parent, fs.constants.W_OK)
        // Serialize stale-workspace recovery as well as creation. A crashed
        // recovery guard is deliberately retained for manual inspection.
        const guard = `${this.work}.recovery`
        fs.mkdirSync(guard, { mode: 0o700 })
        try {
            if(fs.existsSync(this.work)) {
                plainDirectory(this.work)
                const markerPath = path.join(this.work, 'owner.json')
                const marker = JSON.parse(fs.readFileSync(markerPath, 'utf8'))
                if(marker.appPath !== this.appPath || !/^[a-f0-9]{32}$/.test(marker.token)
                    || this.alive(marker.pid) || fs.existsSync(path.join(this.work, 'previous.app'))
                    || fs.existsSync(path.join(this.work, 'installing'))) {
                    throw new Error('이전 업데이트가 진행 중이거나 복구 대기 중입니다. 기존 앱은 보존됩니다.')
                }
                // Never recursively delete a directory which may still be mounted.
                if(fs.existsSync(path.join(this.work, 'mounted'))) throw new Error('이전 업데이트 디스크를 분리한 뒤 다시 시도하세요.')
                this.removeWorkspace(marker.token)
            }
            fs.mkdirSync(this.work, { mode: 0o700 })
            this.token = crypto.randomBytes(16).toString('hex')
            fs.writeFileSync(path.join(this.work, 'owner.json'), JSON.stringify({ appPath: this.appPath, token: this.token, pid: process.pid }), { flag: 'wx', mode: 0o600 })
            fs.writeFileSync(path.join(this.work, 'token'), this.token, { flag: 'wx', mode: 0o600 })
            this.identity = `${original.dev}:${original.ino}`
        } finally {
            fs.rmdirSync(guard)
        }
    }

    removeWorkspace(token) {
        plainDirectory(this.work)
        const owner = JSON.parse(fs.readFileSync(path.join(this.work, 'owner.json'), 'utf8'))
        if(owner.appPath !== this.appPath || owner.token !== token || path.dirname(this.work) !== this.parent
            || fs.existsSync(path.join(this.work, 'mounted')) || fs.existsSync(path.join(this.work, 'previous.app'))) {
            throw new Error('Refusing to remove an unverified update workspace.')
        }
        fs.rmSync(this.work, { recursive: true })
    }

    async prepare(info, notify) {
        if(this.ready) { notify('update-downloaded', this.ready); return }
        if(this.busy) return
        this.busy = true
        let claimed = false
        let attached = false
        try {
            validateDownload(info, this.arch)
            if(!semver.gt(info.version, this.currentVersion)) throw new Error('Update must be newer than the running app.')
            this.claimWorkspace()
            claimed = true
            await this.verifyApp(this.appPath, this.currentVersion)
            notify('update-available', { ...info, automatic: true })
            const dmg = path.join(this.work, 'update.dmg')
            await this.download({ ...info, arch: this.arch }, dmg, progress => notify('download-progress', progress))
            const mount = path.join(this.work, 'volume')
            fs.mkdirSync(mount)
            // Mark before attaching: a failed attach may have partially mounted.
            fs.writeFileSync(path.join(this.work, 'mounted'), '1', { flag: 'wx' })
            attached = true
            await this.command('/usr/bin/hdiutil', ['attach', '-readonly', '-nobrowse', '-noautoopen', '-mountpoint', mount, dmg], { timeout: 120000 })
            const source = path.join(mount, 'ChurWorld Launcher.app')
            await this.verifyApp(source, info.version)
            const staged = path.join(this.work, 'next.app')
            await this.command('/usr/bin/ditto', [source, staged], { timeout: 120000 })
            await this.verifyApp(staged, info.version)
            await this.command('/usr/bin/hdiutil', ['detach', mount], { timeout: 30000 })
            attached = false
            fs.unlinkSync(path.join(this.work, 'mounted'))
            fs.copyFileSync(path.join(__dirname, 'mac-update-install.sh'), path.join(this.work, 'install.sh'), fs.constants.COPYFILE_EXCL)
            fs.chmodSync(path.join(this.work, 'install.sh'), 0o700)
            this.ready = { ...info, automatic: true }
            notify('update-downloaded', this.ready)
        } catch(error) {
            if(attached) {
                try {
                    await this.command('/usr/bin/hdiutil', ['detach', path.join(this.work, 'volume')], { timeout: 30000 })
                    fs.unlinkSync(path.join(this.work, 'mounted'))
                } catch(_detachError) { /* Keep the mount and workspace; never remove mounted contents. */ }
            }
            if(claimed && !fs.existsSync(path.join(this.work, 'mounted'))) this.removeWorkspace(this.token)
            throw error
        } finally {
            this.busy = false
        }
    }

    async install(relaunch = false) {
        if(!this.ready || this.installing) return false
        plainDirectory(this.work)
        const owner = JSON.parse(fs.readFileSync(path.join(this.work, 'owner.json'), 'utf8'))
        if(owner.token !== this.token || owner.appPath !== this.appPath) throw new Error('Update workspace changed.')
        const log = fs.openSync(this.logPath, 'w', 0o600)
        try {
            const child = this.launch('/bin/bash', [path.join(this.work, 'install.sh'), String(process.pid), this.appPath,
                this.work, this.token, this.ready.version, this.currentVersion, this.arch, this.identity, relaunch ? '1' : '0'],
            { detached: true, stdio: ['ignore', log, log] })
            await new Promise((resolve, reject) => {
                child.once('error', reject)
                child.once('spawn', resolve)
            })
            await new Promise((resolve, reject) => {
                const finish = error => {
                    clearInterval(poll)
                    clearTimeout(timeout)
                    child.removeListener('exit', exited)
                    if(error) reject(error)
                    else resolve()
                }
                const exited = () => finish(new Error('macOS 설치 준비에 실패했습니다. 업데이트 로그를 확인하세요.'))
                const poll = setInterval(() => {
                    if(fs.existsSync(path.join(this.work, 'ready-to-quit'))) finish()
                }, 50)
                const timeout = setTimeout(() => {
                    child.kill('SIGTERM')
                    finish(new Error('macOS 설치 준비 시간이 초과되었습니다.'))
                }, 10000)
                child.once('exit', exited)
            })
            child.unref()
            this.installing = true
            return true
        } finally {
            fs.closeSync(log)
        }
    }
}

module.exports = { MacAutoUpdater, downloadDmg, validateDownload }
