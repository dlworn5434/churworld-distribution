const path = require('node:path')
const fs = require('node:fs')
const { DistributionAPI, HeliosDistribution } = require('helios-core/common')
const { LoggerUtil } = require('helios-core')

const ConfigManager = require('./configmanager')
const { ManagedModStore } = require('./managedmods')
const managedModHistory = require('./managed-mod-history.json')
const { TrustedCache } = require('./trusted-cache')
const { fail, isMutable } = require('./trusted-manifest')
const { safeDestination, verifyFile, downloadFile } = require('./secure-download')

const logger = LoggerUtil.getLogger('ManagedMods')
let managedMods
const approvals = new WeakMap()

function getManagedMods() {
    const commonDirectory = ConfigManager.getCommonDirectory()
    if(!managedMods || managedMods.commonDirectory !== commonDirectory) {
        managedMods = new ManagedModStore(commonDirectory, { logger, history: managedModHistory })
    }
    return managedMods
}

function freezeTree(value) {
    if(value && typeof value === 'object' && !Object.isFrozen(value)) {
        for(const item of Object.values(value)) freezeTree(item)
        Object.freeze(value)
    }
    return value
}
function entries(distribution, serverId, commonDir, instanceDir) {
    const server = distribution.getServerById(serverId)
    if(!server) fail('TRUST_SERVER_INVALID')
    const result = [], paths = new Set()
    const walk = modules => {
        for(const module of modules) {
            const filename = path.resolve(module.getPath())
            const root = module.rawModule.type === 'File' ? path.join(instanceDir, serverId) : commonDir
            safeDestination(filename, root)
            const key = process.platform === 'win32' ? filename.toLowerCase() : filename
            if(paths.has(key)) fail('TRUST_PATH_DUPLICATE')
            paths.add(key)
            result.push({ filename, root, descriptor: module.rawModule.artifact, mutable: isMutable(module.rawModule) })
            walk(module.subModules)
        }
    }
    walk(server.modules)
    return result
}
class ManagedDistributionAPI extends DistributionAPI {
    getCache() {
        if(!this.trustedCache) this.trustedCache = new TrustedCache({ directory: path.join(this.launcherDirectory, 'trusted-metadata'), purpose: 'distribution', url: this.remoteUrl, allowExpiredFallback: true })
        return this.trustedCache
    }
    build(verified) {
        if(!verified) fail('TRUST_DISTRIBUTION_UNAVAILABLE')
        const raw = JSON.parse(JSON.stringify(verified.payload.distribution))
        const distribution = new HeliosDistribution(raw, this.commonDir, this.instanceDir)
        // Helios normalizes mainServer in its constructor. Freeze afterwards.
        freezeTree(distribution)
        approvals.set(distribution, { verified, commonDir: this.commonDir, instanceDir: this.instanceDir })
        this.rawDistribution = raw; this.distribution = distribution
        return distribution
    }
    async getDistribution() {
        if(this.distribution) { this.assertApproved(this.distribution); return this.distribution }
        return this.refreshDistributionOrFallback()
    }
    async getDistributionLocalLoadOnly() { return this.build(this.getCache().read(true)) }
    async refreshDistributionOrFallback() {
        const previous = this.getCache().read(true)
        if(previous && !this.isDevMode() && this.commonDir && this.instanceDir) {
            try { await getManagedMods().remember(new HeliosDistribution(JSON.parse(JSON.stringify(previous.payload.distribution)), this.commonDir, this.instanceDir)) }
            catch(_error) { logger.warn('Could not record previous managed mods; unrecorded files will be kept.') }
        }
        return this.build(await this.getCache().refresh())
    }
    async pullLocal() { return this.getCache().read()?.payload.distribution || null }
    async pullRemote() { fail('TRUST_DIRECT_PULL_DISABLED') }
    async writeDistributionToDisk() { fail('TRUST_UNSIGNED_CACHE_DISABLED') }
    async loadDistribution() { return (await this.refreshDistributionOrFallback()).rawDistribution }
    async _loadDistributionNullable() { return this.loadDistribution() }
    assertApproved(distribution) {
        const proof = approvals.get(distribution)
        if(!proof || proof.commonDir !== this.commonDir || proof.instanceDir !== this.instanceDir) fail('TRUST_DISTRIBUTION_NOT_APPROVED')
        this.getCache().verify(proof.verified.envelope, { previous: this.getCache().read(true), allowExpired: true })
        return proof
    }
    isOfflineOnly(distribution) { return Date.parse(this.assertApproved(distribution).verified.payload.expiresAt) <= this.getCache().now() }
    getTrustStatus(distribution) {
        const expiresAt = this.assertApproved(distribution).verified.payload.expiresAt
        const remaining = Date.parse(expiresAt) - this.getCache().now()
        return { expiresAt, daysRemaining: Math.floor(remaining / 86400000), offlineOnly: remaining <= 0, renewalRequired: remaining <= 7 * 86400000 }
    }
    getVerifiedSnapshot(distribution) { return this.assertApproved(distribution).verified }
    getFileEntries(distribution, serverId) { this.assertApproved(distribution); return entries(distribution, serverId, this.commonDir, this.instanceDir) }
    async prepareServerFiles(distribution, serverId, progress = () => {}) {
        this.assertApproved(distribution)
        if(this.isOfflineOnly(distribution)) return this.verifyServerFiles(distribution, serverId)
        const files = entries(distribution, serverId, this.commonDir, this.instanceDir)
        for(let index = 0; index < files.length; index++) {
            const file = files[index]
            if(file.mutable && fs.existsSync(file.filename)) continue
            let valid = false
            try { await verifyFile(file.descriptor, file.filename, file.root); valid = true }
            catch(error) { if(!['ENOENT', 'TRUST_FILE_SIZE', 'TRUST_FILE_HASH'].includes(error.code)) throw error }
            if(!valid) await downloadFile(file.descriptor, file.filename, update => progress({ ...update, index, count: files.length }), { root: file.root })
        }
        this.assertApproved(distribution)
    }
    async verifyServerFiles(distribution, serverId) {
        this.assertApproved(distribution)
        for(const file of entries(distribution, serverId, this.commonDir, this.instanceDir)) {
            if(file.mutable && fs.existsSync(file.filename)) continue
            await verifyFile(file.descriptor, file.filename, file.root)
        }
    }
}

// Old WesterosCraft url.
// exports.REMOTE_DISTRO_URL = 'http://mc.westeroscraft.com/WesterosCraftLauncher/distribution.json'
exports.REMOTE_DISTRO_URL = 'https://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/distribution.signed.json'
const api = new ManagedDistributionAPI(
    ConfigManager.getLauncherDirectory(),
    null, // Injected forcefully by the preloader.
    null, // Injected forcefully by the preloader.
    exports.REMOTE_DISTRO_URL,
    false
)

exports.DistroAPI = api

exports.beginManagedUpdate = () => getManagedMods().beginUpdate()

// The caller must complete file validation/downloads before entering this gate.
exports.launchWithManagedMods = async (distribution, serverId, startGame, update) => {
    const store = getManagedMods()
    if(update && update.commonDirectory !== store.commonDirectory) throw new Error('Game directory changed during update. Please retry.')
    await api.verifyServerFiles(distribution, serverId)
    return store.launch(distribution, serverId, startGame, { allowCleanup: !api.isDevMode(), updateId: update?.id })
}
exports.ManagedDistributionAPI = ManagedDistributionAPI
