const { DistributionAPI, HeliosDistribution } = require('helios-core/common')
const { LoggerUtil } = require('helios-core')

const ConfigManager = require('./configmanager')
const { ManagedModStore } = require('./managedmods')

const logger = LoggerUtil.getLogger('ManagedMods')
let managedMods

function getManagedMods() {
    const commonDirectory = ConfigManager.getCommonDirectory()
    if(!managedMods || managedMods.commonDirectory !== commonDirectory) {
        managedMods = new ManagedModStore(commonDirectory, { logger })
    }
    return managedMods
}

class ManagedDistributionAPI extends DistributionAPI {
    async writeDistributionToDisk(distribution) {
        // Preload fetches a new index before the launch button is pressed.
        // Preserve verified old ownership before that cache gets overwritten.
        if(!this.isDevMode() && this.commonDir && this.instanceDir) {
            try {
                const previous = await this.pullLocal()
                if(previous) await getManagedMods().remember(new HeliosDistribution(previous, this.commonDir, this.instanceDir))
            } catch(_error) {
                logger.warn('Could not record previous managed mods; unrecorded files will be kept.')
            }
        }
        return super.writeDistributionToDisk(distribution)
    }
}

// Old WesterosCraft url.
// exports.REMOTE_DISTRO_URL = 'http://mc.westeroscraft.com/WesterosCraftLauncher/distribution.json'
exports.REMOTE_DISTRO_URL = 'https://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/distribution.json'
const api = new ManagedDistributionAPI(
    ConfigManager.getLauncherDirectory(),
    null, // Injected forcefully by the preloader.
    null, // Injected forcefully by the preloader.
    exports.REMOTE_DISTRO_URL,
    false
)

exports.DistroAPI = api

exports.beginManagedUpdate = () => getManagedMods().beginUpdate()

// The caller must complete file validation/downloads before entering this gate.
exports.launchWithManagedMods = (distribution, serverId, startGame, update) => {
    const store = getManagedMods()
    if(update && update.commonDirectory !== store.commonDirectory) throw new Error('Game directory changed during update. Please retry.')
    return store.launch(distribution, serverId, startGame, { allowCleanup: !api.isDevMode(), updateId: update?.id })
}
