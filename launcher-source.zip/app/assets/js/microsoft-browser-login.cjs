'use strict'

// Main-process only. OAuth codes, PKCE verifiers, and tokens never reach UI callbacks.
const http = require('node:http')
const https = require('node:https')
const crypto = require('node:crypto')

const AUTHORIZE_URL = 'https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize'
const TOKEN_URL = 'https://login.microsoftonline.com/consumers/oauth2/v2.0/token'
const NATIVE_REDIRECT = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
const SCOPE = 'XboxLive.signin offline_access'
const MAX_RESPONSE_BYTES = 64 * 1024
const MAX_CALLBACK_LENGTH = 16 * 1024
const FLOW_TIMEOUT_MS = 5 * 60 * 1000
const REQUEST_TIMEOUT_MS = 15 * 1000
const CALLBACK_HTML = '<!doctype html><html lang="ko"><meta charset="utf-8"><title>ChurWorld 로그인</title><body><p>로그인 응답을 받았습니다. 츄르월드 런처에서 결과를 확인해 주세요.</p></body></html>'
const INVALID_HTML = '<!doctype html><html lang="ko"><meta charset="utf-8"><title>ChurWorld 로그인</title><body><p>이 요청을 처리할 수 없습니다. 츄르월드 런처에서 로그인을 진행해 주세요.</p></body></html>'
const ALLOWED_CODES = new Set(['AUTH_BROWSER_DENIED', 'AUTH_BROWSER_CONFIG_REQUIRED', 'AUTH_BROWSER_TIMEOUT', 'AUTH_STATE_CHANGED', 'AUTH_INVALID_RESPONSE', 'AUTH_TEMPORARY_FAILURE', 'AUTH_REAUTH_REQUIRED'])
const ALLOWED_REASONS = new Set(['cancelled', 'expired', 'configuration', 'denied', 'network', 'network_timeout', 'invalid_response', 'redirect_rejected', 'provider_error', 'provider_unavailable', 'rate_limited', 'invalid_grant', 'browser_open_failed', 'listener_failed'])

class MicrosoftBrowserLoginError extends Error {
    constructor(code, reason) {
        const safeCode = ALLOWED_CODES.has(code) ? code : 'AUTH_TEMPORARY_FAILURE'
        super(safeCode)
        this.name = 'MicrosoftBrowserLoginError'
        this.code = safeCode
        this.reason = ALLOWED_REASONS.has(reason) ? reason : 'provider_error'
    }
}

const failure = (code, reason) => new MicrosoftBrowserLoginError(code, reason)
const cancelled = () => failure('AUTH_STATE_CHANGED', 'cancelled')
const invalidResponse = () => failure('AUTH_INVALID_RESPONSE', 'invalid_response')

function safeProviderError(value, status) {
    if (status === 429) return failure('AUTH_TEMPORARY_FAILURE', 'rate_limited')
    if (status >= 500) return failure('AUTH_TEMPORARY_FAILURE', 'provider_unavailable')
    if (value === 'access_denied' || value === 'user_cancelled' || value === 'authorization_declined') return failure('AUTH_BROWSER_DENIED', 'denied')
    if (['invalid_client', 'unauthorized_client', 'invalid_request', 'invalid_scope', 'unsupported_response_type', 'unsupported_grant_type'].includes(value)) return failure('AUTH_BROWSER_CONFIG_REQUIRED', 'configuration')
    if (value === 'invalid_grant' || value === 'interaction_required' || value === 'login_required') return failure('AUTH_REAUTH_REQUIRED', 'invalid_grant')
    return failure('AUTH_TEMPORARY_FAILURE', 'provider_error')
}

function validToken(value) {
    return typeof value === 'string' && value.length > 0 && value.length <= 32768 && /^[\x21-\x7e]+$/.test(value)
}

function decodeTokenResponse(response) {
    if (!response || !Number.isInteger(response.statusCode)) throw invalidResponse()
    if (response.statusCode >= 300 && response.statusCode < 400) throw failure('AUTH_INVALID_RESPONSE', 'redirect_rejected')
    if (response.statusCode === 429 || response.statusCode >= 500) throw safeProviderError(null, response.statusCode)
    if (typeof response.body !== 'string' || Buffer.byteLength(response.body, 'utf8') > MAX_RESPONSE_BYTES) throw invalidResponse()
    const contentType = response.headers && response.headers['content-type']
    if (typeof contentType !== 'string' || !/^application\/json(?:\s*;|\s*$)/i.test(contentType)) throw invalidResponse()
    let body
    try { body = JSON.parse(response.body) } catch { throw invalidResponse() }
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw invalidResponse()
    if (response.statusCode !== 200) throw safeProviderError(body.error, response.statusCode)
    if (Object.prototype.hasOwnProperty.call(body, 'error') || !validToken(body.access_token) || !validToken(body.refresh_token)
        || typeof body.token_type !== 'string' || body.token_type.toLowerCase() !== 'bearer'
        || !Number.isSafeInteger(body.expires_in) || body.expires_in <= 10
        || !Number.isSafeInteger(Date.now() + body.expires_in * 1000)) throw invalidResponse()
    return {access_token: body.access_token, refresh_token: body.refresh_token, expires_in: body.expires_in, token_type: 'Bearer'}
}

// No redirect following, retries, cookies, environment credentials, or response logging.
function nativeTokenRequest({url, form, signal, timeoutMs, maxBytes}) {
    if (url !== TOKEN_URL || maxBytes !== MAX_RESPONSE_BYTES || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > REQUEST_TIMEOUT_MS) return Promise.reject(invalidResponse())
    if (signal.aborted) return Promise.reject(cancelled())
    return new Promise((resolve, reject) => {
        let settled = false, request, response, timer
        const finish = (error, result) => {
            if (settled) return
            settled = true
            clearTimeout(timer)
            signal.removeEventListener('abort', abort)
            if (error) {
                response?.destroy()
                request?.destroy()
                reject(error)
            } else resolve(result)
        }
        const abort = () => finish(cancelled())
        signal.addEventListener('abort', abort, {once: true})
        if (signal.aborted) { abort(); return }
        timer = setTimeout(() => finish(failure('AUTH_TEMPORARY_FAILURE', 'network_timeout')), timeoutMs)
        try {
            const payload = new URLSearchParams(form).toString()
            request = https.request(TOKEN_URL, {method: 'POST', headers: {
                'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json',
                'Content-Length': Buffer.byteLength(payload), Connection: 'close'
            }}, incoming => {
                response = incoming
                if (settled) { incoming.destroy(); return }
                let length = 0
                const chunks = []
                incoming.on('data', chunk => {
                    length += chunk.length
                    if (length > maxBytes) { finish(invalidResponse()); return }
                    chunks.push(chunk)
                })
                incoming.on('aborted', () => finish(failure('AUTH_TEMPORARY_FAILURE', 'network')))
                incoming.on('error', () => finish(failure('AUTH_TEMPORARY_FAILURE', 'network')))
                incoming.on('end', () => finish(null, {statusCode: incoming.statusCode, headers: incoming.headers, body: Buffer.concat(chunks).toString('utf8')}))
            })
            request.on('error', () => finish(failure('AUTH_TEMPORARY_FAILURE', 'network')))
            request.end(payload)
        } catch { finish(failure('AUTH_TEMPORARY_FAILURE', 'network')) }
    })
}

function equalState(actual, expected) {
    if (typeof actual !== 'string' || actual.length !== expected.length) return false
    const actualBytes = Buffer.from(actual, 'utf8'), expectedBytes = Buffer.from(expected, 'utf8')
    return actualBytes.length === expectedBytes.length && crypto.timingSafeEqual(actualBytes, expectedBytes)
}

function queryData(url, expectedState) {
    if (url.hash || Array.from(url.searchParams).length > 20) return null
    const state = url.searchParams.getAll('state'), code = url.searchParams.getAll('code'), error = url.searchParams.getAll('error')
    if (state.length !== 1 || !equalState(state[0], expectedState) || code.length > 1 || error.length > 1 || code.length + error.length !== 1) return null
    if (code.length === 1 && validToken(code[0]) && code[0].length <= 8192) return {code: code[0]}
    if (error.length === 1 && /^[a-z_]{1,80}$/.test(error[0])) return {error: error[0]}
    return null
}

function copiedCallbackData(value, expectedState) {
    if (typeof value !== 'string' || value.length > MAX_CALLBACK_LENGTH) return null
    const trimmed = value.trim()
    // The raw prefix also rejects explicit :443, encoded hostnames, userinfo, and backslashes.
    if (!trimmed.startsWith(NATIVE_REDIRECT + '?')) return null
    let url
    try { url = new URL(trimmed) } catch { return null }
    if (url.origin + url.pathname !== NATIVE_REDIRECT || url.username || url.password || url.port) return null
    return queryData(url, expectedState)
}

function callbackData(request, expectedHost, expectedState) {
    if (request.method !== 'GET' || request.socket.remoteAddress !== '127.0.0.1') return null
    if (request.headers.host !== expectedHost || request.headers['transfer-encoding'] != null
        || (request.headers['content-length'] != null && request.headers['content-length'] !== '0')) return null
    const hostCount = request.rawHeaders.filter((value, index) => index % 2 === 0 && value.toLowerCase() === 'host').length
    if (hostCount !== 1 || typeof request.url !== 'string' || request.url.length > MAX_CALLBACK_LENGTH || !request.url.startsWith('/') || request.url.startsWith('//')) return null
    let url
    try { url = new URL(request.url, 'http://' + expectedHost) } catch { return null }
    if (url.pathname !== '/') return null
    return queryData(url, expectedState)
}

function respond(response, statusCode, accepted) {
    return new Promise(resolve => {
        response.once('finish', resolve)
        response.once('close', resolve)
        response.writeHead(statusCode, {
            'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store, max-age=0', Pragma: 'no-cache',
            'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
            'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', Connection: 'close'
        })
        response.end(accepted ? CALLBACK_HTML : INVALID_HTML)
    })
}

function createMicrosoftBrowserLogin(dependencies = {}) {
    const requestToken = dependencies.requestToken || nativeTokenRequest
    const timeoutMs = dependencies.timeoutMs ?? FLOW_TIMEOUT_MS
    const requestTimeoutMs = dependencies.requestTimeoutMs ?? REQUEST_TIMEOUT_MS
    if (typeof requestToken !== 'function' || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > FLOW_TIMEOUT_MS
        || !Number.isInteger(requestTimeoutMs) || requestTimeoutMs < 1 || requestTimeoutMs > REQUEST_TIMEOUT_MS) throw failure('AUTH_BROWSER_CONFIG_REQUIRED', 'configuration')
    return function acquireMicrosoftBrowserToken({clientId, openBrowser, signal, onStatus, mode = 'copy-link', onCallbackReady, onReopenReady} = {}) {
        if (typeof clientId !== 'string' || !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(clientId)
            || typeof openBrowser !== 'function' || (onStatus != null && typeof onStatus !== 'function')
            || !['copy-link', 'loopback'].includes(mode)
            || (mode === 'copy-link' && typeof onCallbackReady !== 'function')
            || (onCallbackReady != null && typeof onCallbackReady !== 'function')
            || (onReopenReady != null && typeof onReopenReady !== 'function')
            || (signal != null && (typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function'))) return Promise.reject(failure('AUTH_BROWSER_CONFIG_REQUIRED', 'configuration'))
        if (signal?.aborted) return Promise.reject(cancelled())
        return new Promise((resolve, reject) => {
            let settled = false, exchanging = false, openingBrowser = false, server, timer, port, redirectUri
            const connections = new Set()
            const requestAbort = new AbortController()
            const state = crypto.randomBytes(32).toString('base64url')
            const verifier = crypto.randomBytes(64).toString('base64url')
            const challenge = crypto.createHash('sha256').update(verifier).digest('base64url')
            const notify = status => {
                if (typeof onStatus !== 'function' || (settled && status !== 'complete')) return
                try { Promise.resolve(onStatus(status)).catch(() => {}) } catch { /* UI notifications cannot change OAuth state. */ }
            }
            const closeListener = () => {
                if (!server) return
                try { server.close(() => {}) } catch { /* A listener already closing needs no further action. */ }
            }
            const finish = (error, tokens) => {
                if (settled) return
                settled = true
                clearTimeout(timer)
                signal?.removeEventListener('abort', abort)
                requestAbort.abort()
                closeListener()
                for (const socket of connections) socket.destroy()
                if (error) reject(error instanceof MicrosoftBrowserLoginError ? error : failure('AUTH_TEMPORARY_FAILURE', 'provider_error'))
                else { notify('complete'); resolve(tokens) }
            }
            const abort = () => finish(cancelled())
            signal?.addEventListener('abort', abort, {once: true})
            if (signal?.aborted) { abort(); return }
            timer = setTimeout(() => finish(failure('AUTH_BROWSER_TIMEOUT', 'expired')), timeoutMs)
            const exchange = async data => {
                if (settled) return
                if (data.error) { finish(safeProviderError(data.error, 400)); return }
                notify('exchanging_token')
                try {
                    const result = await requestToken({url: TOKEN_URL, form: {
                        client_id: clientId, scope: SCOPE, grant_type: 'authorization_code',
                        code: data.code, redirect_uri: redirectUri, code_verifier: verifier
                    }, signal: requestAbort.signal, timeoutMs: requestTimeoutMs, maxBytes: MAX_RESPONSE_BYTES})
                    if (settled) return
                    finish(null, decodeTokenResponse(result))
                } catch (error) {
                    if (!settled) finish(error instanceof MicrosoftBrowserLoginError ? error : failure('AUTH_TEMPORARY_FAILURE', 'network'))
                }
            }
            const handleRequest = async (request, response) => {
                request.resume()
                if (settled || exchanging) { await respond(response, 409, false); return }
                let data
                try { data = callbackData(request, 'localhost:' + port, state) } catch { data = null }
                if (data == null) { await respond(response, 400, false); return }
                exchanging = true
                await respond(response, 200, true)
                closeListener()
                await exchange(data)
            }
            const beginBrowser = () => {
                const target = new URL(AUTHORIZE_URL)
                for (const [key, value] of Object.entries({client_id: clientId, response_type: 'code', response_mode: 'query', scope: SCOPE,
                    redirect_uri: redirectUri, state, code_challenge: challenge, code_challenge_method: 'S256', prompt: 'select_account'})) target.searchParams.set(key, value)
                const reopen = async () => {
                    if (settled || exchanging || openingBrowser) return false
                    openingBrowser = true
                    notify('opening_browser')
                    try {
                        await openBrowser(target.href)
                        if (!settled && !exchanging) notify('waiting_for_browser')
                        return !settled || exchanging
                    } catch {
                        if (!settled && !exchanging) finish(failure('AUTH_TEMPORARY_FAILURE', 'browser_open_failed'))
                        return false
                    } finally { openingBrowser = false }
                }
                if (mode === 'copy-link') {
                    // Main-process callback only: UI must invoke an explicit operation that reads the clipboard in main.
                    // Never send this callback, clipboard text, authorization URL, or auth code through renderer IPC.
                    onCallbackReady(value => {
                        if (settled || exchanging) return false
                        let data
                        try { data = copiedCallbackData(value, state) } catch { data = null }
                        if (data == null) return false
                        exchanging = true
                        void exchange(data)
                        return true
                    })
                }
                if (onReopenReady) onReopenReady(reopen)
                void reopen()
            }
            try {
                if (mode === 'copy-link') {
                    redirectUri = NATIVE_REDIRECT
                    beginBrowser()
                    return
                }
                server = http.createServer({maxHeaderSize: MAX_CALLBACK_LENGTH + 8192}, (request, response) => {
                    handleRequest(request, response).catch(() => { if (!settled) finish(invalidResponse()) })
                })
                server.requestTimeout = REQUEST_TIMEOUT_MS
                server.headersTimeout = REQUEST_TIMEOUT_MS
                server.keepAliveTimeout = 1
                server.maxRequestsPerSocket = 1
                server.maxConnections = 16
                server.on('connection', socket => {
                    connections.add(socket)
                    socket.setTimeout(REQUEST_TIMEOUT_MS, () => socket.destroy())
                    socket.on('close', () => connections.delete(socket))
                })
                server.on('clientError', (_error, socket) => { socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n') })
                server.on('error', () => finish(failure('AUTH_TEMPORARY_FAILURE', 'listener_failed')))
                server.listen({host: '127.0.0.1', port: 0, exclusive: true}, () => {
                    if (settled) { closeListener(); return }
                    port = server.address().port
                    redirectUri = 'http://localhost:' + port + '/'
                    try { beginBrowser() } catch { finish(failure('AUTH_TEMPORARY_FAILURE', 'browser_open_failed')) }
                })
            } catch { finish(failure('AUTH_TEMPORARY_FAILURE', 'listener_failed')) }
        })
    }
}

const acquireMicrosoftBrowserToken = createMicrosoftBrowserLogin()
module.exports = {acquireMicrosoftBrowserToken, createMicrosoftBrowserLogin, MicrosoftBrowserLoginError}
