/**
 * Script for landing.ejs
 */
// Requirements
const { URL }                 = require('url')
const {
    MojangRestAPI,
    getServerStatus
}                             = require('helios-core/mojang')
const {
    RestResponseStatus,
    isDisplayableError,
    validateLocalFile
}                             = require('helios-core/common')
const {
    FullRepair,
    DistributionIndexProcessor,
    MojangIndexProcessor,
    downloadFile
}                             = require('helios-core/dl')
const {
    validateSelectedJvm,
    ensureJavaDirIsRoot,
    javaExecFromRoot,
    discoverBestJvmInstallation,
    latestOpenJDK,
    extractJdk
}                             = require('helios-core/java')

// Internal Requirements
const DiscordWrapper          = require('./assets/js/discordwrapper')
const ProcessBuilder          = require('./assets/js/processbuilder')

// Launch Elements
const launch_content          = document.getElementById('launch_content')
const launch_details          = document.getElementById('launch_details')
const launch_progress         = document.getElementById('launch_progress')
const launch_progress_label   = document.getElementById('launch_progress_label')
const launch_details_text     = document.getElementById('launch_details_text')
const server_selection_button = document.getElementById('server_selection_button')
const tower_server_button     = document.getElementById('tower_server_preview')
const launch_target_text      = document.getElementById('launch_target_text')
const selected_world_title    = document.getElementById('selected_world_title')
const selected_world_desc     = document.getElementById('selected_world_description')
const selected_world_tag      = document.getElementById('selected_world_tag')
const user_text               = document.getElementById('user_text')

const loggerLanding = LoggerUtil.getLogger('Landing')

/* Launch Progress Wrapper Functions */

/**
 * Show/hide the loading area.
 * 
 * @param {boolean} loading True if the loading area should be shown, otherwise false.
 */
function toggleLaunchArea(loading){
    if(loading){
        pauseTetrisForLauncher()
        launch_details.style.display = 'flex'
        launch_content.style.display = 'none'
    } else {
        launch_details.style.display = 'none'
        launch_content.style.display = 'inline-flex'
    }
}

/**
 * Set the details text of the loading area.
 * 
 * @param {string} details The new text for the loading details.
 */
function setLaunchDetails(details){
    launch_details_text.innerHTML = details
}

/**
 * Set the value of the loading progress bar and display that value.
 * 
 * @param {number} percent Percentage (0-100)
 */
function setLaunchPercentage(percent){
    launch_progress.setAttribute('max', 100)
    launch_progress.setAttribute('value', percent)
    launch_progress_label.innerHTML = percent + '%'
}

/**
 * Set the value of the OS progress bar and display that on the UI.
 * 
 * @param {number} percent Percentage (0-100)
 */
function setDownloadPercentage(percent){
    remote.getCurrentWindow().setProgressBar(percent/100)
    setLaunchPercentage(percent)
}

/**
 * Enable or disable the launch button.
 * 
 * @param {boolean} val True to enable, false to disable.
 */
function setLaunchEnabled(val){
    document.getElementById('launch_button').disabled = !val
}

// Bind launch button
document.getElementById('launch_button').addEventListener('click', async e => {
    loggerLanding.info('Launching game..')
    try {
        const server = (await DistroAPI.getDistribution()).getServerById(ConfigManager.getSelectedServer())
        const jExe = ConfigManager.getJavaExecutable(ConfigManager.getSelectedServer())
        if(jExe == null){
            await asyncSystemScan(server.effectiveJavaOptions)
        } else {

            setLaunchDetails(Lang.queryJS('landing.launch.pleaseWait'))
            toggleLaunchArea(true)
            setLaunchPercentage(0, 100)

            const details = await validateSelectedJvm(ensureJavaDirIsRoot(jExe), server.effectiveJavaOptions.supported)
            if(details != null){
                loggerLanding.info('Jvm Details', details)
                await dlAsync()

            } else {
                await asyncSystemScan(server.effectiveJavaOptions)
            }
        }
    } catch(err) {
        loggerLanding.error('Unhandled error in during launch process.', err)
        showLaunchFailure(Lang.queryJS('landing.launch.failureTitle'), Lang.queryJS('landing.launch.failureText'))
    }
})

// Bind settings button
document.getElementById('settingsMediaButton').onclick = async e => {
    await prepareSettings()
    switchView(getCurrentView(), VIEWS.settings)
}

// Bind avatar overlay button.
document.getElementById('avatarOverlay').onclick = async e => {
    await prepareSettings()
    switchView(getCurrentView(), VIEWS.settings, 500, 500, () => {
        settingsNavItemListener(document.getElementById('settingsNavAccount'), false)
    })
}

// Bind selected account
function updateSelectedAccount(authUser){
    let username = Lang.queryJS('landing.selectedAccount.noAccountSelected')
    if(authUser != null){
        if(authUser.displayName != null){
            username = authUser.displayName
        }
        if(authUser.uuid != null){
            document.getElementById('avatarContainer').style.backgroundImage = `url('https://mc-heads.net/body/${authUser.uuid}/right')`
        }
    }
    user_text.innerHTML = username
}
updateSelectedAccount(ConfigManager.getSelectedAccount())

// Bind selected server
const LAUNCH_DESTINATIONS = Object.freeze({
    life: {
        name: '생활 서버',
        hostname: 'churworld.kr',
        description: '고양이들과 함께 느긋한 일상을 만들고<br>새로운 인연과 모험을 시작해 보세요.',
        tag: '성인들의 놀이터'
    },
    tower: {
        name: '더타워 서버',
        hostname: 'tower.churworld.kr',
        description: '끝없이 이어지는 탑을 오르며 강력한 적과<br>새로운 보상에 도전해 보세요.',
        tag: '모험 · 도전 콘텐츠'
    }
})

function getSelectedLaunchDestination(){
    const destination = ConfigManager.getSelectedDestination()
    return LAUNCH_DESTINATIONS[destination] != null ? destination : 'life'
}

function updateLaunchDestinationUI(){
    const destination = getSelectedLaunchDestination()
    const destinationInfo = LAUNCH_DESTINATIONS[destination]

    server_selection_button.classList.toggle('churServerCardSelected', destination === 'life')
    tower_server_button.classList.toggle('churServerCardSelected', destination === 'tower')
    launch_target_text.textContent = `${destinationInfo.name}로 바로 접속합니다`
    selected_world_title.textContent = destinationInfo.name
    selected_world_desc.innerHTML = destinationInfo.description
    selected_world_tag.textContent = destinationInfo.tag
}

function getLaunchDestinationConnection(serv){
    const destination = getSelectedLaunchDestination()
    if(destination === 'tower' && serv?.rawServer?.id === 'churworld'){
        return {
            hostname: LAUNCH_DESTINATIONS.tower.hostname,
            port: serv.port
        }
    }
    return {
        hostname: serv.hostname,
        port: serv.port
    }
}

async function selectLaunchDestination(destination){
    ConfigManager.setSelectedDestination(destination)
    ConfigManager.save()
    updateLaunchDestinationUI()
    await refreshServerStatus(true)
}

function updateSelectedServer(serv){
    if(getCurrentView() === VIEWS.settings){
        fullSettingsSave()
    }
    ConfigManager.setSelectedServer(serv != null ? serv.rawServer.id : null)
    ConfigManager.save()
    updateLaunchDestinationUI()
    if(getCurrentView() === VIEWS.settings){
        animateSettingsTabRefresh()
    }
    setLaunchEnabled(serv != null)
}
// Real text is set in uibinder.js on distributionIndexDone.
server_selection_button.onclick = async e => {
    e.currentTarget.blur()
    await selectLaunchDestination('life')
}
tower_server_button.onclick = async e => {
    e.currentTarget.blur()
    await selectLaunchDestination('tower')
}

// Update Mojang Status Color
const refreshMojangStatuses = async function(){
    loggerLanding.info('Refreshing Mojang Statuses..')

    let status = 'grey'
    let tooltipEssentialHTML = ''
    let tooltipNonEssentialHTML = ''

    const response = await MojangRestAPI.status()
    let statuses
    if(response.responseStatus === RestResponseStatus.SUCCESS) {
        statuses = response.data
    } else {
        loggerLanding.warn('Unable to refresh Mojang service status.')
        statuses = MojangRestAPI.getDefaultStatuses()
    }
    
    greenCount = 0
    greyCount = 0

    for(let i=0; i<statuses.length; i++){
        const service = statuses[i]

        const tooltipHTML = `<div class="mojangStatusContainer">
            <span class="mojangStatusIcon" style="color: ${MojangRestAPI.statusToHex(service.status)};">&#8226;</span>
            <span class="mojangStatusName">${service.name}</span>
        </div>`
        if(service.essential){
            tooltipEssentialHTML += tooltipHTML
        } else {
            tooltipNonEssentialHTML += tooltipHTML
        }

        if(service.status === 'yellow' && status !== 'red'){
            status = 'yellow'
        } else if(service.status === 'red'){
            status = 'red'
        } else {
            if(service.status === 'grey'){
                ++greyCount
            }
            ++greenCount
        }

    }

    if(greenCount === statuses.length){
        if(greyCount === statuses.length){
            status = 'grey'
        } else {
            status = 'green'
        }
    }
    
    document.getElementById('mojangStatusEssentialContainer').innerHTML = tooltipEssentialHTML
    document.getElementById('mojangStatusNonEssentialContainer').innerHTML = tooltipNonEssentialHTML
    document.getElementById('mojang_status_icon').style.color = MojangRestAPI.statusToHex(status)
}

const refreshServerStatus = async (fade = false) => {
    loggerLanding.info('Refreshing Server Status')
    const serv = (await DistroAPI.getDistribution()).getServerById(ConfigManager.getSelectedServer())

    let pLabel = Lang.queryJS('landing.serverStatus.server')
    let pVal = Lang.queryJS('landing.serverStatus.offline')

    try {

        const connection = getLaunchDestinationConnection(serv)
        const servStat = await getServerStatus(47, connection.hostname, connection.port)
        console.log(servStat)
        pLabel = Lang.queryJS('landing.serverStatus.players')
        pVal = servStat.players.online + '/' + servStat.players.max

    } catch (err) {
        loggerLanding.warn('Unable to refresh server status, assuming offline.')
        loggerLanding.debug(err)
    }
    if(fade){
        $('#server_status_wrapper').fadeOut(250, () => {
            document.getElementById('landingPlayerLabel').innerHTML = pLabel
            document.getElementById('player_count').innerHTML = pVal
            $('#server_status_wrapper').fadeIn(500)
        })
    } else {
        document.getElementById('landingPlayerLabel').innerHTML = pLabel
        document.getElementById('player_count').innerHTML = pVal
    }
    
}

refreshMojangStatuses()
// Server Status is refreshed in uibinder.js on distributionIndexDone.

// Refresh statuses every hour. The status page itself refreshes every day so...
let mojangStatusListener = setInterval(() => refreshMojangStatuses(true), 60*60*1000)
// Set refresh rate to once every 5 minutes.
let serverStatusListener = setInterval(() => refreshServerStatus(true), 300000)

/**
 * Shows an error overlay, toggles off the launch area.
 * 
 * @param {string} title The overlay title.
 * @param {string} desc The overlay description.
 */
function showLaunchFailure(title, desc){
    setOverlayContent(
        title,
        desc,
        Lang.queryJS('landing.launch.okay')
    )
    setOverlayHandler(null)
    toggleOverlay(true)
    toggleLaunchArea(false)
}

/* System (Java) Scan */

/**
 * Asynchronously scan the system for valid Java installations.
 * 
 * @param {boolean} launchAfter Whether we should begin to launch after scanning. 
 */
async function asyncSystemScan(effectiveJavaOptions, launchAfter = true){

    setLaunchDetails(Lang.queryJS('landing.systemScan.checking'))
    toggleLaunchArea(true)
    setLaunchPercentage(0, 100)

    const jvmDetails = await discoverBestJvmInstallation(
        ConfigManager.getDataDirectory(),
        effectiveJavaOptions.supported
    )

    if(jvmDetails == null) {
        // If the result is null, no valid Java installation was found.
        // Show this information to the user.
        setOverlayContent(
            Lang.queryJS('landing.systemScan.noCompatibleJava'),
            Lang.queryJS('landing.systemScan.installJavaMessage', { 'major': effectiveJavaOptions.suggestedMajor }),
            Lang.queryJS('landing.systemScan.installJava'),
            Lang.queryJS('landing.systemScan.installJavaManually')
        )
        setOverlayHandler(() => {
            setLaunchDetails(Lang.queryJS('landing.systemScan.javaDownloadPrepare'))
            toggleOverlay(false)
            
            try {
                downloadJava(effectiveJavaOptions, launchAfter)
            } catch(err) {
                loggerLanding.error('Unhandled error in Java Download', err)
                showLaunchFailure(Lang.queryJS('landing.systemScan.javaDownloadFailureTitle'), Lang.queryJS('landing.systemScan.javaDownloadFailureText'))
            }
        })
        setDismissHandler(() => {
            $('#overlayContent').fadeOut(250, () => {
                //$('#overlayDismiss').toggle(false)
                setOverlayContent(
                    Lang.queryJS('landing.systemScan.javaRequired', { 'major': effectiveJavaOptions.suggestedMajor }),
                    Lang.queryJS('landing.systemScan.javaRequiredMessage', { 'major': effectiveJavaOptions.suggestedMajor }),
                    Lang.queryJS('landing.systemScan.javaRequiredDismiss'),
                    Lang.queryJS('landing.systemScan.javaRequiredCancel')
                )
                setOverlayHandler(() => {
                    toggleLaunchArea(false)
                    toggleOverlay(false)
                })
                setDismissHandler(() => {
                    toggleOverlay(false, true)

                    asyncSystemScan(effectiveJavaOptions, launchAfter)
                })
                $('#overlayContent').fadeIn(250)
            })
        })
        toggleOverlay(true, true)
    } else {
        // Java installation found, use this to launch the game.
        const javaExec = javaExecFromRoot(jvmDetails.path)
        ConfigManager.setJavaExecutable(ConfigManager.getSelectedServer(), javaExec)
        ConfigManager.save()

        // We need to make sure that the updated value is on the settings UI.
        // Just incase the settings UI is already open.
        settingsJavaExecVal.value = javaExec
        await populateJavaExecDetails(settingsJavaExecVal.value)

        // TODO Callback hell, refactor
        // TODO Move this out, separate concerns.
        if(launchAfter){
            await dlAsync()
        }
    }

}

async function downloadJava(effectiveJavaOptions, launchAfter = true) {

    // TODO Error handling.
    // asset can be null.
    const asset = await latestOpenJDK(
        effectiveJavaOptions.suggestedMajor,
        ConfigManager.getDataDirectory(),
        effectiveJavaOptions.distribution)

    if(asset == null) {
        throw new Error(Lang.queryJS('landing.downloadJava.findJdkFailure'))
    }

    let received = 0
    await downloadFile(asset.url, asset.path, ({ transferred }) => {
        received = transferred
        setDownloadPercentage(Math.trunc((transferred/asset.size)*100))
    })
    setDownloadPercentage(100)

    if(received != asset.size) {
        loggerLanding.warn(`Java Download: Expected ${asset.size} bytes but received ${received}`)
        if(!await validateLocalFile(asset.path, asset.algo, asset.hash)) {
            log.error(`Hashes do not match, ${asset.id} may be corrupted.`)
            // Don't know how this could happen, but report it.
            throw new Error(Lang.queryJS('landing.downloadJava.javaDownloadCorruptedError'))
        }
    }

    // Extract
    // Show installing progress bar.
    remote.getCurrentWindow().setProgressBar(2)

    // Wait for extration to complete.
    const eLStr = Lang.queryJS('landing.downloadJava.extractingJava')
    let dotStr = ''
    setLaunchDetails(eLStr)
    const extractListener = setInterval(() => {
        if(dotStr.length >= 3){
            dotStr = ''
        } else {
            dotStr += '.'
        }
        setLaunchDetails(eLStr + dotStr)
    }, 750)

    const newJavaExec = await extractJdk(asset.path)

    // Extraction complete, remove the loading from the OS progress bar.
    remote.getCurrentWindow().setProgressBar(-1)

    // Extraction completed successfully.
    ConfigManager.setJavaExecutable(ConfigManager.getSelectedServer(), newJavaExec)
    ConfigManager.save()

    clearInterval(extractListener)
    setLaunchDetails(Lang.queryJS('landing.downloadJava.javaInstalled'))

    // TODO Callback hell
    // Refactor the launch functions
    asyncSystemScan(effectiveJavaOptions, launchAfter)

}

// Keep reference to Minecraft Process
let proc
// Is DiscordRPC enabled
let hasRPC = false
// Joined server regex
// Change this if your server uses something different.
const GAME_JOINED_REGEX = /\[.+\]: Sound engine started/
const GAME_LAUNCH_REGEX = /^\[.+\]: (?:MinecraftForge .+ Initialized|ModLauncher .+ starting: .+|Loading Minecraft .+ with Fabric Loader .+)$/
const MIN_LINGER = 5000

async function dlAsync(login = true) {

    // Login parameter is temporary for debug purposes. Allows testing the validation/downloads without
    // launching the game.

    const loggerLaunchSuite = LoggerUtil.getLogger('LaunchSuite')

    setLaunchDetails(Lang.queryJS('landing.dlAsync.loadingServerInfo'))

    let distro

    try {
        distro = await DistroAPI.refreshDistributionOrFallback()
        onDistroRefresh(distro)
    } catch(err) {
        loggerLaunchSuite.error('Unable to refresh distribution index.', err)
        showLaunchFailure(Lang.queryJS('landing.dlAsync.fatalError'), Lang.queryJS('landing.dlAsync.unableToLoadDistributionIndex'))
        return
    }

    const serv = distro.getServerById(ConfigManager.getSelectedServer())

    if(login) {
        if(ConfigManager.getSelectedAccount() == null){
            loggerLanding.error('You must be logged into an account.')
            return
        }
    }

    setLaunchDetails(Lang.queryJS('landing.dlAsync.pleaseWait'))
    toggleLaunchArea(true)
    setLaunchPercentage(0, 100)

    const fullRepairModule = new FullRepair(
        ConfigManager.getCommonDirectory(),
        ConfigManager.getInstanceDirectory(),
        ConfigManager.getLauncherDirectory(),
        ConfigManager.getSelectedServer(),
        DistroAPI.isDevMode()
    )

    fullRepairModule.spawnReceiver()

    fullRepairModule.childProcess.on('error', (err) => {
        loggerLaunchSuite.error('Error during launch', err)
        showLaunchFailure(Lang.queryJS('landing.dlAsync.errorDuringLaunchTitle'), err.message || Lang.queryJS('landing.dlAsync.errorDuringLaunchText'))
    })
    fullRepairModule.childProcess.on('close', (code, _signal) => {
        if(code !== 0){
            loggerLaunchSuite.error(`Full Repair Module exited with code ${code}, assuming error.`)
            showLaunchFailure(Lang.queryJS('landing.dlAsync.errorDuringLaunchTitle'), Lang.queryJS('landing.dlAsync.seeConsoleForDetails'))
        }
    })

    loggerLaunchSuite.info('Validating files.')
    setLaunchDetails(Lang.queryJS('landing.dlAsync.validatingFileIntegrity'))
    let invalidFileCount = 0
    try {
        invalidFileCount = await fullRepairModule.verifyFiles(percent => {
            setLaunchPercentage(percent)
        })
        setLaunchPercentage(100)
    } catch (err) {
        loggerLaunchSuite.error('Error during file validation.')
        showLaunchFailure(Lang.queryJS('landing.dlAsync.errorDuringFileVerificationTitle'), err.displayable || Lang.queryJS('landing.dlAsync.seeConsoleForDetails'))
        return
    }
    

    if(invalidFileCount > 0) {
        loggerLaunchSuite.info('Downloading files.')
        setLaunchDetails(Lang.queryJS('landing.dlAsync.downloadingFiles'))
        setLaunchPercentage(0)
        try {
            await fullRepairModule.download(percent => {
                setDownloadPercentage(percent)
            })
            setDownloadPercentage(100)
        } catch(err) {
            loggerLaunchSuite.error('Error during file download.')
            showLaunchFailure(Lang.queryJS('landing.dlAsync.errorDuringFileDownloadTitle'), err.displayable || Lang.queryJS('landing.dlAsync.seeConsoleForDetails'))
            return
        }
    } else {
        loggerLaunchSuite.info('No invalid files, skipping download.')
    }

    // Remove download bar.
    remote.getCurrentWindow().setProgressBar(-1)

    fullRepairModule.destroyReceiver()

    setLaunchDetails(Lang.queryJS('landing.dlAsync.preparingToLaunch'))

    const mojangIndexProcessor = new MojangIndexProcessor(
        ConfigManager.getCommonDirectory(),
        serv.rawServer.minecraftVersion)
    const distributionIndexProcessor = new DistributionIndexProcessor(
        ConfigManager.getCommonDirectory(),
        distro,
        serv.rawServer.id
    )

    const modLoaderData = await distributionIndexProcessor.loadModLoaderVersionJson(serv)
    const versionData = await mojangIndexProcessor.getVersionJson()

    if(login) {
        const authUser = ConfigManager.getSelectedAccount()
        loggerLaunchSuite.info(`Sending selected account (${authUser.displayName}) to ProcessBuilder.`)
        let pb = new ProcessBuilder(serv, versionData, modLoaderData, authUser, remote.app.getVersion())
        setLaunchDetails(Lang.queryJS('landing.dlAsync.launchingGame'))

        // const SERVER_JOINED_REGEX = /\[.+\]: \[CHAT\] [a-zA-Z0-9_]{1,16} joined the game/
        const SERVER_JOINED_REGEX = new RegExp(`\\[.+\\]: \\[CHAT\\] ${authUser.displayName} joined the game`)

        const onLoadComplete = () => {
            toggleLaunchArea(false)
            if(hasRPC){
                DiscordWrapper.updateDetails(Lang.queryJS('landing.discord.loading'))
                proc.stdout.on('data', gameStateChange)
            }
            proc.stdout.removeListener('data', tempListener)
            proc.stderr.removeListener('data', gameErrorListener)
        }
        const start = Date.now()

        // Attach a temporary listener to the client output.
        // Will wait for a certain bit of text meaning that
        // the client application has started, and we can hide
        // the progress bar stuff.
        const tempListener = function(data){
            if(GAME_LAUNCH_REGEX.test(data.trim())){
                const diff = Date.now()-start
                if(diff < MIN_LINGER) {
                    setTimeout(onLoadComplete, MIN_LINGER-diff)
                } else {
                    onLoadComplete()
                }
            }
        }

        // Listener for Discord RPC.
        const gameStateChange = function(data){
            data = data.trim()
            if(SERVER_JOINED_REGEX.test(data)){
                DiscordWrapper.updateDetails(Lang.queryJS('landing.discord.joined'))
            } else if(GAME_JOINED_REGEX.test(data)){
                DiscordWrapper.updateDetails(Lang.queryJS('landing.discord.joining'))
            }
        }

        const gameErrorListener = function(data){
            data = data.trim()
            if(data.indexOf('Could not find or load main class net.minecraft.launchwrapper.Launch') > -1){
                loggerLaunchSuite.error('Game launch failed, LaunchWrapper was not downloaded properly.')
                showLaunchFailure(Lang.queryJS('landing.dlAsync.errorDuringLaunchTitle'), Lang.queryJS('landing.dlAsync.launchWrapperNotDownloaded'))
            }
        }

        try {
            // Build Minecraft process.
            proc = pb.build()

            // Bind listeners to stdout.
            proc.stdout.on('data', tempListener)
            proc.stderr.on('data', gameErrorListener)

            setLaunchDetails(Lang.queryJS('landing.dlAsync.doneEnjoyServer'))

            // Init Discord Hook
            if(distro.rawDistribution.discord != null && serv.rawServer.discord != null){
                DiscordWrapper.initRPC(distro.rawDistribution.discord, serv.rawServer.discord)
                hasRPC = true
                proc.on('close', (code, signal) => {
                    loggerLaunchSuite.info('Shutting down Discord Rich Presence..')
                    DiscordWrapper.shutdownRPC()
                    hasRPC = false
                    proc = null
                })
            }

        } catch(err) {

            loggerLaunchSuite.error('Error during launch', err)
            showLaunchFailure(Lang.queryJS('landing.dlAsync.errorDuringLaunchTitle'), Lang.queryJS('landing.dlAsync.checkConsoleForDetails'))

        }
    }

}

/**
 * News Loading Functions
 */

// DOM Cache
const newsContent                   = document.getElementById('newsContent')
const newsArticleTitle              = document.getElementById('newsArticleTitle')
const newsArticleDate               = document.getElementById('newsArticleDate')
const newsArticleAuthor             = document.getElementById('newsArticleAuthor')
const newsArticleComments           = document.getElementById('newsArticleComments')
const newsNavigationStatus          = document.getElementById('newsNavigationStatus')
const newsArticleContentScrollable  = document.getElementById('newsArticleContentScrollable')
const nELoadSpan                    = document.getElementById('nELoadSpan')

// News panel state.
let newsActive = false
let minigameActive = false

/**
 * Show or hide the news UI without moving the launcher layout.
 * 
 * @param {boolean} up True to show the news panel, otherwise false.
 */
function slide_(up){
    const landingContainer = document.getElementById('landingContainer')
    const newsContainer = document.querySelector('#landingContainer > #newsContainer')
    newsContainer.classList.toggle('newsActive', up)
    newsContainer.setAttribute('aria-hidden', String(!up))
    landingContainer.classList.toggle('newsPanelActive', up)
}

// Bind news button.
document.getElementById('newsButton').onclick = () => {
    // Toggle tabbing.
    if(newsActive){
        $('#landingContainer *').removeAttr('tabindex')
        $('#newsContainer *').attr('tabindex', '-1')
    } else {
        $('#landingContainer *').attr('tabindex', '-1')
        $('#newsContainer, #newsContainer *, #lower, #lower #center *').removeAttr('tabindex')
        if(newsAlertShown){
            $('#newsButtonAlert').fadeOut(2000)
            newsAlertShown = false
            ConfigManager.setNewsCacheDismissed(true)
            ConfigManager.save()
        }
    }
    slide_(!newsActive)
    newsActive = !newsActive
}

// Always provide an obvious way back, including when the news feed fails.
document.getElementById('newsBackButton').onclick = () => {
    if(newsActive){
        document.getElementById('newsButton').click()
    }
}

// Array to store article meta.
let newsArr = null

// News load animation listener.
let newsLoadingListener = null

/**
 * Set the news loading animation.
 * 
 * @param {boolean} val True to set loading animation, otherwise false.
 */
function setNewsLoading(val){
    if(val){
        const nLStr = Lang.queryJS('landing.news.checking')
        let dotStr = '..'
        nELoadSpan.innerHTML = nLStr + dotStr
        newsLoadingListener = setInterval(() => {
            if(dotStr.length >= 3){
                dotStr = ''
            } else {
                dotStr += '.'
            }
            nELoadSpan.innerHTML = nLStr + dotStr
        }, 750)
    } else {
        if(newsLoadingListener != null){
            clearInterval(newsLoadingListener)
            newsLoadingListener = null
        }
    }
}

// Bind retry button.
newsErrorRetry.onclick = () => {
    $('#newsErrorFailed').fadeOut(250, () => {
        initNews()
        $('#newsErrorLoading').fadeIn(250)
    })
}

newsArticleContentScrollable.onscroll = (e) => {
    if(e.target.scrollTop > Number.parseFloat($('.newsArticleSpacerTop').css('height'))){
        newsContent.setAttribute('scrolled', '')
    } else {
        newsContent.removeAttribute('scrolled')
    }
}

/**
 * Reload the news without restarting.
 * 
 * @returns {Promise.<void>} A promise which resolves when the news
 * content has finished loading and transitioning.
 */
function reloadNews(){
    return new Promise((resolve, reject) => {
        $('#newsContent').fadeOut(250, () => {
            $('#newsErrorLoading').fadeIn(250)
            initNews().then(() => {
                resolve()
            })
        })
    })
}

let newsAlertShown = false

/**
 * Show the news alert indicating there is new news.
 */
function showNewsAlert(){
    newsAlertShown = true
    $(newsButtonAlert).fadeIn(250)
}

async function digestMessage(str) {
    const msgUint8 = new TextEncoder().encode(str)
    const hashBuffer = await crypto.subtle.digest('SHA-1', msgUint8)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const hashHex = hashArray
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('')
    return hashHex
}

/**
 * Initialize News UI. This will load the news and prepare
 * the UI accordingly.
 * 
 * @returns {Promise.<void>} A promise which resolves when the news
 * content has finished loading and transitioning.
 */
async function initNews(){

    setNewsLoading(true)

    const news = await loadNews()

    newsArr = news?.articles || null

    if(newsArr == null){
        // News Loading Failed
        setNewsLoading(false)

        await $('#newsErrorLoading').fadeOut(250).promise()
        await $('#newsErrorFailed').fadeIn(250).promise()

    } else if(newsArr.length === 0) {
        // No News Articles
        setNewsLoading(false)

        ConfigManager.setNewsCache({
            date: null,
            content: null,
            dismissed: false
        })
        ConfigManager.save()

        await $('#newsErrorLoading').fadeOut(250).promise()
        await $('#newsErrorNone').fadeIn(250).promise()
    } else {
        // Success
        setNewsLoading(false)

        const lN = newsArr[0]
        const cached = ConfigManager.getNewsCache()
        let newHash = await digestMessage(lN.content)
        let newDate = new Date(lN.date)
        let isNew = false

        if(cached.date != null && cached.content != null){

            if(new Date(cached.date) >= newDate){

                // Compare Content
                if(cached.content !== newHash){
                    isNew = true
                    showNewsAlert()
                } else {
                    if(!cached.dismissed){
                        isNew = true
                        showNewsAlert()
                    }
                }

            } else {
                isNew = true
                showNewsAlert()
            }

        } else {
            isNew = true
            showNewsAlert()
        }

        if(isNew){
            ConfigManager.setNewsCache({
                date: newDate.getTime(),
                content: newHash,
                dismissed: false
            })
            ConfigManager.save()
        }

        const switchHandler = (forward) => {
            let cArt = parseInt(newsContent.getAttribute('article'))
            let nxtArt = forward ? (cArt >= newsArr.length-1 ? 0 : cArt + 1) : (cArt <= 0 ? newsArr.length-1 : cArt - 1)
    
            displayArticle(newsArr[nxtArt], nxtArt+1)
        }

        document.getElementById('newsNavigateRight').onclick = () => { switchHandler(true) }
        document.getElementById('newsNavigateLeft').onclick = () => { switchHandler(false) }
        await $('#newsErrorContainer').fadeOut(250).promise()
        displayArticle(newsArr[0], 1)
        await $('#newsContent').fadeIn(250).promise()
    }


}

/**
 * Add keyboard controls to the news UI. Left and right arrows toggle
 * between articles. If you are on the landing page, the up arrow will
 * open the news UI.
 */
document.addEventListener('keydown', (e) => {
    if(minigameActive){
        return
    }
    if(newsActive){
        if(e.key === 'ArrowRight' || e.key === 'ArrowLeft'){
            document.getElementById(e.key === 'ArrowRight' ? 'newsNavigateRight' : 'newsNavigateLeft').click()
        }
        // Interferes with scrolling an article using the down arrow.
        // Not sure of a straight forward solution at this point.
        // if(e.key === 'ArrowDown'){
        //     document.getElementById('newsButton').click()
        // }
    } else {
        if(getCurrentView() === VIEWS.landing){
            if(e.key === 'ArrowUp'){
                document.getElementById('newsButton').click()
            }
        }
    }
})

/**
 * Display a news article on the UI.
 * 
 * @param {Object} articleObject The article meta object.
 * @param {number} index The article index.
 */
function displayArticle(articleObject, index){
    newsArticleTitle.innerHTML = articleObject.title
    newsArticleTitle.href = articleObject.link
    newsArticleAuthor.innerHTML = 'by ' + articleObject.author
    newsArticleDate.innerHTML = articleObject.date
    newsArticleComments.innerHTML = articleObject.comments
    newsArticleComments.href = articleObject.commentsLink
    newsArticleContentScrollable.innerHTML = '<div id="newsArticleContentWrapper"><div class="newsArticleSpacerTop"></div>' + articleObject.content + '<div class="newsArticleSpacerBot"></div></div>'
    Array.from(newsArticleContentScrollable.getElementsByClassName('bbCodeSpoilerButton')).forEach(v => {
        v.onclick = () => {
            const text = v.parentElement.getElementsByClassName('bbCodeSpoilerText')[0]
            text.style.display = text.style.display === 'block' ? 'none' : 'block'
        }
    })
    newsNavigationStatus.innerHTML = Lang.query('ejs.landing.newsNavigationStatus', {currentPage: index, totalPages: newsArr.length})
    newsContent.setAttribute('article', index-1)
}

/**
 * Load news information from the RSS feed specified in the
 * distribution index.
 */
async function loadNews(){

    const distroData = await DistroAPI.getDistribution()
    if(!distroData.rawDistribution.rss) {
        loggerLanding.debug('No RSS feed provided.')
        return null
    }

    const promise = new Promise((resolve, reject) => {
        
        const newsFeed = distroData.rawDistribution.rss
        const newsHost = new URL(newsFeed).origin + '/'
        $.ajax({
            url: newsFeed,
            success: (data) => {
                const items = $(data).find('item')
                const articles = []

                for(let i=0; i<items.length; i++){
                // JQuery Element
                    const el = $(items[i])

                    // Resolve date.
                    const date = new Date(el.find('pubDate').text()).toLocaleDateString('en-US', {month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: 'numeric'})

                    // Resolve comments.
                    let comments = el.find('slash\\:comments').text() || '0'
                    comments = comments + ' Comment' + (comments === '1' ? '' : 's')

                    // Fix relative links in content.
                    let content = el.find('content\\:encoded').text()
                    let regex = /src="(?!http:\/\/|https:\/\/)(.+?)"/g
                    let matches
                    while((matches = regex.exec(content))){
                        content = content.replace(`"${matches[1]}"`, `"${newsHost + matches[1]}"`)
                    }

                    let link   = el.find('link').text()
                    let title  = el.find('title').text()
                    let author = el.find('dc\\:creator').text()

                    // Generate article.
                    articles.push(
                        {
                            link,
                            title,
                            date,
                            author,
                            content,
                            comments,
                            commentsLink: link + '#comments'
                        }
                    )
                }
                resolve({
                    articles
                })
            },
            timeout: 2500
        }).catch(err => {
            resolve({
                articles: null
            })
        })
    })

    return await promise
}

/**
 * ChurWorld Mini-game Hub and Tetris
 */
const minigameContainer   = document.getElementById('minigameContainer')
const minigameHub         = document.getElementById('minigameHub')
const tetrisGameView      = document.getElementById('tetrisGameView')
const tetrisCanvas        = document.getElementById('tetrisCanvas')
const tetrisContext       = tetrisCanvas.getContext('2d')
const tetrisOverlay       = document.getElementById('tetrisOverlay')
const tetrisOverlayTitle  = document.getElementById('tetrisOverlayTitle')
const tetrisOverlayText   = document.getElementById('tetrisOverlayText')
const tetrisScoreText     = document.getElementById('tetrisScore')
const tetrisHighScoreText = document.getElementById('tetrisHighScore')
const tetrisLinesText     = document.getElementById('tetrisLines')
const tetrisLevelText     = document.getElementById('tetrisLevel')
const tetrisStartButton   = document.getElementById('tetrisStartButton')
const tetrisPauseButton   = document.getElementById('tetrisPauseButton')

const TETRIS_COLUMNS = 10
const TETRIS_ROWS = 20
const TETRIS_BLOCK_SIZE = 20
const TETRIS_HIGH_SCORE_KEY = 'churworldTetrisHighScore'
const TETRIS_SHAPES = Object.freeze({
    I: [[1, 1, 1, 1]],
    J: [[1, 0, 0], [1, 1, 1]],
    L: [[0, 0, 1], [1, 1, 1]],
    O: [[1, 1], [1, 1]],
    S: [[0, 1, 1], [1, 1, 0]],
    T: [[0, 1, 0], [1, 1, 1]],
    Z: [[1, 1, 0], [0, 1, 1]]
})
const TETRIS_COLORS = Object.freeze({
    I: '#73c7cf',
    J: '#7f9ddd',
    L: '#f2a16f',
    O: '#efca69',
    S: '#79bb8e',
    T: '#b490d0',
    Z: '#ec7f7a'
})

let tetrisBoard = createTetrisBoard()
let tetrisPiece = null
let tetrisBag = []
let tetrisScore = 0
let tetrisLines = 0
let tetrisLevel = 1
let tetrisHighScore = readTetrisHighScore()
let tetrisRunning = false
let tetrisPaused = false
let tetrisLastDrop = 0
let tetrisAnimationFrame = null

function createTetrisBoard(){
    return Array.from({ length: TETRIS_ROWS }, () => Array(TETRIS_COLUMNS).fill(null))
}

function readTetrisHighScore(){
    const storedScore = Number.parseInt(localStorage.getItem(TETRIS_HIGH_SCORE_KEY), 10)
    return Number.isFinite(storedScore) ? storedScore : 0
}

function saveTetrisHighScore(){
    if(tetrisScore <= tetrisHighScore){
        return
    }
    tetrisHighScore = tetrisScore
    localStorage.setItem(TETRIS_HIGH_SCORE_KEY, String(tetrisHighScore))
}

function shuffleTetrisBag(){
    const bag = Object.keys(TETRIS_SHAPES)
    for(let index = bag.length - 1; index > 0; index--){
        const swapIndex = Math.floor(Math.random() * (index + 1))
        const current = bag[index]
        bag[index] = bag[swapIndex]
        bag[swapIndex] = current
    }
    return bag
}

function getNextTetrisType(){
    if(tetrisBag.length === 0){
        tetrisBag = shuffleTetrisBag()
    }
    return tetrisBag.pop()
}

function spawnTetrisPiece(){
    const type = getNextTetrisType()
    const matrix = TETRIS_SHAPES[type].map(row => [...row])
    tetrisPiece = {
        type,
        matrix,
        x: Math.floor((TETRIS_COLUMNS - matrix[0].length) / 2),
        y: 0
    }

    if(tetrisCollides(tetrisPiece.matrix, tetrisPiece.x, tetrisPiece.y)){
        finishTetrisGame()
    }
}

function tetrisCollides(matrix, offsetX, offsetY){
    for(let row = 0; row < matrix.length; row++){
        for(let column = 0; column < matrix[row].length; column++){
            if(matrix[row][column] === 0){
                continue
            }
            const boardX = offsetX + column
            const boardY = offsetY + row
            if(boardX < 0 || boardX >= TETRIS_COLUMNS || boardY >= TETRIS_ROWS){
                return true
            }
            if(boardY >= 0 && tetrisBoard[boardY][boardX] != null){
                return true
            }
        }
    }
    return false
}

function drawTetrisCell(x, y, color, alpha = 1){
    const inset = 1.2
    tetrisContext.globalAlpha = alpha
    tetrisContext.fillStyle = color
    tetrisContext.fillRect(
        x * TETRIS_BLOCK_SIZE + inset,
        y * TETRIS_BLOCK_SIZE + inset,
        TETRIS_BLOCK_SIZE - inset * 2,
        TETRIS_BLOCK_SIZE - inset * 2
    )
    tetrisContext.fillStyle = 'rgba(255, 255, 255, 0.23)'
    tetrisContext.fillRect(
        x * TETRIS_BLOCK_SIZE + 3,
        y * TETRIS_BLOCK_SIZE + 3,
        TETRIS_BLOCK_SIZE - 6,
        2
    )
    tetrisContext.globalAlpha = 1
}

function drawTetrisMatrix(matrix, offsetX, offsetY, color, alpha = 1){
    matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if(value !== 0 && offsetY + y >= 0){
                drawTetrisCell(offsetX + x, offsetY + y, color, alpha)
            }
        })
    })
}

function getTetrisGhostY(){
    if(tetrisPiece == null){
        return 0
    }
    let ghostY = tetrisPiece.y
    while(!tetrisCollides(tetrisPiece.matrix, tetrisPiece.x, ghostY + 1)){
        ghostY++
    }
    return ghostY
}

function drawTetris(){
    tetrisContext.fillStyle = '#171319'
    tetrisContext.fillRect(0, 0, tetrisCanvas.width, tetrisCanvas.height)

    tetrisContext.strokeStyle = 'rgba(255, 255, 255, 0.035)'
    tetrisContext.lineWidth = 1
    for(let column = 1; column < TETRIS_COLUMNS; column++){
        tetrisContext.beginPath()
        tetrisContext.moveTo(column * TETRIS_BLOCK_SIZE + 0.5, 0)
        tetrisContext.lineTo(column * TETRIS_BLOCK_SIZE + 0.5, tetrisCanvas.height)
        tetrisContext.stroke()
    }
    for(let row = 1; row < TETRIS_ROWS; row++){
        tetrisContext.beginPath()
        tetrisContext.moveTo(0, row * TETRIS_BLOCK_SIZE + 0.5)
        tetrisContext.lineTo(tetrisCanvas.width, row * TETRIS_BLOCK_SIZE + 0.5)
        tetrisContext.stroke()
    }

    tetrisBoard.forEach((row, y) => {
        row.forEach((color, x) => {
            if(color != null){
                drawTetrisCell(x, y, color)
            }
        })
    })

    if(tetrisPiece != null){
        const color = TETRIS_COLORS[tetrisPiece.type]
        const ghostY = getTetrisGhostY()
        if(ghostY !== tetrisPiece.y){
            drawTetrisMatrix(tetrisPiece.matrix, tetrisPiece.x, ghostY, color, 0.18)
        }
        drawTetrisMatrix(tetrisPiece.matrix, tetrisPiece.x, tetrisPiece.y, color)
    }
}

function updateTetrisStats(){
    tetrisScoreText.textContent = tetrisScore.toLocaleString('ko-KR')
    tetrisHighScoreText.textContent = Math.max(tetrisScore, tetrisHighScore).toLocaleString('ko-KR')
    tetrisLinesText.textContent = tetrisLines.toLocaleString('ko-KR')
    tetrisLevelText.textContent = tetrisLevel.toLocaleString('ko-KR')
}

function showTetrisOverlay(title, text){
    tetrisOverlayTitle.textContent = title
    tetrisOverlayText.textContent = text
    tetrisOverlay.style.display = 'flex'
}

function hideTetrisOverlay(){
    tetrisOverlay.style.display = 'none'
}

function clearCompletedTetrisLines(){
    let cleared = 0
    tetrisBoard = tetrisBoard.filter(row => {
        if(row.every(cell => cell != null)){
            cleared++
            return false
        }
        return true
    })

    while(tetrisBoard.length < TETRIS_ROWS){
        tetrisBoard.unshift(Array(TETRIS_COLUMNS).fill(null))
    }

    if(cleared > 0){
        const scoreTable = [0, 40, 100, 300, 1200]
        tetrisScore += scoreTable[cleared] * tetrisLevel
        tetrisLines += cleared
        tetrisLevel = Math.floor(tetrisLines / 10) + 1
        saveTetrisHighScore()
        updateTetrisStats()
    }
}

function lockTetrisPiece(){
    if(tetrisPiece == null){
        return
    }
    const color = TETRIS_COLORS[tetrisPiece.type]
    tetrisPiece.matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if(value !== 0 && tetrisPiece.y + y >= 0){
                tetrisBoard[tetrisPiece.y + y][tetrisPiece.x + x] = color
            }
        })
    })
    clearCompletedTetrisLines()
    spawnTetrisPiece()
}

function moveTetrisPiece(horizontal, vertical, awardSoftDrop = false){
    if(!tetrisRunning || tetrisPaused || tetrisPiece == null){
        return false
    }
    const nextX = tetrisPiece.x + horizontal
    const nextY = tetrisPiece.y + vertical
    if(tetrisCollides(tetrisPiece.matrix, nextX, nextY)){
        if(vertical > 0){
            lockTetrisPiece()
        }
        drawTetris()
        return false
    }
    tetrisPiece.x = nextX
    tetrisPiece.y = nextY
    if(awardSoftDrop && vertical > 0){
        tetrisScore++
        saveTetrisHighScore()
        updateTetrisStats()
    }
    drawTetris()
    return true
}

function rotateTetrisPiece(){
    if(!tetrisRunning || tetrisPaused || tetrisPiece == null){
        return
    }
    const rotated = tetrisPiece.matrix[0].map((value, index) => (
        tetrisPiece.matrix.map(row => row[index]).reverse()
    ))
    const originalX = tetrisPiece.x
    for(const kick of [0, -1, 1, -2, 2]){
        if(!tetrisCollides(rotated, originalX + kick, tetrisPiece.y)){
            tetrisPiece.matrix = rotated
            tetrisPiece.x = originalX + kick
            drawTetris()
            return
        }
    }
}

function hardDropTetrisPiece(){
    if(!tetrisRunning || tetrisPaused || tetrisPiece == null){
        return
    }
    let distance = 0
    while(!tetrisCollides(tetrisPiece.matrix, tetrisPiece.x, tetrisPiece.y + 1)){
        tetrisPiece.y++
        distance++
    }
    tetrisScore += distance * 2
    saveTetrisHighScore()
    updateTetrisStats()
    lockTetrisPiece()
    drawTetris()
}

function finishTetrisGame(){
    tetrisRunning = false
    tetrisPaused = false
    saveTetrisHighScore()
    updateTetrisStats()
    tetrisPauseButton.disabled = true
    tetrisPauseButton.textContent = '일시정지'
    tetrisStartButton.textContent = '다시 시작'
    showTetrisOverlay('게임 종료', `점수 ${tetrisScore.toLocaleString('ko-KR')}점`)
}

function runTetrisFrame(timestamp){
    if(!tetrisRunning){
        tetrisAnimationFrame = null
        return
    }
    if(!tetrisPaused){
        const dropInterval = Math.max(110, 820 - (tetrisLevel - 1) * 65)
        if(timestamp - tetrisLastDrop >= dropInterval){
            moveTetrisPiece(0, 1)
            tetrisLastDrop = timestamp
        }
    }
    tetrisAnimationFrame = requestAnimationFrame(runTetrisFrame)
}

function startTetrisGame(){
    if(tetrisAnimationFrame != null){
        cancelAnimationFrame(tetrisAnimationFrame)
    }
    tetrisBoard = createTetrisBoard()
    tetrisBag = []
    tetrisPiece = null
    tetrisScore = 0
    tetrisLines = 0
    tetrisLevel = 1
    tetrisRunning = true
    tetrisPaused = false
    tetrisLastDrop = performance.now()
    tetrisStartButton.textContent = '다시 시작'
    tetrisPauseButton.disabled = false
    tetrisPauseButton.textContent = '일시정지'
    hideTetrisOverlay()
    updateTetrisStats()
    spawnTetrisPiece()
    drawTetris()
    tetrisAnimationFrame = requestAnimationFrame(runTetrisFrame)
}

function toggleTetrisPause(forcePause = false){
    if(!tetrisRunning){
        return
    }
    tetrisPaused = forcePause ? true : !tetrisPaused
    tetrisPauseButton.textContent = tetrisPaused ? '계속하기' : '일시정지'
    if(tetrisPaused){
        showTetrisOverlay('잠시 멈춤', '계속하기 또는 P 키를 눌러주세요')
    } else {
        tetrisLastDrop = performance.now()
        hideTetrisOverlay()
    }
}

function pauseTetrisForLauncher(){
    if(tetrisRunning && !tetrisPaused){
        toggleTetrisPause(true)
    }
}

function showMinigameHub(){
    pauseTetrisForLauncher()
    tetrisGameView.style.display = 'none'
    minigameHub.style.display = 'block'
}

function openMinigameHub(){
    if(newsActive){
        document.getElementById('newsButton').click()
    }
    minigameActive = true
    minigameContainer.classList.add('minigameActive')
    minigameContainer.setAttribute('aria-hidden', 'false')
    showMinigameHub()
    document.getElementById('minigameCloseButton').focus()
}

function closeMinigameHub(){
    pauseTetrisForLauncher()
    minigameActive = false
    minigameContainer.classList.remove('minigameActive')
    minigameContainer.setAttribute('aria-hidden', 'true')
    document.getElementById('minigameButton').focus()
}

document.getElementById('minigameButton').onclick = openMinigameHub
document.getElementById('minigameCloseButton').onclick = closeMinigameHub
document.getElementById('tetrisGameCard').onclick = () => {
    minigameHub.style.display = 'none'
    tetrisGameView.style.display = 'block'
    drawTetris()
    tetrisStartButton.focus()
}
document.getElementById('tetrisBackButton').onclick = showMinigameHub
tetrisStartButton.onclick = startTetrisGame
tetrisPauseButton.onclick = () => toggleTetrisPause()

document.querySelectorAll('[data-tetris-action]').forEach(button => {
    button.onclick = () => {
        const action = button.getAttribute('data-tetris-action')
        if(action === 'left'){
            moveTetrisPiece(-1, 0)
        } else if(action === 'right'){
            moveTetrisPiece(1, 0)
        } else if(action === 'rotate'){
            rotateTetrisPiece()
        } else if(action === 'down'){
            moveTetrisPiece(0, 1, true)
        } else if(action === 'drop'){
            hardDropTetrisPiece()
        }
    }
})

document.addEventListener('keydown', event => {
    if(!minigameActive || tetrisGameView.style.display === 'none'){
        return
    }

    const key = event.key.toLowerCase()
    const handledKeys = ['arrowleft', 'arrowright', 'arrowup', 'arrowdown', 'a', 'd', 'w', 's', 'p', ' ']
    if(handledKeys.includes(key)){
        event.preventDefault()
    }

    if(key === 'arrowleft' || key === 'a'){
        moveTetrisPiece(-1, 0)
    } else if(key === 'arrowright' || key === 'd'){
        moveTetrisPiece(1, 0)
    } else if(key === 'arrowup' || key === 'w'){
        rotateTetrisPiece()
    } else if(key === 'arrowdown' || key === 's'){
        moveTetrisPiece(0, 1, true)
    } else if(key === ' '){
        hardDropTetrisPiece()
    } else if(key === 'p'){
        toggleTetrisPause()
    } else if(key === 'escape'){
        showMinigameHub()
    }
})

updateTetrisStats()
drawTetris()
