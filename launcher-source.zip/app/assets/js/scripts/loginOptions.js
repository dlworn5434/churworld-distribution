const loginOptionsCancelContainer = document.getElementById('loginOptionCancelContainer')
const loginOptionMicrosoft = document.getElementById('loginOptionMicrosoft')
const loginOptionMojang = document.getElementById('loginOptionMojang')
const loginOptionsCancelButton = document.getElementById('loginOptionCancelButton')
const loginOptionBrowser = document.getElementById('loginOptionBrowser')
const loginOptionActions = document.getElementById('loginOptionActions')
const browserLoginPanel = document.getElementById('browserLoginPanel')
const browserLoginStatus = document.getElementById('browserLoginStatus')
const browserLoginNotice = document.getElementById('browserLoginNotice')
const browserLoginComplete = document.getElementById('browserLoginComplete')
const browserLoginReopen = document.getElementById('browserLoginReopen')
const browserLoginCancel = document.getElementById('browserLoginCancel')
const browserLoginAccounts = typeof window !== 'undefined' ? window.launcher?.accounts : null

let browserLoginPending = false
let browserLoginId = null
let browserLoginStage = ''
let browserLoginActionBusy = false
let browserLoginCancelling = false
const browserLoginRetiredIds = new Set()
const browserLoginStatusText = Object.freeze({
    opening_browser: '브라우저를 여는 중입니다…',
    waiting_for_browser: '로그인을 마친 뒤 브라우저의 주소를 복사해 주세요.',
    exchanging_token: '로그인 결과를 확인하고 있습니다…',
    checking_account: '마인크래프트 계정을 확인하고 있습니다…',
    complete: '로그인이 완료되었습니다.',
    cancelled: '브라우저 로그인을 취소했습니다.',
    error: '로그인을 완료하지 못했습니다. 다시 시도해 주세요.'
})

let loginOptionsCancellable = false

let loginOptionsViewOnLoginSuccess
let loginOptionsViewOnLoginCancel
let loginOptionsViewOnCancel
let loginOptionsViewCancelHandler

function loginOptionsCancelEnabled(val){
    loginOptionsCancellable = Boolean(val)
    if(loginOptionsCancellable && !browserLoginPending){
        $(loginOptionsCancelContainer).show()
    } else {
        $(loginOptionsCancelContainer).hide()
    }
}

function renderBrowserLoginUI(){
    loginOptionMicrosoft.disabled = browserLoginPending
    loginOptionBrowser.disabled = browserLoginPending
    loginOptionActions.hidden = browserLoginPending
    browserLoginPanel.hidden = !browserLoginPending
    browserLoginNotice.hidden = browserLoginPending
    const waiting = browserLoginId !== null && browserLoginStage === 'waiting_for_browser'
    browserLoginComplete.disabled = !waiting || browserLoginActionBusy || browserLoginCancelling
    browserLoginReopen.disabled = !waiting || browserLoginActionBusy || browserLoginCancelling
    browserLoginCancel.disabled = !browserLoginId || browserLoginCancelling || ['complete', 'cancelled', 'error'].includes(browserLoginStage)
    browserLoginPanel.setAttribute('aria-busy', String(browserLoginActionBusy || browserLoginCancelling))
    loginOptionsCancelEnabled(loginOptionsCancellable)
}

function resetBrowserLoginUI(expectedId){
    if(expectedId !== undefined && browserLoginId !== expectedId) return
    if(browserLoginId){
        browserLoginRetiredIds.add(browserLoginId)
        if(browserLoginRetiredIds.size > 32) browserLoginRetiredIds.delete(browserLoginRetiredIds.values().next().value)
    }
    browserLoginPending = false
    browserLoginId = null
    browserLoginStage = ''
    browserLoginActionBusy = false
    browserLoginCancelling = false
    renderBrowserLoginUI()
}

function onBrowserLoginStatus(event){
    if(!browserLoginPending || !event || typeof event.id !== 'string' || !/^[a-f0-9]{32}$/.test(event.id)) return
    if(typeof event.status !== 'string' || !Object.hasOwn(browserLoginStatusText, event.status)) return
    if(browserLoginId === null){
        if(event.status !== 'opening_browser' || browserLoginRetiredIds.has(event.id)) return
        browserLoginId = event.id
    }
    if(event.id !== browserLoginId) return
    browserLoginStage = event.status
    browserLoginStatus.textContent = browserLoginStatusText[event.status]
    if(['complete', 'cancelled', 'error'].includes(event.status)){
        browserLoginNotice.textContent = browserLoginStatusText[event.status]
    }
    renderBrowserLoginUI()
}

if(typeof browserLoginAccounts?.onBrowserLoginStatus === 'function'){
    browserLoginAccounts.onBrowserLoginStatus(onBrowserLoginStatus)
}

if(typeof launcherPlatform !== 'undefined' && launcherPlatform === 'darwin'){
    document.getElementById('browserLoginCopyShortcut').textContent = '⌘+L → ⌘+C'
}

loginOptionBrowser.onclick = () => {
    if(browserLoginPending) return
    if(typeof browserLoginAccounts?.completeBrowserLogin !== 'function'){
        showAuthFailure({code: 'AUTH_BROWSER_CONFIG_REQUIRED'})
        return
    }
    browserLoginPending = true
    browserLoginStage = 'opening_browser'
    browserLoginStatus.textContent = browserLoginStatusText.opening_browser
    browserLoginNotice.textContent = ''
    renderBrowserLoginUI()
    try {
        ipcRenderer.send(MSFT_OPCODE.OPEN_BROWSER_LOGIN, loginOptionsViewOnLoginSuccess, loginOptionsViewOnLoginCancel)
    } catch(error) {
        resetBrowserLoginUI()
        showAuthFailure(error)
    }
}

async function runBrowserLoginAction(action){
    if(!browserLoginPending || !browserLoginId || browserLoginCancelling) return
    if(['complete', 'cancelled', 'error'].includes(browserLoginStage)) return
    const id = browserLoginId
    let cancelAccepted = false
    if(action !== 'cancelBrowserLogin' && (browserLoginActionBusy || browserLoginStage !== 'waiting_for_browser')) return
    if(action === 'cancelBrowserLogin'){
        browserLoginCancelling = true
        browserLoginStatus.textContent = '로그인을 취소하는 중입니다…'
    } else {
        browserLoginActionBusy = true
    }
    renderBrowserLoginUI()
    try {
        await browserLoginAccounts[action](id)
        if(action === 'cancelBrowserLogin') cancelAccepted = true
    } catch(error) {
        if(browserLoginId === id && browserLoginPending && !browserLoginCancelling) showAuthFailure(error)
        else if(browserLoginId === id && action === 'cancelBrowserLogin') showAuthFailure(error)
    } finally {
        if(browserLoginId === id && browserLoginPending){
            if(action !== 'cancelBrowserLogin') browserLoginActionBusy = false
            if(action === 'cancelBrowserLogin' && !cancelAccepted) browserLoginCancelling = false
            browserLoginStatus.textContent = browserLoginCancelling && !['complete', 'cancelled', 'error'].includes(browserLoginStage)
                ? '로그인을 취소하는 중입니다…' : browserLoginStatusText[browserLoginStage]
            renderBrowserLoginUI()
        }
    }
}

browserLoginComplete.onclick = () => runBrowserLoginAction('completeBrowserLogin')
browserLoginReopen.onclick = () => runBrowserLoginAction('reopenBrowserLogin')
browserLoginCancel.onclick = () => runBrowserLoginAction('cancelBrowserLogin')

loginOptionMicrosoft.onclick = (e) => {
    if(browserLoginPending) return
    switchView(getCurrentView(), VIEWS.waiting, 500, 500, () => {
        ipcRenderer.send(
            MSFT_OPCODE.OPEN_LOGIN,
            loginOptionsViewOnLoginSuccess,
            loginOptionsViewOnLoginCancel
        )
    })
}

if(loginOptionMojang) {
    loginOptionMojang.onclick = (e) => loginOptionMicrosoft.onclick(e)
}

loginOptionsCancelButton.onclick = (e) => {
    if(browserLoginPending) return
    switchView(getCurrentView(), loginOptionsViewOnCancel, 500, 500, () => {
        // Clear login values (Mojang login)
        // No cleanup needed for Microsoft.
        loginUsername.value = ''
        loginPassword.value = ''
        if(loginOptionsViewCancelHandler != null){
            loginOptionsViewCancelHandler()
            loginOptionsViewCancelHandler = null
        }
    })
}
