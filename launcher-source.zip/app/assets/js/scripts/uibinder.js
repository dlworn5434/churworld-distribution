/**
 * Initialize UI functions which depend on internal modules.
 * Loaded after core UI functions are initialized in uicore.js.
 */
// Requirements







let rscShouldLoad = false
let fatalStartupError = false

// Mapping of each view to their container IDs.
const VIEWS = {
    landing: '#landingContainer',
    loginOptions: '#loginOptionsContainer',
    login: '#loginContainer',
    settings: '#settingsContainer',
    welcome: '#welcomeContainer',
    waiting: '#waitingContainer'
}

// The currently shown view container.
let currentView

/**
 * Switch launcher views.
 * 
 * @param {string} current The ID of the current view container. 
 * @param {*} next The ID of the next view container.
 * @param {*} currentFadeTime Optional. The fade out time for the current view.
 * @param {*} nextFadeTime Optional. The fade in time for the next view.
 * @param {*} onCurrentFade Optional. Callback function to execute when the current
 * view fades out.
 * @param {*} onNextFade Optional. Callback function to execute when the next view
 * fades in.
 */
function switchView(current, next, currentFadeTime = 500, nextFadeTime = 500, onCurrentFade = () => {}, onNextFade = () => {}){
    currentView = next
    $(`${current}`).fadeOut(currentFadeTime, async () => {
        await onCurrentFade()
        $(`${next}`).fadeIn(nextFadeTime, async () => {
            await onNextFade()
        })
    })
}

/**
 * Get the currently shown view container.
 * 
 * @returns {string} The currently shown view container.
 */
function getCurrentView(){
    return currentView
}

async function showMainUI(data){

    if(!isDev){
        loggerAutoUpdater.info('Initializing..')
        ipcRenderer.send('autoUpdateAction', 'initAutoUpdater', ConfigManager.getAllowPrerelease())
    }

    await prepareSettings(true)
    updateSelectedServer(data.getServerById(ConfigManager.getSelectedServer()))
    refreshServerStatus()
    setTimeout(() => {
        document.getElementById('frameBar').style.backgroundColor = 'rgba(0, 0, 0, 0.5)'
        document.body.style.backgroundImage = `url('assets/images/backgrounds/${document.body.getAttribute('bkid')}.jpg')`
        $('#main').show()

        const isLoggedIn = Object.keys(ConfigManager.getAuthAccounts()).length > 0

        // If this is enabled in a development environment we'll get ratelimited.
        // The relaunch frequency is usually far too high.
        if(!isDev && isLoggedIn){
            validateSelectedAccount()
        }

        if(ConfigManager.isFirstLaunch()){
            currentView = VIEWS.welcome
            $(VIEWS.welcome).fadeIn(1000)
        } else {
            if(isLoggedIn){
                currentView = VIEWS.landing
                $(VIEWS.landing).fadeIn(1000)
            } else {
                loginOptionsCancelEnabled(false)
                loginOptionsViewOnLoginSuccess = VIEWS.landing
                loginOptionsViewOnLoginCancel = VIEWS.loginOptions
                currentView = VIEWS.loginOptions
                $(VIEWS.loginOptions).fadeIn(1000)
            }
        }

        setTimeout(() => {
            $('#loadingContainer').fadeOut(500, () => {
                $('#loadSpinnerImage').removeClass('rotating')
            })
        }, 250)
        
    }, 750)
    // Disable tabbing to the news container.
    initNews().then(() => {
        $('#newsContainer *').attr('tabindex', '-1')
    })
}

function showFatalStartupError(){
    setTimeout(() => {
        $('#loadingContainer').fadeOut(250, () => {
            document.getElementById('overlayContainer').style.background = 'none'
            setOverlayContent(
                Lang.queryJS('uibinder.startup.fatalErrorTitle'),
                Lang.queryJS('uibinder.startup.fatalErrorMessage'),
                Lang.queryJS('uibinder.startup.closeButton'),
                '진단 정보 저장'
            )
            setOverlayHandler(() => {
                const window = windowControls
                window.close()
            })
            setDismissHandler(() => window.launcher.diagnostics.export().catch(() => {}))
            toggleOverlay(true, true)
        })
    }, 750)
}

/**
 * Common functions to perform after refreshing the distro index.
 * 
 * @param {Object} data The distro index object.
 */
function onDistroRefresh(data){
    updateSelectedServer(data.getServerById(ConfigManager.getSelectedServer()))
    refreshServerStatus()
    initNews()
}

/**
 * Sync the mod configurations with the distro index.
 * 
 * @param {Object} data The distro index object.
 */


/**
 * Ensure java configurations are present for the available servers.
 * 
 * @param {Object} data The distro index object.
 */


/**
 * Recursively scan for optional sub modules. If none are found,
 * this function returns a boolean. If optional sub modules do exist,
 * a recursive configuration object is returned.
 * 
 * @returns {boolean | Object} The resolved mod configuration.
 */


/**
 * Recursively merge an old configuration into a new configuration.
 * 
 * @param {boolean | Object} o The old configuration value.
 * @param {boolean | Object} n The new configuration value.
 * @param {boolean} nReq If the new value is a required mod.
 * 
 * @returns {boolean | Object} The merged configuration.
 */


function authFailureDetails(error) {
    const messages = {
        AUTH_TEMPORARY_FAILURE: '인증 서버에 잠시 연결할 수 없습니다. 계정은 유지됩니다. 잠시 후 다시 시도해 주세요.',
        AUTH_STORAGE_FAILURE: '로그인 정보를 안전하게 저장하지 못했습니다. 계정은 유지됩니다. 저장 공간과 권한을 확인한 뒤 다시 시도해 주세요.',
        AUTH_INVALID_RESPONSE: '인증 서버의 응답을 확인하지 못했습니다. 계정은 유지됩니다. 잠시 후 다시 시도해 주세요.',
        AUTH_REAUTH_REQUIRED: 'Microsoft 로그인을 다시 진행해 주세요. 취소해도 저장된 계정은 삭제되지 않습니다.',
        AUTH_LEGACY_DISABLED: '이전 Mojang 비밀번호 로그인은 지원하지 않습니다. Microsoft로 다시 로그인해 주세요.',
        AUTH_ACCOUNT_ACTION_REQUIRED: 'Minecraft 보유 여부 또는 Xbox 계정 설정을 확인해 주세요. 저장된 계정은 유지됩니다.'
    }
    const code = error?.code === 'AUTH_STATE_CHANGED' ? 'AUTH_STATE_CHANGED'
        : Object.prototype.hasOwnProperty.call(messages, error?.code) ? error.code
            : typeof error?.code === 'string' && error.code.startsWith('CONFIG_') ? 'AUTH_STORAGE_FAILURE'
                : 'AUTH_TEMPORARY_FAILURE'
    return { code, title: '로그인 확인', desc: messages[code] }
}

function showAuthFailure(error) {
    const details = authFailureDetails(error)
    if(details.code === 'AUTH_STATE_CHANGED') return
    setOverlayContent(details.title, details.desc, '확인')
    setOverlayHandler(() => toggleOverlay(false))
    toggleOverlay(true)
}

function showAccountReauthentication() {
    setOverlayContent('Microsoft 로그인이 필요합니다',
        'Microsoft 로그인을 다시 진행해 주세요. 취소해도 저장된 계정은 삭제되지 않습니다.',
        'Microsoft 로그인', '취소')
    setOverlayHandler(() => {
        const returnView = getCurrentView()
        loginOptionsViewOnLoginSuccess = returnView
        loginOptionsViewOnLoginCancel = VIEWS.loginOptions
        loginOptionsViewOnCancel = returnView
        loginOptionsViewCancelHandler = null
        loginOptionsCancelEnabled(true)
        toggleOverlay(false)
        switchView(returnView, VIEWS.loginOptions)
    })
    setDismissHandler(() => toggleOverlay(false))
    toggleOverlay(true, true)
}

async function validateSelectedAccount(){
    const selectedAcc = ConfigManager.getSelectedAccount()
    if(selectedAcc == null) {
        showAccountReauthentication()
        return false
    }
    try {
        const valid = await AuthManager.validateSelected()
        // A completed check must never act on a different selection.
        if(ConfigManager.getSelectedAccount()?.uuid !== selectedAcc.uuid) return false
        if(valid === true) return true
        showAccountReauthentication()
    } catch(error) {
        if(ConfigManager.getSelectedAccount()?.uuid === selectedAcc.uuid) showAuthFailure(error)
    }
    return false
}

/**
 * Temporary function to update the selected account along
 * with the relevent UI elements.
 * 
 * @param {string} uuid The UUID of the account.
 */
function setSelectedAccount(uuid){
    try {
        const authAcc = ConfigManager.transactionAuth(() => ConfigManager.setSelectedAccount(uuid))
        updateSelectedAccount(authAcc)
        validateSelectedAccount()
        return true
    } catch(error) {
        showAuthFailure(error)
        return false
    }
}

// Start only after all preserved UI scripts and elements are ready.
window.addEventListener('DOMContentLoaded', async () => {
    try { await showMainUI(await DistroAPI.getDistribution()) }
    catch { fatalStartupError = true; showFatalStartupError() }
}, {once: true})
