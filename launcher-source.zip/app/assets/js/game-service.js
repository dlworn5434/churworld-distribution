'use strict'
const {downloadFile} = require('helios-core/dl')
const {TrustedRepair} = require('./trusted-repair')
const {validateLocalFile} = require('helios-core/common')
const Java = require('helios-core/java')
const {LoggerUtil} = require('helios-core')
const ConfigManager = require('./configmanager')
const AuthManager = require('./authmanager')
const ProcessBuilder = require('./processbuilder')
const DiscordWrapper = require('./discordwrapper')
const {AuthError} = require('./auth-errors')
const Lang = require('./langloader')
const path = require('node:path')

function createGameService({distribution, version, emit, approvedPaths, dependencies = {}}) {
    const Repair = dependencies.TrustedRepair || TrustedRepair
    const Builder = dependencies.ProcessBuilder || ProcessBuilder
    const auth = dependencies.AuthManager || AuthManager
    const java = dependencies.Java || Java
    const log = LoggerUtil.getLogger('GameService')
    let busy = false
    const server = async () => (await distribution.DistroAPI.getDistribution()).getServerById(ConfigManager.getSelectedServer())
    const state = (type, value) => emit({type, value})
    const details = key => state('details', Lang.queryJS(key))
    function selected(snapshot) {
        if(ConfigManager.getSelectedAccount()?.uuid !== snapshot.uuid || ConfigManager.getAuthRevision() !== snapshot.revision
            || ConfigManager.getSelectedServer() !== snapshot.server || ConfigManager.getSelectedDestination() !== snapshot.destination
            || ConfigManager.getDataDirectory() !== snapshot.directory) throw new AuthError('AUTH_STATE_CHANGED')
    }
    const capture = () => ({uuid: ConfigManager.getSelectedAccount()?.uuid, revision: ConfigManager.getAuthRevision(),
        server: ConfigManager.getSelectedServer(), destination: ConfigManager.getSelectedDestination(), directory: ConfigManager.getDataDirectory()})
    async function validate() {
        if(!await auth.validateSelected()) throw new AuthError('AUTH_REAUTH_REQUIRED')
    }
    async function scanJava() {
        if(busy) throw new Error('Game preparation is already running')
        busy = true
        try {
        const serv = await server()
        const originalServer = ConfigManager.getSelectedServer()
        const originalDirectory = ConfigManager.getDataDirectory()
        const current = ConfigManager.getJavaExecutable(serv.rawServer.id)
        if(current) {
            const found = await java.validateSelectedJvm(java.ensureJavaDirIsRoot(current), serv.effectiveJavaOptions.supported)
            if(found) return {path: current, details: found}
        }
        const found = await java.discoverBestJvmInstallation(ConfigManager.getDataDirectory(), serv.effectiveJavaOptions.supported)
        if(!found) return null
        if(ConfigManager.getSelectedServer() !== originalServer || ConfigManager.getDataDirectory() !== originalDirectory) throw new AuthError('AUTH_STATE_CHANGED')
        const executable = java.javaExecFromRoot(found.path)
        approvedPaths.add(executable)
        ConfigManager.setJavaExecutable(serv.rawServer.id, executable)
        ConfigManager.save()
        return {path: executable, details: found}
        } finally { busy = false }
    }
    async function checkJava(file) {
        const serv = await server()
        if(typeof file !== 'string' || !path.isAbsolute(file)
            || (file !== ConfigManager.getJavaExecutable(serv.rawServer.id) && !approvedPaths.has(file))) return null
        return java.validateSelectedJvm(java.ensureJavaDirIsRoot(file), serv.effectiveJavaOptions.supported)
    }
    async function installJava() {
        if(busy) throw new Error('Game preparation is already running')
        busy = true
        try {
            const distro = await distribution.DistroAPI.getDistribution()
            if(distribution.DistroAPI.isOfflineOnly?.(distro)) throw new Error('Offline Java installation unavailable')
            const serv = await server()
            const asset = await java.latestOpenJDK(serv.effectiveJavaOptions.suggestedMajor,
                ConfigManager.getDataDirectory(), serv.effectiveJavaOptions.distribution)
            if(!asset) throw new Error('Compatible Java download unavailable')
            details('landing.systemScan.javaDownloadPrepare')
            let received = 0
            await downloadFile(asset.url, asset.path, ({transferred}) => {
                received = transferred
                state('progress', Math.min(100, Math.floor(100 * transferred / asset.size)))
            })
            // Verify every completed download, including same-sized corrupt responses.
            if(received !== asset.size || !await validateLocalFile(asset.path, asset.algo, asset.hash)) throw new Error('Java verification failed')
            details('landing.downloadJava.extractingJava')
            const executable = await java.extractJdk(asset.path)
            approvedPaths.add(executable)
            ConfigManager.setJavaExecutable(serv.rawServer.id, executable)
            ConfigManager.save()
            return {path: executable}
        } finally { busy = false }
    }
    async function launch() {
        if(busy) throw new Error('Game preparation is already running')
        busy = true
        let update, repair
        try {
            await validate()
            let snapshot = capture()
            update = await distribution.beginManagedUpdate()
            details('landing.dlAsync.loadingServerInfo')
            const distro = await distribution.DistroAPI.refreshDistributionOrFallback()
            selected(snapshot)
            const synchronization = require('./configuration-sync')
            synchronization.syncModConfigurations(distro)
            synchronization.ensureJavaSettings(distro)
            state('distribution', distro)
            const serv = distro.getServerById(snapshot.server)
            if(!serv) throw new Error('Selected server unavailable')
            if(typeof distribution.DistroAPI.prepareServerFiles !== 'function') throw new Error('Signed distribution verifier unavailable')
            if(distribution.DistroAPI.isOfflineOnly(distro)) state('details', '업데이트 확인을 완료하지 못해 기존 설치 파일을 확인합니다.')
            else details('landing.dlAsync.downloadingFiles')
            await distribution.DistroAPI.prepareServerFiles(distro, serv.rawServer.id, progress => state('progress', progress?.percent ?? progress))
            selected(snapshot)
            repair = new Repair({commonDirectory: ConfigManager.getCommonDirectory(), instanceDirectory: ConfigManager.getInstanceDirectory(),
                launcherDirectory: ConfigManager.getLauncherDirectory(), serverId: serv.rawServer.id, distribution: distro,
                offlineOnly: distribution.DistroAPI.isOfflineOnly(distro)})
            repair.spawnReceiver()
            repair.childProcess.on('error', () => state('error', 'GAME_REPAIR_FAILED'))
            details('landing.dlAsync.validatingFileIntegrity')
            const invalid = await repair.verifyFiles(percent => state('progress', percent))
            if(invalid > 0) {
                details('landing.dlAsync.downloadingFiles')
                await repair.download(percent => state('progress', percent))
                if(await repair.verifyFiles(() => {}) !== 0) throw new Error('Downloaded files failed verification')
            }
            const {vanilla, mod} = await repair.getLaunchMetadata()
            repair.destroyReceiver()
            repair = null
            selected(snapshot)
            details('landing.dlAsync.preparingToLaunch')
            selected(snapshot)
            await validate()
            // Refresh can legitimately replace the selected token and increment revision.
            if(ConfigManager.getSelectedAccount()?.uuid !== snapshot.uuid
                || ConfigManager.getSelectedServer() !== snapshot.server
                || ConfigManager.getSelectedDestination() !== snapshot.destination
                || ConfigManager.getDataDirectory() !== snapshot.directory) throw new AuthError('AUTH_STATE_CHANGED')
            snapshot = {...snapshot, revision: ConfigManager.getAuthRevision()}
            const account = ConfigManager.getSelectedAccount()
            const builder = new Builder(serv, vanilla, mod, account, version)
            details('landing.dlAsync.launchingGame')
            const child = await distribution.launchWithManagedMods(distro, serv.rawServer.id, () => {
                selected(snapshot)
                return builder.build()
            }, update)
            if(child.churuSpawnFailed) throw new Error('Minecraft process could not be started')
            const launched = /(?:MinecraftForge .+ Initialized|ModLauncher .+ starting:|Loading Minecraft .+ with Fabric Loader)/
            const loaded = data => { if(launched.test(String(data))) state('loaded', true) }
            child.stdout.on('data', loaded)
            child.stderr.on('data', data => {
                if(String(data).includes('Could not find or load main class net.minecraft.launchwrapper.Launch')) state('error', 'GAME_LAUNCH_FAILED')
            })
            child.on('error', () => state('error', 'GAME_LAUNCH_FAILED'))
            child.on('close', () => { state('loaded', true); if(distro.rawDistribution.discord && serv.rawServer.discord) DiscordWrapper.shutdownRPC() })
            if(distro.rawDistribution.discord && serv.rawServer.discord) {
                DiscordWrapper.initRPC(distro.rawDistribution.discord, serv.rawServer.discord)
                child.stdout.on('data', data => {
                    const line = String(data)
                    if(line.includes(account.displayName + ' joined the game')) DiscordWrapper.updateDetails(Lang.queryJS('landing.discord.joined'))
                    else if(line.includes('Sound engine started')) DiscordWrapper.updateDetails(Lang.queryJS('landing.discord.joining'))
                })
            }
            details('landing.dlAsync.doneEnjoyServer')
            return true
        } catch(error) {
            log.warn('Game preparation did not complete.')
            throw error
        } finally {
            if(repair) repair.destroyReceiver()
            if(update) update.finish()
            busy = false
        }
    }
    return {scanJava, checkJava, installJava, launch, isBusy: () => busy}
}

module.exports = {createGameService}
