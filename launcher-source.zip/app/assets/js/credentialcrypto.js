'use strict'

const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { spawn } = require('node:child_process')

const PROBE_FLAG = '--churu-credential-key-probe'
const PROFILE_PREFIX = '--churu-credential-key-profile='
const OWNER_KIND = 'churu-credential-key-probe-v1'
const MARKER_SCHEMA = 1
const MAX_STATE_BYTES = 4 * 1024 * 1024
const MAX_MARKER_BYTES = 4096

function storageError(code) {
    const error = new Error('Secure credential storage is not ready. Existing account data was preserved.')
    error.code = code
    return error
}

function samePath(a, b) {
    const normalize = value => process.platform === 'win32' ? path.resolve(value).toLowerCase() : path.resolve(value)
    return normalize(a) === normalize(b)
}

function plainDirectory(directory, create = false) {
    if(create && !fs.existsSync(directory)) fs.mkdirSync(directory, { recursive: true, mode: 0o700 })
    const stat = fs.lstatSync(directory)
    if(!stat.isDirectory() || stat.isSymbolicLink() || !samePath(fs.realpathSync(directory), directory)) {
        throw storageError('CREDENTIAL_UNSAFE_PATH')
    }
}

function plainFile(file, maximum) {
    const before = fs.lstatSync(file)
    if(!before.isFile() || before.isSymbolicLink() || before.size > maximum || !samePath(fs.realpathSync(file), file)) {
        throw storageError('CREDENTIAL_UNSAFE_PATH')
    }
    const fd = fs.openSync(file, 'r')
    try {
        const current = fs.fstatSync(fd)
        if(current.dev !== before.dev || current.ino !== before.ino || current.size > maximum) {
            throw storageError('CREDENTIAL_UNSAFE_PATH')
        }
        return fs.readFileSync(fd, 'utf8')
    } finally {
        fs.closeSync(fd)
    }
}

function keySnapshot(file) {
    const parsed = JSON.parse(plainFile(file, MAX_STATE_BYTES))
    const key = parsed && parsed.os_crypt && parsed.os_crypt.encrypted_key
    if(typeof key !== 'string' || key.length < 16 || key.length > 16384) return null
    const decoded = Buffer.from(key, 'base64')
    if(decoded.toString('base64') !== key || decoded.subarray(0, 5).toString('ascii') !== 'DPAPI') return null
    return { key, digest: crypto.createHash('sha256').update(key).digest('hex') }
}

function readSnapshot(file) {
    try {
        return keySnapshot(file)
    } catch(error) {
        if(error.code === 'CREDENTIAL_UNSAFE_PATH') throw error
        return null
    }
}

function flushMatchingKey(file, expectedDigest) {
    const before = fs.lstatSync(file)
    if(!before.isFile() || before.isSymbolicLink() || !samePath(fs.realpathSync(file), file)) {
        throw storageError('CREDENTIAL_UNSAFE_PATH')
    }
    const fd = fs.openSync(file, 'r+')
    try {
        const opened = fs.fstatSync(fd)
        if(opened.dev !== before.dev || opened.ino !== before.ino) return false
        fs.fsyncSync(fd)
        const after = fs.lstatSync(file)
        if(after.dev !== opened.dev || after.ino !== opened.ino) return false
    } finally {
        fs.closeSync(fd)
    }
    return readSnapshot(file)?.digest === expectedDigest
}

function nonceMatches(safeStorage, nonce, ciphertext) {
    if(typeof nonce !== 'string' || !/^[0-9a-f]{64}$/.test(nonce)
        || typeof ciphertext !== 'string' || ciphertext.length > 1024) return false
    const encoded = Buffer.from(ciphertext, 'base64')
    if(encoded.toString('base64') !== ciphertext) return false
    try { return safeStorage.decryptString(encoded) === nonce } catch { return false }
}

function cachedProof(markerPath, snapshot, safeStorage) {
    try {
        const marker = JSON.parse(plainFile(markerPath, MAX_MARKER_BYTES))
        return marker.schema === MARKER_SCHEMA && marker.keyDigest === snapshot.digest
            && nonceMatches(safeStorage, marker.nonce, marker.ciphertext)
    } catch(error) {
        if(error.code === 'CREDENTIAL_UNSAFE_PATH') throw error
        return false
    }
}

function saveProof(markerPath, marker) {
    if(fs.existsSync(markerPath)) plainFile(markerPath, MAX_MARKER_BYTES)
    const temporary = `${markerPath}.${crypto.randomBytes(16).toString('hex')}.tmp`
    let fd
    try {
        fd = fs.openSync(temporary, 'wx', 0o600)
        fs.writeFileSync(fd, JSON.stringify(marker))
        fs.fsyncSync(fd)
        fs.closeSync(fd)
        fd = undefined
        if(fs.existsSync(markerPath)) plainFile(markerPath, MAX_MARKER_BYTES)
        fs.renameSync(temporary, markerPath)
    } finally {
        if(fd !== undefined) fs.closeSync(fd)
        if(fs.existsSync(temporary)) fs.unlinkSync(temporary)
    }
}

function ownedWorkspace(userData) {
    const root = path.join(userData, '.credential-key-probe')
    plainDirectory(root, true)
    const id = crypto.randomBytes(16).toString('hex')
    const work = path.join(root, `probe-${id}`)
    fs.mkdirSync(work, { mode: 0o700 })
    const profile = path.join(work, 'profile')
    fs.mkdirSync(profile, { mode: 0o700 })
    const owner = { kind: OWNER_KIND, id, profile }
    fs.writeFileSync(path.join(work, 'owner.json'), JSON.stringify(owner), { flag: 'wx', mode: 0o600 })
    return { root, work, profile, owner }
}

function cleanupWorkspace(workspace) {
    // Never derive a recursive target from child output or delete the shared root.
    const { root, work, profile, owner } = workspace
    plainDirectory(root)
    plainDirectory(work)
    if(!samePath(path.dirname(work), root) || path.basename(work) !== `probe-${owner.id}`
        || !samePath(profile, path.join(work, 'profile'))) throw storageError('CREDENTIAL_UNSAFE_PATH')
    const recorded = JSON.parse(plainFile(path.join(work, 'owner.json'), 4096))
    if(recorded.kind !== OWNER_KIND || recorded.id !== owner.id || !samePath(recorded.profile, profile)) {
        throw storageError('CREDENTIAL_UNSAFE_PATH')
    }
    fs.rmSync(work, { recursive: true, force: true })
}

async function probeDiskKey({ app, probeExecutable, probeEntry, userData, snapshot, nonce, ciphertext, remainingMs }) {
    const workspace = ownedWorkspace(userData)
    try {
        fs.writeFileSync(path.join(workspace.profile, 'Local State'), JSON.stringify({
            os_crypt: { encrypted_key: snapshot.key, audit_enabled: true }
        }), { flag: 'wx', mode: 0o600 })
        const executable = probeExecutable || process.execPath
        const entry = probeEntry === undefined ? (app.isPackaged ? null : app.getAppPath()) : probeEntry
        const args = entry ? [entry] : []
        // Only a random, non-credential proof travels in argv. Windows Electron GUI
        // executables do not reliably expose inherited stdin to the main process.
        const proof = Buffer.from(JSON.stringify({ schema: 1, nonce, ciphertext })).toString('base64')
        args.push(PROBE_FLAG, `${PROFILE_PREFIX}${workspace.profile}`, `--churu-credential-key-challenge=${proof}`)
        const environment = { ...process.env }
        delete environment.ELECTRON_RUN_AS_NODE
        delete environment.NODE_OPTIONS
        delete environment.NODE_PATH
        return await new Promise((resolve, reject) => {
            let child
            let response = ''
            let failed = false
            let done = false
            let timer
            const finish = (error, value) => {
                if(done) return
                done = true
                clearTimeout(timer)
                if(error) reject(error)
                else resolve(value)
            }
            try {
                child = spawn(executable, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'], env: environment })
            } catch {
                finish(storageError('CREDENTIAL_KEY_PROBE_FAILED'))
                return
            }
            timer = setTimeout(() => { failed = true; child.kill() }, Math.min(8000, remainingMs))
            child.stdout.on('data', chunk => {
                response += chunk.toString('utf8')
                if(response.length > 1024) { failed = true; child.kill() }
            })
            child.once('error', () => finish(storageError('CREDENTIAL_KEY_PROBE_FAILED')))
            child.once('close', code => {
                let accepted = false
                try { accepted = !failed && code === 0 && JSON.parse(response).ok === true } catch {}
                finish(null, accepted)
            })
        })
    } finally {
        cleanupWorkspace(workspace)
    }
}

async function prepareCredentialCrypto({ app, safeStorage, probeExecutable, probeEntry, timeoutMs = 30000 }) {
    if(!app || !safeStorage || !app.isReady()) throw storageError('CREDENTIAL_APP_NOT_READY')
    if(!Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 30000) throw storageError('CREDENTIAL_INVALID_TIMEOUT')
    if(!['win32', 'darwin', 'linux'].includes(process.platform)) {
        throw storageError('CREDENTIAL_UNSUPPORTED_PLATFORM')
    }
    if(process.platform === 'linux') {
        // Only an OS secret-store backend is acceptable; basic_text is not encryption at rest.
        let backend
        try { backend = safeStorage.getSelectedStorageBackend?.() } catch {}
        if(!['gnome_libsecret', 'kwallet', 'kwallet5', 'kwallet6'].includes(backend)) {
            throw storageError('CREDENTIAL_UNSUPPORTED_BACKEND')
        }
    }
    if(!safeStorage.isEncryptionAvailable()) throw storageError('CREDENTIAL_ENCRYPTION_UNAVAILABLE')
    const nonce = crypto.randomBytes(32).toString('hex')
    let ciphertext
    try {
        ciphertext = safeStorage.encryptString(nonce).toString('base64')
        if(!nonceMatches(safeStorage, nonce, ciphertext)) throw new Error('round trip')
    } catch {
        throw storageError('CREDENTIAL_ENCRYPTION_UNAVAILABLE')
    }
    let assertPreparedKey = () => {}
    if(process.platform === 'win32') {
        const userData = path.resolve(app.getPath('userData'))
        const sessionData = path.resolve(app.getPath('sessionData'))
        plainDirectory(userData)
        plainDirectory(sessionData)
        const statePath = path.join(sessionData, 'Local State')
        const markerPath = path.join(userData, 'credential-key-proof.json')
        const deadline = Date.now() + timeoutMs
        let rejectedDigest = null
        let prepared = false
        let preparedDigest = null
        while(Date.now() < deadline) {
            const snapshot = readSnapshot(statePath)
            if(snapshot) {
                if(cachedProof(markerPath, snapshot, safeStorage) && flushMatchingKey(statePath, snapshot.digest)) {
                    prepared = true
                    preparedDigest = snapshot.digest
                    break
                }
                if(snapshot.digest !== rejectedDigest) {
                    const proved = await probeDiskKey({ app, probeExecutable, probeEntry, userData, snapshot,
                        nonce, ciphertext, remainingMs: Math.max(1, deadline - Date.now()) })
                    if(proved && flushMatchingKey(statePath, snapshot.digest)) {
                        saveProof(markerPath, { schema: MARKER_SCHEMA, keyDigest: snapshot.digest, nonce, ciphertext })
                        if(readSnapshot(statePath)?.digest === snapshot.digest) {
                            prepared = true
                            preparedDigest = snapshot.digest
                            break
                        }
                    } else {
                        rejectedDigest = snapshot.digest
                    }
                }
            }
            await new Promise(resolve => setTimeout(resolve, Math.min(200, Math.max(1, deadline - Date.now()))))
        }
        if(!prepared) throw storageError('CREDENTIAL_KEY_NOT_DURABLE')
        assertPreparedKey = () => {
            if(readSnapshot(statePath)?.digest !== preparedDigest) throw storageError('CREDENTIAL_KEY_CHANGED')
        }
    }
    return Object.freeze({
        encryptString(value) {
            assertPreparedKey()
            let result
            try { result = safeStorage.encryptString(value) }
            catch { throw storageError('CREDENTIAL_ENCRYPT_FAILED') }
            assertPreparedKey()
            return result
        },
        decryptString(value) {
            assertPreparedKey()
            let result
            try { result = safeStorage.decryptString(value) }
            catch { throw storageError('CREDENTIAL_DECRYPT_FAILED') }
            assertPreparedKey()
            return result
        }
    })
}

module.exports = { prepareCredentialCrypto }
