// Main-process persistence. Runtime credentials never become the disk schema.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')

const FORMAT = 'churworld-protected-config'
const VERSION = 1
const LIMIT = 16 * 1024 * 1024
const clone = value => JSON.parse(JSON.stringify(value))
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value)

class ConfigStorageError extends Error {
    constructor(code) {
        super('로그인 정보 또는 설정을 안전하게 읽거나 저장하지 못했습니다. 기존 파일은 보존됩니다.')
        this.name = 'ConfigStorageError'
        this.code = code
    }
}

function assertConfig(value) {
    if(!record(value) || !record(value.settings) || !record(value.authenticationDatabase)) {
        throw new ConfigStorageError('CONFIG_INVALID')
    }
    if(value.selectedAccount != null && typeof value.selectedAccount !== 'string') throw new ConfigStorageError('CONFIG_INVALID')
    for(const [id, account] of Object.entries(value.authenticationDatabase)) {
        if(!record(account) || account.uuid !== id || !['microsoft', 'mojang', undefined].includes(account.type)) {
            throw new ConfigStorageError('CONFIG_INVALID_ACCOUNT')
        }
    }
}

function readRegular(file) {
    const info = fs.lstatSync(file)
    if(!info.isFile() || info.isSymbolicLink() || info.size > LIMIT) throw new ConfigStorageError('CONFIG_INVALID_FILE')
    return fs.readFileSync(file)
}

function digest(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex') }

function mergeDefaults(defaults, current) {
    for(const [key, value] of Object.entries(defaults)) {
        if(current[key] === undefined) current[key] = clone(value)
        else if(record(value) && !['authenticationDatabase', 'javaConfig'].includes(key)) {
            if(!record(current[key])) throw new ConfigStorageError('CONFIG_INVALID')
            mergeDefaults(value, current[key])
        }
    }
    return current
}

function syncDirectory(dir) {
    // Windows does not support opening directories through Node for fsync.
    if(process.platform === 'win32') return
    let fd
    try { fd = fs.openSync(dir, 'r'); fs.fsyncSync(fd) } finally { if(fd !== undefined) fs.closeSync(fd) }
}

function atomicWrite(file, bytes) {
    const dir = path.dirname(file)
    const temp = path.join(dir, `.${path.basename(file)}.${crypto.randomUUID()}.tmp`)
    let fd
    let committed = false
    try {
        fd = fs.openSync(temp, 'wx', 0o600)
        fs.writeFileSync(fd, bytes)
        if(process.platform !== 'win32') fs.fchmodSync(fd, 0o600)
        fs.fsyncSync(fd)
        fs.closeSync(fd)
        fd = undefined
        fs.renameSync(temp, file)
        committed = true
        // The rename is the commit point. A later directory-flush error must
        // never be reported as a rejected transaction and roll memory back.
        try { syncDirectory(dir) } catch { return {committed: true, durable: false} }
        return {committed: true, durable: true}
    } finally {
        if(fd !== undefined) fs.closeSync(fd)
        if(!committed) {
            // A failed cleanup must not replace the original write error. The
            // temporary file contains only encrypted data and has mode 0600.
            try { fs.unlinkSync(temp) } catch { /* Retry is safe; primary was not replaced. */ }
        }
    }
}

class ProtectedConfigStore {
    constructor({directory, legacyPath, encryption}) {
        this.file = path.join(directory, 'config.json')
        this.previousFile = path.join(directory, 'config.protected.previous.json')
        this.legacyPath = legacyPath
        this.encryption = encryption
        this.revision = 0
        this.expectedDigest = null
        this.loaded = false
        this.snapshot = null
        this.firstLaunch = false
        this.warning = null
        this.legacyCleanupDigest = null
    }

    decode(bytes) {
        let disk
        try { disk = JSON.parse(bytes.toString('utf8')) } catch { throw new ConfigStorageError('CONFIG_CORRUPT') }
        if(!record(disk)) throw new ConfigStorageError('CONFIG_INVALID')
        if(disk.protectedConfig !== undefined) {
            const header = disk.protectedConfig
            if(!record(header) || header.format !== FORMAT || header.version !== VERSION) throw new ConfigStorageError('CONFIG_UNSUPPORTED_VERSION')
            if(header.legacyCleanupDigest !== undefined && !/^[a-f0-9]{64}$/.test(header.legacyCleanupDigest)) throw new ConfigStorageError('CONFIG_CORRUPT')
            this.legacyCleanupDigest = header.legacyCleanupDigest || null
            if(!record(disk.authenticationDatabase) || Object.keys(disk.authenticationDatabase).length !== 0 || disk.clientToken != null || disk.selectedAccount != null) {
                // An old launcher may have written new plaintext credentials. Never
                // discard either generation or silently pick one on a downgrade.
                throw new ConfigStorageError('CONFIG_MIXED_VERSIONS')
            }
            if(typeof header.ciphertext !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(header.ciphertext)) throw new ConfigStorageError('CONFIG_CORRUPT')
            let auth
            try {
                const decoded = this.encryption.decryptString(Buffer.from(header.ciphertext, 'base64'))
                auth = JSON.parse(decoded)
            } catch { throw new ConfigStorageError('CONFIG_KEY_UNAVAILABLE') }
            if(!record(auth) || auth.format !== FORMAT || auth.version !== VERSION) throw new ConfigStorageError('CONFIG_CORRUPT')
            disk.authenticationDatabase = auth.authenticationDatabase
            disk.selectedAccount = auth.selectedAccount
            disk.clientToken = auth.clientToken
            delete disk.protectedConfig
        }
        assertConfig(disk)
        return disk
    }

    encode(runtime) {
        const disk = clone(runtime)
        assertConfig(disk)
        delete disk.protectedConfig
        const auth = {
            format: FORMAT, version: VERSION,
            authenticationDatabase: disk.authenticationDatabase,
            selectedAccount: disk.selectedAccount,
            clientToken: disk.clientToken
        }
        let ciphertext
        try { ciphertext = this.encryption.encryptString(JSON.stringify(auth)).toString('base64') }
        catch { throw new ConfigStorageError('CONFIG_KEY_UNAVAILABLE') }
        disk.authenticationDatabase = {}
        disk.selectedAccount = null
        disk.clientToken = null
        disk.protectedConfig = {format: FORMAT, version: VERSION, ciphertext}
        if(this.legacyCleanupDigest) disk.protectedConfig.legacyCleanupDigest = this.legacyCleanupDigest
        const bytes = Buffer.from(JSON.stringify(disk, null, 4), 'utf8')
        if(bytes.length > LIMIT) throw new ConfigStorageError('CONFIG_TOO_LARGE')
        // Check the complete credential generation before replacing the old file.
        if(JSON.stringify(this.decode(bytes)) !== JSON.stringify(clone(runtime))) throw new ConfigStorageError('CONFIG_VERIFY_FAILED')
        return bytes
    }

    load(defaults) {
        if(this.loaded) return this.result()
        let bytes, runtime, legacy = false
        try {
            fs.mkdirSync(path.dirname(this.file), {recursive: true, mode: 0o700})
            try { bytes = readRegular(this.file) }
            catch(error) {
                if(error.code !== 'ENOENT') throw error
                if(fs.existsSync(this.previousFile)) throw new ConfigStorageError('CONFIG_RECOVERY_REQUIRED')
                if(this.legacyPath) {
                    try { bytes = readRegular(this.legacyPath); legacy = true }
                    catch(legacyError) { if(legacyError.code !== 'ENOENT') throw legacyError }
                }
            }
            runtime = bytes ? mergeDefaults(defaults, this.decode(bytes)) : clone(defaults)
            this.firstLaunch = !bytes
            if(legacy) this.legacyCleanupDigest = digest(bytes)
            assertConfig(runtime)
            this.expectedDigest = bytes && !legacy ? digest(bytes) : null
            const encoded = this.encode(runtime)
            this.commit(encoded, this.expectedDigest)
            // Only remove the original legacy file after the new encrypted file
            // is durable and the source still matches what was migrated.
            if(this.legacyCleanupDigest && this.legacyPath && !this.warning) {
                try {
                    if(digest(readRegular(this.legacyPath)) === this.legacyCleanupDigest) {
                        fs.unlinkSync(this.legacyPath)
                        syncDirectory(path.dirname(this.legacyPath))
                        this.legacyCleanupDigest = null
                    }
                } catch(error) {
                    if(error.code === 'ENOENT') this.legacyCleanupDigest = null
                    else this.warning = 'CONFIG_LEGACY_CLEANUP_PENDING'
                }
            }
            this.snapshot = clone(runtime)
            this.loaded = true
            this.revision++
            return this.result()
        } catch(error) {
            if(error instanceof ConfigStorageError) throw error
            throw new ConfigStorageError('CONFIG_READ_FAILED')
        }
    }

    commit(encoded, expected) {
        let current
        try { current = readRegular(this.file) }
        catch(error) { if(error.code !== 'ENOENT') throw error }
        if((current ? digest(current) : null) !== expected) throw new ConfigStorageError('CONFIG_EXTERNAL_CHANGE')
        if(current) {
            const parsed = JSON.parse(current.toString('utf8'))
            if(parsed.protectedConfig?.format === FORMAT) {
                // Recovery backups contain only already-protected data.
                atomicWrite(this.previousFile, current)
            }
        }
        const outcome = atomicWrite(this.file, encoded)
        this.expectedDigest = digest(encoded)
        this.warning = outcome.durable ? null : 'CONFIG_DURABILITY_UNCONFIRMED'
    }

    save(runtime, revision) {
        if(!this.loaded || revision !== this.revision) throw new ConfigStorageError('CONFIG_STALE_WRITE')
        try {
            const encoded = this.encode(runtime)
            this.commit(encoded, this.expectedDigest)
            this.snapshot = clone(runtime)
            this.revision++
            return {revision: this.revision, warning: this.warning}
        } catch(error) {
            if(error instanceof ConfigStorageError) throw error
            throw new ConfigStorageError('CONFIG_WRITE_FAILED')
        }
    }

    recoverPrevious() {
        // Called only after an explicit recovery choice. Never overwrite a
        // present profile, including corrupt or unsupported newer data.
        if(fs.existsSync(this.file)) throw new ConfigStorageError('CONFIG_EXTERNAL_CHANGE')
        const bytes = readRegular(this.previousFile)
        let header
        try { header = JSON.parse(bytes.toString('utf8')).protectedConfig }
        catch { throw new ConfigStorageError('CONFIG_CORRUPT') }
        if(header?.format !== FORMAT) throw new ConfigStorageError('CONFIG_INVALID')
        this.decode(bytes)
        atomicWrite(this.file, bytes)
    }

    result() { return {config: clone(this.snapshot), revision: this.revision, firstLaunch: this.firstLaunch, warning: this.warning} }
}

module.exports = {ProtectedConfigStore, ConfigStorageError, atomicWrite, FORMAT, VERSION}
