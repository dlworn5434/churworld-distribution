const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { execFile } = require('node:child_process')
const { promisify } = require('node:util')

const STATE_VERSION = 1
const MD5 = /^[a-f0-9]{32}$/i
const SHA256 = /^[a-f0-9]{64}$/i

async function javaIsRunning() {
    // Older launchers did not record game PIDs. Before any deletion, also
    // check process names (never command lines/tokens). Failure means keep.
    try {
        if(process.platform === 'win32') {
            const executable = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tasklist.exe')
            const { stdout } = await promisify(execFile)(executable, ['/FO', 'CSV', '/NH'], { windowsHide: true, timeout: 5000, maxBuffer: 8 * 1024 * 1024 })
            return stdout.split(/\r?\n/).some(line => /^"javaw?\.exe",/i.test(line.trim()))
        }
        const { stdout } = await promisify(execFile)('/bin/ps', ['-A', '-o', 'comm='], { timeout: 5000, maxBuffer: 8 * 1024 * 1024 })
        return stdout.split(/\r?\n/).some(line => /^javaw?$/i.test(path.basename(line.trim())))
    } catch(_error) {
        return true
    }
}

function processExists(pid) {
    if(!Number.isSafeInteger(pid) || pid < 1) return true
    try {
        process.kill(pid, 0)
        return true
    } catch(error) {
        return error.code !== 'ESRCH'
    }
}

function hashFile(file) {
    return new Promise((resolve, reject) => {
        const md5 = crypto.createHash('md5')
        const sha256 = crypto.createHash('sha256')
        const input = fs.createReadStream(file)
        input.on('data', chunk => {
            md5.update(chunk)
            sha256.update(chunk)
        })
        input.on('error', reject)
        input.on('end', () => resolve({ md5: md5.digest('hex'), sha256: sha256.digest('hex') }))
    })
}

// Only previously verified, launcher-managed Fabric JARs are eligible. Never
// infer ownership by a filename prefix, scan a user's mods folder, or remove a
// directory. This module has no dependency on Electron and can be tested offline.
class ManagedModStore {
    constructor(commonDirectory, { isProcessAlive = processExists, isJavaRunning = javaIsRunning, logger = console, history = null } = {}) {
        this.commonDirectory = path.resolve(commonDirectory)
        this.directory = path.join(this.commonDirectory, '.churworld-managed-mods')
        this.statePath = path.join(this.directory, 'state.json')
        this.isProcessAlive = isProcessAlive
        this.isJavaRunning = isJavaRunning
        this.logger = logger
        this.history = history
    }

    key(file) {
        // Case-insensitive comparison is deliberately conservative on macOS,
        // including case-sensitive volumes: retaining a file is safer.
        return process.platform === 'linux' ? file : file.toLowerCase()
    }

    relativeJar(file) {
        if(typeof file !== 'string' || !path.isAbsolute(file)) return null
        const relative = path.relative(this.commonDirectory, file).split(path.sep).join('/')
        if(!/^mods\/fabric\/.+\.jar$/i.test(relative)) return null
        if(relative.split('/').some(part => !part || part === '.' || part === '..' || /[:\\\0]/.test(part))) return null
        return relative
    }

    // Reject symlinks/junctions and hard-linked JARs, including every ancestor
    // below common. Recheck this immediately before any unlink.
    regularFile(relative) {
        const file = path.resolve(this.commonDirectory, relative)
        if(this.relativeJar(file) !== relative) return null
        try {
            let cursor = this.commonDirectory
            let stat = fs.lstatSync(cursor)
            if(stat.isSymbolicLink() || !stat.isDirectory()) return null
            const parts = relative.split('/')
            for(let i = 0; i < parts.length; i++) {
                cursor = path.join(cursor, parts[i])
                stat = fs.lstatSync(cursor)
                if(stat.isSymbolicLink()) return null
                if(i < parts.length - 1 && !stat.isDirectory()) return null
            }
            return stat.isFile() && stat.nlink === 1 ? { file, stat } : null
        } catch(error) {
            if(error.code === 'ENOENT' || error.code === 'ENOTDIR') return null
            throw error
        }
    }

    ensureDirectory() {
        fs.mkdirSync(this.commonDirectory, { recursive: true })
        if(fs.lstatSync(this.commonDirectory).isSymbolicLink()) throw new Error('Linked common directory: mod cleanup unavailable.')
        fs.mkdirSync(this.directory, { recursive: true })
        const stat = fs.lstatSync(this.directory)
        if(stat.isSymbolicLink() || !stat.isDirectory()) throw new Error('Unsafe mod maintenance directory.')
    }

    readJSON(file) {
        const stat = fs.lstatSync(file)
        if(!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) throw new Error('Unsafe mod maintenance file.')
        if(stat.size > 8 * 1024 * 1024) throw new Error('Mod maintenance file is too large.')
        return JSON.parse(fs.readFileSync(file, 'utf8'))
    }

    writeJSON(file, value) {
        if(fs.existsSync(file)) this.readJSON(file)
        const temporary = path.join(this.directory, `write-${crypto.randomUUID()}.tmp`)
        try {
            fs.writeFileSync(temporary, JSON.stringify(value), { flag: 'wx' })
            fs.renameSync(temporary, file)
        } finally {
            if(fs.existsSync(temporary)) fs.unlinkSync(temporary)
        }
    }

    async locked(action) {
        this.ensureDirectory()
        const lockPath = path.join(this.directory, 'maintenance.lock')
        const recoveryPath = path.join(this.directory, 'lock-recovery.json')
        const token = crypto.randomUUID()
        const lock = { pid: process.pid, token }
        const busy = () => new Error('Mod maintenance is busy. Please try launching again.')
        if(fs.existsSync(recoveryPath)) throw busy()
        try {
            fs.writeFileSync(lockPath, JSON.stringify(lock), { flag: 'wx' })
            // A dead-lock recovery may have started after our initial check.
            // Yield our new lock rather than racing that recovery operation.
            if(fs.existsSync(recoveryPath)) {
                if(this.readJSON(lockPath).token === token) fs.unlinkSync(lockPath)
                throw busy()
            }
        } catch(error) {
            if(error.code !== 'EEXIST') throw error
            // Only one process may reclaim a dead owner. Without this guard,
            // two launchers could both unlink the newly acquired lock.
            fs.writeFileSync(recoveryPath, JSON.stringify(lock), { flag: 'wx' })
            try {
                const previous = this.readJSON(lockPath)
                if(this.isProcessAlive(previous.pid)) throw busy()
                if(this.readJSON(lockPath).token !== previous.token) throw new Error('Mod maintenance lock changed.')
                fs.unlinkSync(lockPath)
                fs.writeFileSync(lockPath, JSON.stringify(lock), { flag: 'wx' })
            } finally {
                if(this.readJSON(recoveryPath).token === token) fs.unlinkSync(recoveryPath)
            }
        }
        try {
            return await action()
        } finally {
            if(this.readJSON(lockPath).token === token) fs.unlinkSync(lockPath)
        }
    }

    readState() {
        if(!fs.existsSync(this.statePath)) return { version: STATE_VERSION, records: [], installed: [] }
        const state = this.readJSON(this.statePath)
        if(state.version !== STATE_VERSION || !Array.isArray(state.records) || !Array.isArray(state.installed)) {
            throw new Error('Unknown or damaged managed-mod inventory; preserving all files.')
        }
        for(const record of state.records) {
            if(!record || typeof record.path !== 'string' || this.relativeJar(path.resolve(this.commonDirectory, record.path)) !== record.path ||
                !MD5.test(record.md5) || !SHA256.test(record.sha256) || !Number.isSafeInteger(record.size) || record.size < 0) {
                throw new Error('Invalid managed-mod inventory; preserving all files.')
            }
        }
        for(const server of state.installed) {
            if(typeof server.id !== 'string' || !Array.isArray(server.paths) || server.paths.some(p => typeof p !== 'string')) {
                throw new Error('Invalid installed-server inventory; preserving all files.')
            }
        }
        return state
    }

    snapshot(distribution) {
        if(!Array.isArray(distribution?.servers) || distribution.servers.length === 0) throw new Error('Missing distribution servers.')
        const servers = new Map()
        const protectedPaths = new Set()
        const definitions = new Map()
        for(const server of distribution.servers) {
            const id = server.rawServer?.id
            if(typeof id !== 'string' || !id || servers.has(id)) throw new Error('Invalid distribution server.')
            const records = []
            const visit = modules => {
                if(!Array.isArray(modules)) throw new Error('Invalid distribution modules.')
                for(const module of modules) {
                    const file = module.getPath()
                    if(typeof file !== 'string' || !path.isAbsolute(file)) throw new Error('Invalid distribution path.')
                    const relative = this.relativeJar(file)
                    // Protect references of any type, from every server,
                    // including optional/disabled and nested modules.
                    if(relative) protectedPaths.add(this.key(relative))
                    if(module.rawModule?.type === 'FabricMod') {
                        const { MD5: md5, size } = module.rawModule.artifact || {}
                        if(!relative || !MD5.test(md5) || !Number.isSafeInteger(size) || size < 0) throw new Error('Unsafe Fabric mod definition.')
                        const record = { path: relative, md5: md5.toLowerCase(), size }
                        const previous = definitions.get(this.key(relative))
                        if(previous && (previous.md5 !== record.md5 || previous.size !== size)) throw new Error('Conflicting shared mod definitions.')
                        definitions.set(this.key(relative), record)
                        records.push(record)
                    }
                    visit(module.subModules)
                }
            }
            visit(server.modules)
            servers.set(id, records)
        }
        return { servers, protectedPaths }
    }

    async verified(record) {
        const before = this.regularFile(record.path)
        if(!before || before.stat.size !== record.size) return null
        const hashes = await hashFile(before.file)
        const after = this.regularFile(record.path)
        if(!after || before.stat.ino !== after.stat.ino || before.stat.dev !== after.stat.dev ||
            before.stat.mtimeMs !== after.stat.mtimeMs || before.stat.ctimeMs !== after.stat.ctimeMs || before.stat.size !== after.stat.size) return null
        if(hashes.md5 !== record.md5 || (record.sha256 && hashes.sha256 !== record.sha256)) return null
        const result = { ...record, sha256: hashes.sha256 }
        Object.defineProperty(result, 'verifiedStat', { value: after.stat })
        return result
    }

    mergeRecords(state, records) {
        const merged = new Map(state.records.map(record => [this.key(record.path), record]))
        for(const record of records) merged.set(this.key(record.path), record)
        state.records = [...merged.values()]
    }

    // Before 2.2.7, the last cached manifest was the only ownership evidence.
    // Adopt older cache files only when they match an immutable, bundled record
    // verified against both a historical manifest and that commit's Git blob.
    // Only exact known paths are probed; instance/user mods are never scanned.
    async adoptHistoricalMods(state, snapshot, serverId) {
        if(this.history == null) return 0
        const history = this.history
        if(history.version !== 1 || history.repository !== 'dlworn5434/churworld-distribution' ||
            !/^[a-f0-9]{40}$/.test(history.head) || !Array.isArray(history.records) || history.records.length > 10000) {
            throw new Error('Invalid historical mod catalogue; preserving files.')
        }
        // Validate the entire catalogue before adopting or deleting any file.
        for(const record of history.records) {
            if(typeof record.path !== 'string' || this.relativeJar(path.resolve(this.commonDirectory, record.path)) !== record.path ||
                !MD5.test(record.md5) || !SHA256.test(record.sha256) || !Number.isSafeInteger(record.size) || record.size < 0 ||
                !/^[a-f0-9]{40}$/.test(record.evidenceCommit) || !/^[a-f0-9]{40}$/.test(record.evidenceBlob) ||
                !Array.isArray(record.servers) || record.servers.length === 0 ||
                record.servers.some(id => typeof id !== 'string' || !id)) {
                throw new Error('Invalid historical mod record; preserving files.')
            }
        }
        const known = new Set(state.records.map(record => this.key(record.path)))
        const adopted = []
        for(const record of history.records) {
            const key = this.key(record.path)
            // Shared historical ownership could be another server's untracked
            // last installation. Retain it unless the normal ledger owns it.
            if(record.servers.length !== 1 || record.servers[0] !== serverId || known.has(key) || snapshot.protectedPaths.has(key)) continue
            const found = await this.verified({ path: record.path, size: record.size, md5: record.md5.toLowerCase(), sha256: record.sha256.toLowerCase() })
            if(found) {
                adopted.push(found)
                known.add(key)
            }
        }
        this.mergeRecords(state, adopted)
        return adopted.length
    }

    // Called BEFORE the cached distribution is overwritten, including the
    // launcher's initial preload. Only byte-verified old files are adopted.
    async remember(distribution) {
        return this.locked(async () => {
            const snapshot = this.snapshot(distribution)
            const state = this.readState()
            for(const [id, records] of snapshot.servers) {
                const verified = []
                for(const record of records) {
                    const found = await this.verified(record)
                    if(found) verified.push(found)
                }
                this.mergeRecords(state, verified)
                if(!state.installed.some(server => server.id === id)) state.installed.push({ id, paths: verified.map(record => record.path) })
            }
            this.writeJSON(this.statePath, state)
        })
    }

    async beginUpdate() {
        return this.locked(async () => {
            const id = `update-${crypto.randomUUID()}.json`
            const file = path.join(this.directory, id)
            this.writeJSON(file, { status: 'updating', pid: process.pid })
            return {
                id,
                commonDirectory: this.commonDirectory,
                finish: () => {
                    try { fs.unlinkSync(file) } catch(_error) { /* A dead owner is pruned later. */ }
                }
            }
        })
    }

    hasActiveGame(updateId) {
        for(const name of fs.readdirSync(this.directory)) {
            if(!/^(game|update)-[a-f0-9-]+\.json$/.test(name) || name === updateId) continue
            const file = path.join(this.directory, name)
            const lease = this.readJSON(file)
            // An interrupted spawn with no recorded PID is uncertain, even
            // after the launcher exits. Do not guess that the game stopped.
            if(!['running', 'updating'].includes(lease.status) || this.isProcessAlive(lease.pid)) return true
            fs.unlinkSync(file)
        }
        return false
    }

    async cleanup(distribution, serverId, updateId) {
        const snapshot = this.snapshot(distribution)
        const selected = snapshot.servers.get(serverId)
        if(!selected) throw new Error('Selected server is missing.')
        const state = this.readState()
        const verified = []
        for(const record of selected) {
            const found = await this.verified(record)
            if(!found) throw new Error('Current mods failed verification; keeping all previous mods.')
            verified.push(found)
        }
        this.mergeRecords(state, verified)
        state.installed = state.installed.filter(server => server.id !== serverId)
        state.installed.push({ id: serverId, paths: selected.map(record => record.path) })
        // The last installed version for OTHER servers stays available until
        // those servers themselves complete an update, even if remote changed.
        for(const server of state.installed) {
            for(const file of server.paths) snapshot.protectedPaths.add(this.key(file))
        }
        const adopted = await this.adoptHistoricalMods(state, snapshot, serverId)
        const result = { deleted: 0, bytes: 0, skipped: 0, adopted }
        if(state.records.every(record => snapshot.protectedPaths.has(this.key(record.path)))) {
            this.writeJSON(this.statePath, state)
            return result
        }
        if(this.hasActiveGame(updateId) || await this.isJavaRunning()) {
            this.writeJSON(this.statePath, state)
            return { ...result, reason: 'game-or-update-running' }
        }
        // Persist newly verified ownership before deleting anything. A failed
        // write, malformed state or inaccessible directory must never erase mods.
        this.writeJSON(this.statePath, state)
        const retained = []
        for(const record of state.records) {
            if(snapshot.protectedPaths.has(this.key(record.path))) {
                retained.push(record)
                continue
            }
            try {
                const match = await this.verified(record)
                if(!match) {
                    // Unknown/replaced/symlinked files are preserved and remain
                    // tracked so a temporarily locked old file can be retried.
                    retained.push(record)
                    result.skipped++
                    continue
                }
                const candidate = this.regularFile(record.path)
                if(!candidate) throw new Error('Mod path changed before cleanup.')
                for(const field of ['dev', 'ino', 'size', 'mtimeMs', 'ctimeMs']) {
                    if(candidate.stat[field] !== match.verifiedStat[field]) throw new Error('Mod changed before cleanup.')
                }
                fs.unlinkSync(candidate.file)
                result.deleted++
                result.bytes += record.size
            } catch(_error) {
                retained.push(record)
                result.skipped++
            }
        }
        state.records = retained
        this.writeJSON(this.statePath, state)
        return result
    }

    // Cleanup, a durable game lease and synchronous spawn share one lock. A
    // second launcher cannot delete mods in the gap between cleanup and spawn.
    async launch(distribution, serverId, startGame, { allowCleanup = true, updateId = null } = {}) {
        return this.locked(async () => {
            if(allowCleanup) {
                try {
                    const result = await this.cleanup(distribution, serverId, updateId)
                    this.logger.info(`Managed mod cleanup: ${result.deleted} files, ${result.bytes} bytes freed; ${result.skipped} preserved; ${result.adopted} historical files recognized${result.reason ? ` (${result.reason})` : ''}.`)
                } catch(_error) {
                    this.logger.warn('Managed mod cleanup could not complete; no further files will be removed.')
                }
            }
            const leasePath = path.join(this.directory, `game-${crypto.randomUUID()}.json`)
            this.writeJSON(leasePath, { status: 'pending' })
            let child
            const release = () => {
                try { fs.unlinkSync(leasePath) } catch(_error) { /* Dead PIDs are pruned at next launch. */ }
            }
            try {
                child = startGame()
            } catch(error) {
                release()
                throw error
            }
            const recordPID = () => {
                if(!Number.isSafeInteger(child.pid) || child.pid < 1) return
                try { this.writeJSON(leasePath, { status: 'running', pid: child.pid }) }
                catch(_error) { this.logger.warn('Game PID could not be recorded; cleanup will stay disabled for this pending session.') }
            }
            recordPID()
            child.once('spawn', recordPID)
            child.once('close', release)
            child.once('error', () => { if(!child.pid) release() })
            return child
        })
    }
}

module.exports = { ManagedModStore }
