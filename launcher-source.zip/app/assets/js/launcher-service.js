'use strict'
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const got = require('got')
const toml = require('toml')
const merge = require('lodash.merge')
const {MojangRestAPI, getServerStatus} = require('helios-core/mojang')
const {Type} = require('helios-distribution-types')
const {externalURL, trustedSender, boundedPath, validatePreferences, invalid, publicError} = require('./renderer-policy')

function createLauncherService({app, ipcMain, dialog, shell, windowFor, documentURL, store, update, login, logout, browserLogin, dependencies = {}}) {
    const config = dependencies.ConfigManager || require('./configmanager')
    config.bindStorage(store)
    config.load()
    const auth = dependencies.AuthManager || require('./authmanager')
    const distribution = dependencies.distribution || require('./distromanager')
    const api = distribution.DistroAPI
    const approvedPaths = new Set()
    const emit = (channel, value) => {
        const win = windowFor()
        if(win && !win.isDestroyed()) win.webContents.send(channel, value)
    }
    const game = dependencies.game || require('./game-service').createGameService({distribution, version: app.getVersion(),
        approvedPaths, emit: progress => {
            if(progress.type === 'distribution') {
                currentDistribution = progress.value
                synchronizedDistribution = progress.value
                emit('churu-distribution', {distribution: distributionView(progress.value), state: publicState()})
            } else emit('churu-game', progress)
        }})
    const faults = []
    function recordFault(error, operation = 'request') {
        const value = publicError(error)
        faults.push({time: new Date().toISOString(), operation, code: value.code})
        if(faults.length > 30) faults.shift()
        return value
    }
    let currentDistribution, synchronizedDistribution
    const language = merge({}, toml.parse(fs.readFileSync(path.join(__dirname, '../lang/en_US.toml'), 'utf8')),
        toml.parse(fs.readFileSync(path.join(__dirname, '../lang/_custom.toml'), 'utf8')))
    const publicState = () => config.getPublicState()
    const changed = () => { const state = publicState(); emit('churu-accounts', state); return state }
    async function getDistribution(refresh = false) {
        api.commonDir = config.getCommonDirectory()
        api.instanceDir = config.getInstanceDirectory()
        currentDistribution = await (refresh ? api.refreshDistributionOrFallback() : api.getDistribution())
        if(!currentDistribution.getServerById(config.getSelectedServer())) {
            config.setSelectedServer(currentDistribution.getMainServer()?.rawServer.id || null)
            config.save()
        }
        if(synchronizedDistribution !== currentDistribution) {
            const synchronization = dependencies.synchronization || require('./configuration-sync')
            synchronization.syncModConfigurations(currentDistribution)
            synchronization.ensureJavaSettings(currentDistribution)
            synchronizedDistribution = currentDistribution
        }
        return currentDistribution
    }
    function moduleView(module) {
        return {rawModule: {id: module.rawModule.id, type: module.rawModule.type, name: module.rawModule.name},
            mavenComponents: module.mavenComponents, required: module.getRequired(),
            versionlessId: module.mavenComponents ? module.getVersionlessMavenIdentifier() : module.rawModule.id,
            subModules: module.subModules.map(moduleView)}
    }
    function distributionView(value) {
        return {rawDistribution: {rss: value.rawDistribution.rss}, trust: api.getTrustStatus?.(value) || null, mainServerId: value.getMainServer()?.rawServer.id,
            servers: value.servers.map(server => ({rawServer: {id: server.rawServer.id, name: server.rawServer.name,
                description: server.rawServer.description, icon: server.rawServer.icon, version: server.rawServer.version,
                minecraftVersion: server.rawServer.minecraftVersion, mainServer: server.rawServer.mainServer,
                autoconnect: server.rawServer.autoconnect, javaOptions: server.rawServer.javaOptions},
            hostname: server.hostname, port: server.port, effectiveJavaOptions: server.effectiveJavaOptions,
            modules: server.modules.map(moduleView)}))}
    }
    function selectedServer() {
        const server = currentDistribution?.getServerById(config.getSelectedServer())
        if(!server || !/^[A-Za-z0-9_-]{1,120}$/.test(server.rawServer.id)) throw invalid()
        return server
    }
    function folder(kind, create = false) {
        const server = selectedServer()
        const relative = server.rawServer.id + (kind === 'mods' ? '/mods' : kind === 'shaders' ? '/shaderpacks' : '')
        const result = boundedPath(config.getInstanceDirectory(), relative, true)
        if(create) fs.mkdirSync(result, {recursive: true})
        return result
    }
    const modPattern = /^.+\.(?:jar|zip|litemod)(?:\.disabled)?$/i
    function scanMods() {
        const root = folder('mods')
        const scan = relative => {
            const dir = relative ? boundedPath(root, relative, true) : root
            if(!fs.existsSync(dir)) return []
            return fs.readdirSync(dir).filter(name => modPattern.test(name)).flatMap(name => {
                const fullName = relative ? path.join(relative, name) : name
                const file = boundedPath(root, fullName)
                if(!fs.lstatSync(file).isFile()) return []
                return [{fullName, name: name.replace(/\.disabled$/i, ''), ext: name.replace(/\.disabled$/i, '').split('.').pop(), disabled: /\.disabled$/i.test(name)}]
            })
        }
        return [...scan(''), ...scan(selectedServer().rawServer.minecraftVersion)]
    }
    function selectedMod(name) {
        if(typeof name !== 'string' || !scanMods().some(mod => mod.fullName === name)) throw invalid()
        return boundedPath(folder('mods'), name)
    }
    function scanShaders() {
        const root = folder('shaders')
        const names = fs.existsSync(root) ? fs.readdirSync(root).filter(name => /\.zip$/i.test(name)
            && fs.lstatSync(boundedPath(root, name)).isFile()) : []
        return [{fullName: 'OFF', name: 'Off (Default)'}, ...names.map(name => ({fullName: name, name: name.slice(0, -4)}))]
    }
    function selectedShader() {
        const file = boundedPath(folder('instance'), 'optionsshaders.txt', true)
        if(!fs.existsSync(file)) return 'OFF'
        return fs.readFileSync(file, 'utf8').match(/^shaderPack=(.+)$/m)?.[1]?.trim() || 'OFF'
    }
    function selectShader(name) {
        if(!scanShaders().some(pack => pack.fullName === name)) throw invalid()
        const file = boundedPath(folder('instance', true), 'optionsshaders.txt', true)
        const before = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : ''
        const line = `shaderPack=${name}`
        fs.writeFileSync(file, /^shaderPack=.*$/m.test(before) ? before.replace(/^shaderPack=.*$/m, line) : before + '\n' + line + '\n', 'utf8')
        return true
    }
    async function importFiles(files, kind) {
        if(!Array.isArray(files) || files.length > 64) throw invalid()
        if(game.isBusy()) throw invalid()
        const root = folder(kind, true)
        for(const source of files) {
            if(typeof source !== 'string' || !path.isAbsolute(source) || fs.lstatSync(source).isSymbolicLink()) throw invalid()
            const stat = fs.statSync(source), name = path.basename(source)
            if(!stat.isFile() || stat.size > 1024 ** 3 || !(kind === 'mods' ? modPattern.test(name) : /\.zip$/i.test(name))) throw invalid()
            const target = boundedPath(root, name, true)
            if(path.resolve(source) === target) continue
            fs.copyFileSync(source, target, fs.constants.COPYFILE_EXCL)
        }
        return true
    }
    async function textFeed(url) {
        if(dependencies.textFeed) return dependencies.textFeed(url)
        const parsed = new URL(url)
        if(parsed.protocol !== 'https:' || parsed.username || parsed.password) throw invalid()
        let bytes = 0
        const chunks = []
        const stream = got.stream(parsed, {timeout: {request: 15000}, retry: {limit: 0},
            hooks: {beforeRedirect: [options => { if(options.url.protocol !== 'https:') throw invalid() }]}})
        for await (const chunk of stream) {
            bytes += chunk.length
            if(bytes > 2 * 1024 * 1024) { stream.destroy(); throw invalid() }
            chunks.push(chunk)
        }
        return Buffer.concat(chunks).toString('utf8')
    }
    const syncHandlers = {
        bootstrap() { return {state: publicState(), version: app.getVersion(), platform: process.platform, isDev: !app.isPackaged, language, Type,
            memory: {total: os.totalmem(), free: os.freemem()}} },
        'preferences.read': publicState,
        'preferences.save'(value) {
            if(game.isBusy() || !currentDistribution) throw invalid()
            const next = validatePreferences(value, publicState(), currentDistribution.servers.map(s => s.rawServer.id), approvedPaths)
            return config.commitPublicPreferences(next)
        },
        'accounts.select'(uuid) {
            if(typeof uuid !== 'string' || !config.getAuthAccount(uuid)) throw invalid()
            config.transactionAuth(() => config.setSelectedAccount(uuid))
            return changed()
        },
        'window.maximized': () => windowFor().isMaximized(),
        'files.scanMods': scanMods,
        'files.scanShaders': scanShaders,
        'files.selectedShader': selectedShader,
        'files.selectShader': value => { if(game.isBusy()) throw invalid(); return selectShader(value) }
    }
    const asyncHandlers = {
        async 'distribution.read'() { return {distribution: distributionView(await getDistribution()), state: publicState()} },
        async 'distribution.refresh'() { return {distribution: distributionView(await getDistribution(true)), state: publicState()} },
        async 'accounts.validate'() { const valid = await auth.validateSelected(); changed(); return valid },
        async 'accounts.remove'(uuid) {
            if(typeof uuid !== 'string' || !config.getAuthAccount(uuid)) throw invalid()
            await auth.removeMicrosoftAccount(uuid)
            return changed()
        },
        async 'accounts.login'() { await login(); return changed() },
        async 'accounts.browser.start'() {
            if(game.isBusy() || !browserLogin) throw Object.assign(new Error('AUTH_LOGIN_BUSY'), {code: 'AUTH_LOGIN_BUSY'})
            await browserLogin.start()
            return changed()
        },
        'accounts.browser.complete'(id) {
            if(!browserLogin || typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw invalid()
            return browserLogin.complete(id)
        },
        'accounts.browser.cancel'(id) {
            if(!browserLogin || typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw invalid()
            return browserLogin.cancel(id)
        },
        'accounts.browser.reopen'(id) {
            if(!browserLogin || typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw invalid()
            return browserLogin.reopen(id)
        },
        async 'accounts.logout'(uuid) {
            if(typeof uuid !== 'string' || !config.getAuthAccount(uuid)) throw invalid()
            await logout(uuid)
            return true
        },
        'window.close': () => windowFor().close(),
        'window.minimize': () => windowFor().minimize(),
        'window.maximize': () => { const win = windowFor(); if(win.isMaximized()) win.unmaximize(); else win.maximize() },
        'updates.initialize': allow => { if(typeof allow !== 'boolean') throw invalid(); return update.initialize(allow) },
        'updates.check': () => update.check(),
        'updates.install': () => update.install(),
        'updates.prerelease': allow => { if(typeof allow !== 'boolean') throw invalid(); return update.prerelease(allow) },
        async 'game.launch'() { const value = await game.launch(); changed(); return value },
        async 'game.scanJava'() { const value = await game.scanJava(); changed(); return value },
        async 'game.installJava'() { const value = await game.installJava(); changed(); return value },
        'game.checkJava': file => game.checkJava(file),
        async 'files.choose'(kind) {
            if(!['java', 'data'].includes(kind) || game.isBusy()) throw invalid()
            const options = kind === 'java' ? {properties: ['openFile'], title: 'Java 실행 파일 선택'}
                : {properties: ['openDirectory', 'createDirectory'], title: '게임 데이터 폴더 선택'}
            if(kind === 'java' && process.platform === 'win32') options.filters = [{name: 'Java', extensions: ['exe']}]
            const result = await dialog.showOpenDialog(windowFor(), options)
            if(!result.canceled && result.filePaths[0]) {
                const file = result.filePaths[0]
                if(kind === 'java' && !/^(?:java|javaw)(?:\.exe)?$/i.test(path.basename(file))) throw invalid()
                approvedPaths.add(file)
            }
            return result
        },
        async 'files.openFolder'(kind) {
            if(!['mods', 'shaders'].includes(kind)) throw invalid()
            await shell.openPath(folder(kind, true))
            return true
        },
        async 'files.toggleMod'(value) {
            if(game.isBusy() || typeof value?.enabled !== 'boolean') throw invalid()
            const source = selectedMod(value.name)
            const enabled = !/\.disabled$/i.test(value.name)
            if(enabled === value.enabled) return true
            const name = value.enabled ? value.name.replace(/\.disabled$/i, '') : value.name + '.disabled'
            const target = boundedPath(folder('mods'), name, true)
            if(fs.existsSync(target)) throw invalid()
            fs.renameSync(source, target)
            return true
        },
        async 'files.removeMod'(name) { if(game.isBusy()) throw invalid(); await shell.trashItem(selectedMod(name)); return true },
        'files.importMods': files => importFiles(files, 'mods'),
        'files.importShaders': files => importFiles(files, 'shaders'),
        async 'content.news'() { const distro = await getDistribution(); return distro.rawDistribution.rss ? textFeed(distro.rawDistribution.rss) : null },
        'content.releases': () => textFeed('https://github.com/dlworn5434/churworld-distribution/releases.atom'),
        async 'content.external'(url) { await shell.openExternal(externalURL(url)); return true },
        async 'status.server'() {
            const server = (await getDistribution()).getServerById(config.getSelectedServer())
            const host = config.getSelectedDestination() === 'tower' && server.rawServer.id === 'churworld' ? 'tower.churworld.kr' : server.hostname
            const result = await (dependencies.getServerStatus || getServerStatus)(47, host, server.port)
            return {players: {online: Number(result.players.online), max: Number(result.players.max)}}
        },
        async 'status.mojang'() {
            const result = await (dependencies.MojangRestAPI || MojangRestAPI).status()
            return {responseStatus: result.responseStatus, data: result.data || MojangRestAPI.getDefaultStatuses()}
        },
        async 'diagnostics.export'() {
            const result = await dialog.showSaveDialog(windowFor(), {title: '진단 정보 저장', defaultPath: 'ChurWorld-diagnostics.json', filters: [{name: 'JSON', extensions: ['json']}]})
            if(result.canceled || !result.filePath) return false
            // No account IDs, credentials, environment variables, URLs, logs or local paths.
            let distributionTrust = null
            if(currentDistribution) {
                try { distributionTrust = api.getTrustStatus?.(currentDistribution) || null }
                catch(error) { distributionTrust = {unavailable: true, code: recordFault(error, 'distribution-trust').code} }
            }
            const info = {version: app.getVersion(), platform: process.platform, architecture: process.arch,
                electron: process.versions.electron, node: process.versions.node, rendererIsolation: true,
                accountCount: Object.keys(config.getAuthAccounts()).length, gamePreparationActive: game.isBusy(),
                distributionTrust, failures: faults.slice()}
            fs.writeFileSync(result.filePath, JSON.stringify(info, null, 2), {encoding: 'utf8', mode: 0o600})
            return true
        }
    }
    const allowed = event => trustedSender(event, windowFor(), documentURL)
    ipcMain.on('churu-ui-sync', (event, request) => {
        try {
            if(!allowed(event) || !request || typeof request.operation !== 'string'
                || !Object.prototype.hasOwnProperty.call(syncHandlers, request.operation)) throw invalid()
            event.returnValue = {ok: true, value: syncHandlers[request.operation](request.data)}
        } catch(error) { event.returnValue = {ok: false, error: recordFault(error)} }
    })
    ipcMain.handle('churu-ui', async (event, request) => {
        try {
            if(!allowed(event) || !request || typeof request.operation !== 'string'
                || !Object.prototype.hasOwnProperty.call(asyncHandlers, request.operation)) throw invalid()
            return {ok: true, value: await asyncHandlers[request.operation](request.data)}
        } catch(error) { return {ok: false, error: recordFault(error)} }
    })
    return {getDistribution, changed, game, recordFault}
}

module.exports = {createLauncherService}
