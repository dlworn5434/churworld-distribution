// Main-process adapter. Never instantiate Helios' unsigned DistributionAPI or
// its legacy worker. Custom files come exclusively from the approved snapshot.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const { EventEmitter } = require('node:events')
const { MojangIndexProcessor, DistributionIndexProcessor, getExpectedDownloadSize } = require('helios-core/dl')
const { getVersionJsonPath, getVersionJarPath, getLibraryDir, isLibraryCompatible, getMojangOS, validateLocalFile } = require('helios-core/common')
const { safeRelative, fail } = require('./trusted-manifest')
const { safeDestination, atomicWrite, verifyFile, fetchBytes, downloadHashedFile } = require('./secure-download')
const RECEIPT_URL = 'https://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/offline-receipt'
const VENDOR_HOSTS = new Set(['piston-meta.mojang.com', 'piston-data.mojang.com', 'launchermeta.mojang.com', 'launcher.mojang.com', 'resources.download.minecraft.net', 'libraries.minecraft.net'])

function vendorUrl(value) {
    let url
    try { url = new URL(value) } catch(_error) { fail('TRUST_VENDOR_URL_INVALID') }
    if(url.protocol !== 'https:' || url.username || url.password || url.hash || (url.port && url.port !== '443') || !VENDOR_HOSTS.has(url.hostname)) fail('TRUST_VENDOR_URL_INVALID')
    return url
}
function metadataId(value) { if(typeof value !== 'string' || !/^[A-Za-z0-9_.+-]{1,200}$/.test(value) || value === '.' || value === '..') fail('TRUST_VENDOR_METADATA_INVALID'); return value }
class SafeMojangProcessor extends MojangIndexProcessor {
    constructor(common, version, fetch = fetchBytes) {
        super(common, metadataId(version))
        this.fetchMetadata = fetch
        this.manifestFile = path.join(common, 'versions', '.mojang-version-manifest.json')
        this.metadataFiles = [this.manifestFile]
    }
    validateManifest(manifest) {
        if(!Array.isArray(manifest?.versions) || manifest.versions.length > 10000) fail('TRUST_VENDOR_METADATA_INVALID')
        const entry = manifest.versions.find(item => item.id === this.version)
        if(!entry || !/^[a-f0-9]{40}$/.test(entry.sha1)) fail('TRUST_VENDOR_METADATA_INVALID')
        vendorUrl(entry.url)
        return manifest
    }
    async loadVersionManifest() {
        let bytes
        try { bytes = await this.fetchMetadata(MojangIndexProcessor.VERSION_MANIFEST_ENDPOINT, { maxBytes: 8 * 1024 * 1024, validateUrl: vendorUrl }) }
        catch(error) {
            if(!['TRUST_NETWORK_FAILED', 'TRUST_HTTP_FAILED', 'TRUST_NETWORK_TIMEOUT'].includes(error.code || error.message)) throw error
            return this.validateManifest(readJson(this.manifestFile, this.commonDir))
        }
        const manifest = this.validateManifest(JSON.parse(bytes.toString('utf8')))
        atomicWrite(this.manifestFile, bytes, this.commonDir)
        return manifest
    }
    async loadContentWithRemoteFallback(url, filename, hash) {
        vendorUrl(url)
        safeDestination(filename, this.commonDir)
        if(hash?.algo !== 'sha1' || !/^[a-f0-9]{40}$/.test(hash.value)) fail('TRUST_VENDOR_METADATA_INVALID')
        if(fs.existsSync(filename)) {
            if(fs.statSync(filename).size > 32 * 1024 * 1024) fail('TRUST_METADATA_TOO_LARGE')
            const local = fs.readFileSync(filename)
            if(crypto.createHash('sha1').update(local).digest('hex') === hash.value) return JSON.parse(local.toString('utf8'))
        }
        const bytes = await this.fetchMetadata(url, { maxBytes: 32 * 1024 * 1024, validateUrl: vendorUrl })
        if(crypto.createHash('sha1').update(bytes).digest('hex') !== hash.value) fail('TRUST_VENDOR_METADATA_HASH')
        const value = JSON.parse(bytes.toString('utf8'))
        atomicWrite(filename, bytes, this.commonDir)
        return value
    }
    async loadAssetIndex(version) {
        if(version?.id !== this.version) fail('TRUST_VENDOR_METADATA_INVALID')
        metadataId(version?.assetIndex?.id)
        vendorUrl(version.assetIndex.url)
        if(!/^[a-f0-9]{40}$/.test(version.assetIndex.sha1)) fail('TRUST_VENDOR_METADATA_INVALID')
        return super.loadAssetIndex(version)
    }
}

function readJson(filename, root) {
    safeDestination(filename, root)
    if(fs.statSync(filename).size > 32 * 1024 * 1024) fail('TRUST_METADATA_TOO_LARGE')
    return JSON.parse(fs.readFileSync(filename, 'utf8'))
}
function vendorFiles(common, processor) {
    const version = processor.versionJson
    safeRelative(version.id)
    safeRelative(version.assetIndex.id)
    const files = [getVersionJsonPath(common, version.id), getVersionJarPath(common, version.id), processor.getAssetIndexPath(version.assetIndex.id), ...(processor.metadataFiles || [])]
    const checkArtifact = item => {
        if(!item || !/^[a-f0-9]{40}$/.test(item.sha1) || !Number.isSafeInteger(item.size) || item.size <= 0) fail('TRUST_VENDOR_METADATA_INVALID')
        vendorUrl(item.url)
    }
    checkArtifact(version.downloads.client)
    checkArtifact(version.logging.client.file)
    for(const library of version.libraries) {
        if(!isLibraryCompatible(library.rules, library.natives)) continue
        const item = library.natives == null ? library.downloads.artifact : library.downloads.classifiers[library.natives[getMojangOS()].replace('${arch}', process.arch.replace('x', ''))]
        checkArtifact(item)
        files.push(path.join(getLibraryDir(common), safeRelative(item.path)))
    }
    for(const { hash } of Object.values(processor.assetIndex.objects)) {
        if(!/^[a-f0-9]{40}$/.test(hash)) fail('TRUST_VENDOR_METADATA_INVALID')
        files.push(path.join(common, 'assets', 'objects', hash.slice(0, 2), hash))
    }
    files.push(path.join(common, 'assets', 'log_configs', safeRelative(version.logging.client.file.id)))
    const unique = [...new Set(files.map(file => path.resolve(file)))]
    if(unique.length > 100000) fail('TRUST_VENDOR_METADATA_INVALID')
    for(const file of unique) safeDestination(file, common)
    return unique
}
async function fileDigest(filename) {
    const stat = fs.lstatSync(filename), hash = crypto.createHash('sha256')
    if(!stat.isFile() || stat.isSymbolicLink()) fail('TRUST_PATH_LINK')
    for await(const chunk of fs.createReadStream(filename)) hash.update(chunk)
    const after = fs.lstatSync(filename)
    if(after.size !== stat.size || after.mtimeMs !== stat.mtimeMs || after.ino !== stat.ino || after.dev !== stat.dev) fail('TRUST_FILE_CHANGED')
    return { size: stat.size, sha256: hash.digest('hex') }
}
async function downloadVendorQueue(assets, progress, common, request) {
    const received = {}, partial = new Map()
    let next = 0, totalReceived = 0, failure
    for(const asset of assets) {
        vendorUrl(asset.url); safeDestination(asset.path, common)
        if(asset.algo !== 'sha1' || !/^[a-f0-9]{40}$/.test(asset.hash) || !Number.isSafeInteger(asset.size) || asset.size <= 0) fail('TRUST_VENDOR_METADATA_INVALID')
    }
    await Promise.allSettled(Array.from({ length: Math.min(6, assets.length) }, async () => {
        try {
            while(next < assets.length && !failure) {
                const index = next++, asset = assets[index]
                await downloadHashedFile({ url: asset.url, size: asset.size, hash: asset.hash, algorithm: 'sha1' }, asset.path, value => {
                    totalReceived += value.transferred - (partial.get(index) || 0)
                    partial.set(index, value.transferred)
                    progress(totalReceived)
                }, { root: common, validateUrl: vendorUrl, request })
                received[asset.id] = asset.size
            }
        } catch(error) { failure ||= error }
    }))
    if(failure) throw failure
    return received
}
class TrustedRepair {
    constructor({ commonDirectory, instanceDirectory, launcherDirectory, serverId, distribution, offlineOnly = false, dependencies = {} }) {
        this.common = path.resolve(commonDirectory)
        this.instances = path.resolve(instanceDirectory)
        this.launcher = path.resolve(launcherDirectory)
        this.serverId = serverId; this.distribution = distribution
        this.api = dependencies.api || require('./distromanager').DistroAPI
        this.proof = this.api.getVerifiedSnapshot(distribution)
        this.offlineOnly = offlineOnly || this.api.isOfflineOnly(distribution)
        this.server = distribution.getServerById(serverId)
        if(!this.server) fail('TRUST_SERVER_INVALID')
        safeRelative(serverId); safeRelative(this.server.rawServer.minecraftVersion)
        this.receipt = path.join(this.launcher, 'trusted-metadata', `installed-${serverId}.json`)
        const Processor = dependencies.MojangIndexProcessor || SafeMojangProcessor
        this.mojang = new Processor(this.common, this.server.rawServer.minecraftVersion)
        this.distributionProcessor = new DistributionIndexProcessor(this.common, distribution, serverId)
        this.queue = dependencies.downloadQueue || ((assets, progress) => downloadVendorQueue(assets, progress, this.common))
        this.childProcess = new EventEmitter()
        this.assets = []; this.active = false; this.validated = false
    }
    spawnReceiver() { this.active = true }
    destroyReceiver() { this.active = false }
    assertActive() {
        if(!this.active) fail('TRUST_REPAIR_NOT_STARTED')
        this.api.assertApproved(this.distribution)
        if(this.api.isOfflineOnly(this.distribution)) this.offlineOnly = true
    }
    async readReceipt() {
        let receipt
        try { receipt = readJson(this.receipt, path.dirname(this.receipt)) } catch(_error) { fail('TRUST_OFFLINE_INSTALL_NOT_VERIFIED') }
        if(receipt.schema !== 1 || receipt.distributionDigest !== this.proof.digest || !Array.isArray(receipt.files) || receipt.files.length < 3 || receipt.files.length > 100000) fail('TRUST_OFFLINE_INSTALL_NOT_VERIFIED')
        const found = new Set()
        for(const item of receipt.files) {
            const relative = safeRelative(item.path)
            if(found.has(relative)) fail('TRUST_OFFLINE_INSTALL_NOT_VERIFIED')
            found.add(relative)
            await verifyFile({ ...item, url: RECEIPT_URL }, path.join(this.common, ...relative.split('/')), this.common)
        }
        return found
    }
    async recordReceipt() {
        const files = []
        for(const filename of vendorFiles(this.common, this.mojang)) files.push({ path: path.relative(this.common, filename).split(path.sep).join('/'), ...await fileDigest(filename) })
        atomicWrite(this.receipt, JSON.stringify({ schema: 1, distributionDigest: this.proof.digest, verifiedAt: new Date().toISOString(), files }), path.dirname(this.receipt))
    }
    async verifyFiles(progress = () => {}) {
        this.assertActive(); this.validated = false
        await this.api.verifyServerFiles(this.distribution, this.serverId)
        if(this.offlineOnly) {
            const receiptFiles = await this.readReceipt()
            const versionFile = getVersionJsonPath(this.common, this.server.rawServer.minecraftVersion)
            this.mojang.versionJson = readJson(versionFile, this.common)
            safeRelative(this.mojang.versionJson.assetIndex.id)
            this.mojang.assetIndex = readJson(this.mojang.getAssetIndexPath(this.mojang.versionJson.assetIndex.id), this.common)
            for(const filename of vendorFiles(this.common, this.mojang)) {
                if(!receiptFiles.has(path.relative(this.common, filename).split(path.sep).join('/'))) fail('TRUST_OFFLINE_INSTALL_NOT_VERIFIED')
            }
        } else {
            await this.mojang.init()
            vendorFiles(this.common, this.mojang)
        }
        let completed = 0
        this.assets = Object.values(await this.mojang.validate(async () => progress(Math.trunc(++completed * 100 / this.mojang.totalStages())))).flat()
        for(const asset of this.assets) { safeDestination(asset.path, this.common); vendorUrl(asset.url) }
        if(this.offlineOnly && this.assets.length) fail('TRUST_OFFLINE_INSTALL_NOT_VERIFIED')
        if(this.assets.length === 0) {
            if(!this.offlineOnly) await this.recordReceipt()
            this.validated = true
        }
        return this.assets.length
    }
    async download(progress = () => {}) {
        this.assertActive()
        if(this.offlineOnly) fail('TRUST_EXPIRED_DOWNLOAD_DISABLED')
        const expected = getExpectedDownloadSize(this.assets)
        const received = await this.queue(this.assets, bytes => progress(expected ? Math.min(100, Math.trunc(bytes * 100 / expected)) : 100))
        for(const asset of this.assets) {
            if(received[asset.id] !== asset.size || !await validateLocalFile(asset.path, asset.algo, asset.hash)) fail('TRUST_VENDOR_DOWNLOAD_INVALID')
        }
        await this.mojang.postDownload()
        await this.api.verifyServerFiles(this.distribution, this.serverId)
    }
    async getLaunchMetadata() {
        this.assertActive()
        if(!this.validated) fail('TRUST_REPAIR_NOT_VERIFIED')
        await this.api.verifyServerFiles(this.distribution, this.serverId)
        if(this.offlineOnly) await this.readReceipt()
        // Fabric version JSON is itself a SHA256 verified distribution module.
        const mod = await this.distributionProcessor.loadModLoaderVersionJson()
        return { vanilla: this.mojang.versionJson, mod }
    }
}
module.exports = { TrustedRepair, SafeMojangProcessor, vendorUrl, vendorFiles, fileDigest, downloadVendorQueue }
