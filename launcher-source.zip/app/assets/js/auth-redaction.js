// Log-only transformation. Never use this on the arguments sent to Minecraft.
module.exports = function redactAuthentication(value, account, clientToken) {
    let text = String(value)
    const secrets = [account?.accessToken, account?.microsoft?.access_token, account?.microsoft?.refresh_token, clientToken]
        .filter(secret => typeof secret === 'string' && secret.length > 0)
        .sort((a, b) => b.length - a.length)
    for(const secret of secrets) text = text.split(secret).join('**********')
    return text
}
