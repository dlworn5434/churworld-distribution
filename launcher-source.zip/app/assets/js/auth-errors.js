const DEFINITIONS = Object.freeze({
    AUTH_TEMPORARY_FAILURE: { title: '로그인을 잠시 완료할 수 없습니다', desc: '인증 서버나 네트워크에 일시적인 문제가 있습니다. 계정은 유지됩니다. 잠시 후 다시 시도해 주세요.', retryable: true },
    AUTH_STORAGE_FAILURE: { title: '로그인 정보를 저장할 수 없습니다', desc: '보안 저장소 또는 파일 저장을 완료하지 못했습니다. 기존 계정은 유지됩니다. 저장소 상태를 확인한 뒤 다시 시도해 주세요.', retryable: true },
    AUTH_INVALID_RESPONSE: { title: '인증 응답을 확인할 수 없습니다', desc: '인증 서버의 응답을 안전하게 처리하지 못했습니다. 기존 계정은 유지됩니다. 잠시 후 다시 시도해 주세요.', retryable: true },
    AUTH_REAUTH_REQUIRED: { title: 'Microsoft 로그인이 필요합니다', desc: '저장된 인증을 더 이상 사용할 수 없습니다. Microsoft 계정으로 다시 로그인해 주세요.', reauthRequired: true },
    AUTH_ACCOUNT_ACTION_REQUIRED: { title: '계정 확인이 필요합니다', desc: 'Minecraft 이용 권한 또는 Xbox 계정 설정을 확인한 뒤 다시 로그인해 주세요.' },
    AUTH_STATE_CHANGED: { title: '계정 상태가 변경되었습니다', desc: '계정 선택 또는 로그인 상태가 변경되어 이전 인증 요청을 취소했습니다.', cancelled: true },
    AUTH_LEGACY_DISABLED: { title: 'Microsoft 로그인을 사용해 주세요', desc: '이전 Mojang 비밀번호 로그인은 지원하지 않습니다. Microsoft 계정으로 로그인해 주세요.', reauthRequired: true }
})

class AuthError extends Error {
    constructor(code, display) {
        const safeCode = Object.prototype.hasOwnProperty.call(DEFINITIONS, code) ? code : 'AUTH_TEMPORARY_FAILURE'
        super(safeCode)
        this.name = 'AuthError'
        this.code = safeCode
        this.title = display?.title ?? DEFINITIONS[safeCode].title
        this.desc = display?.desc ?? DEFINITIONS[safeCode].desc
        this.retryable = DEFINITIONS[safeCode].retryable === true
        this.reauthRequired = DEFINITIONS[safeCode].reauthRequired === true
        this.cancelled = DEFINITIONS[safeCode].cancelled === true
    }
}

function isAuthError(error) {
    return error instanceof AuthError
}

module.exports = { AuthError, isAuthError }
