const crypto = require('node:crypto')
const semver = require('semver')

const SIGNING_PREFIX = Buffer.from('ChurWorld signed manifest v1\n', 'utf8')
const MAX_MANIFEST_BYTES = 6 * 1024 * 1024
const MAX_VALIDITY_MS = 30 * 24 * 60 * 60 * 1000
const REPOSITORY = 'dlworn5434/churworld-distribution'
const MODULE_TYPES = new Set(['File', 'Library', 'FabricMod', 'ForgeMod', 'LiteMod', 'Fabric', 'Forge', 'ForgeHosted', 'LiteLoader', 'VersionManifest'])

class TrustError extends Error {
    constructor(code) { super(code); this.name = 'TrustError'; this.code = code }
}
function fail(code) { throw new TrustError(code) }
function object(value) { return value !== null && typeof value === 'object' && !Array.isArray(value) }
function iso(value) {
    if(typeof value !== 'string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(value) || !Number.isFinite(Date.parse(value))) fail('TRUST_DATE_INVALID')
    return Date.parse(value)
}
function decode64(value, max) {
    if(typeof value !== 'string' || value.length > max * 2 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) fail('TRUST_ENCODING_INVALID')
    const result = Buffer.from(value, 'base64')
    if(result.length > max || result.toString('base64') !== value) fail('TRUST_ENCODING_INVALID')
    return result
}
function safeRelative(value) {
    if(typeof value !== 'string' || value.length === 0 || value.length > 700 || /[\\\x00-\x1f\x7f:<>"|?*]/.test(value)) fail('TRUST_PATH_INVALID')
    const parts = value.split('/')
    if(parts.some(part => !part || part === '.' || part === '..' || /[. ]$/.test(part) || /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) fail('TRUST_PATH_INVALID')
    return value
}
function approvedUrl(value, { redirect = false, manifest = false } = {}) {
    if(typeof value !== 'string') fail('TRUST_URL_INVALID')
    let original
    try { original = decodeURIComponent(value.split(/[?#]/)[0]) } catch(_error) { fail('TRUST_URL_INVALID') }
    if(original.split('/').some(part => part === '..' || part === '.')) fail('TRUST_URL_INVALID')
    let url
    try { url = new URL(value) } catch(_error) { fail('TRUST_URL_INVALID') }
    if(url.protocol !== 'https:' || url.username || url.password || url.hash || (url.port && url.port !== '443') || /[\x00-\x20\\]/.test(value)) fail('TRUST_URL_INVALID')
    let decoded
    try { decoded = decodeURIComponent(url.pathname) } catch(_error) { fail('TRUST_URL_INVALID') }
    if(decoded.includes('\\') || decoded.split('/').some(part => part === '..' || part === '.')) fail('TRUST_URL_INVALID')
    const rawMain = url.hostname === 'raw.githubusercontent.com' && decoded.startsWith(`/${REPOSITORY}/main/`) && !url.search
    const rawCommit = url.hostname === 'raw.githubusercontent.com' && !url.search
        && new RegExp(`^/${REPOSITORY}/[a-f0-9]{40}/`).test(decoded)
    const release = url.hostname === 'github.com' && decoded.startsWith(`/${REPOSITORY}/releases/download/`) && !url.search
    const asset = redirect && ['release-assets.githubusercontent.com', 'objects.githubusercontent.com'].includes(url.hostname)
    // Metadata stays on the update channel; signed artifacts may pin immutable
    // commits so an ordinary later mod release cannot remove their source bytes.
    if(manifest ? !rawMain : !(rawMain || rawCommit || release || asset)) fail('TRUST_URL_NOT_APPROVED')
    return url
}
function artifact(value) {
    if(!object(value) || !Number.isSafeInteger(value.size) || value.size <= 0 || value.size > 2 * 1024 * 1024 * 1024 || !/^[a-f0-9]{64}$/.test(value.SHA256 || value.sha256 || '')) fail('TRUST_ARTIFACT_INVALID')
    approvedUrl(value.url)
    if(value.path !== undefined) safeRelative(value.path)
}
function isMutable(module) {
    return module.type === 'File' && module.artifact.mutable === true
        && /^config\/[A-Za-z0-9_./ -]+\.(?:txt|json|json5|toml|properties|cfg|ini|yaml|yml)$/.test(module.artifact.path || '')
}
function validateDistribution(distribution) {
    if(!object(distribution) || !Array.isArray(distribution.servers) || distribution.servers.length < 1 || distribution.servers.length > 100) fail('TRUST_DISTRIBUTION_INVALID')
    let count = 0
    const ids = new Set()
    for(const server of distribution.servers) {
        if(!object(server) || typeof server.id !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(server.id) || ids.has(server.id) || !Array.isArray(server.modules)) fail('TRUST_SERVER_INVALID')
        ids.add(server.id)
        const walk = (modules, depth) => {
            if(depth > 20) fail('TRUST_MODULE_LIMIT')
            for(const module of modules) {
                if(++count > 10000 || !object(module) || !MODULE_TYPES.has(module.type) || typeof module.id !== 'string') fail('TRUST_MODULE_INVALID')
                artifact(module.artifact)
                if(module.type === 'VersionManifest') {
                    if(!/^[A-Za-z0-9_.+-]{1,200}$/.test(module.id) || module.id === '.' || module.id === '..') fail('TRUST_PATH_INVALID')
                } else if(module.type !== 'File' || !module.artifact.path) {
                    if(!/^[A-Za-z0-9_.+-]+:[A-Za-z0-9_.+-]+:[A-Za-z0-9_.+-]+(?::[A-Za-z0-9_.+-]+)?(?:@[A-Za-z0-9]+)?$/.test(module.id) || module.id.split(/[:@]/).some(part => part === '.' || part === '..')) fail('TRUST_MAVEN_INVALID')
                }
                if(module.artifact.mutable !== undefined && (module.artifact.mutable !== true || !isMutable(module))) fail('TRUST_MUTABLE_INVALID')
                if(module.subModules !== undefined) {
                    if(!Array.isArray(module.subModules)) fail('TRUST_MODULE_INVALID')
                    walk(module.subModules, depth + 1)
                }
            }
        }
        walk(server.modules, 0)
    }
    return distribution
}
function validateLauncher(payload) {
    if(!semver.valid(payload.version) || !Array.isArray(payload.artifacts) || payload.artifacts.length < 1 || payload.artifacts.length > 10) fail('TRUST_UPDATE_INVALID')
    const platforms = new Set()
    for(const item of payload.artifacts) {
        artifact(item)
        if(!/^[a-f0-9]{64}$/.test(item.sha256 || '')) fail('TRUST_ARTIFACT_INVALID')
        if(!['win32', 'darwin'].includes(item.platform) || !['x64', 'arm64'].includes(item.arch) || platforms.has(`${item.platform}/${item.arch}`)) fail('TRUST_UPDATE_INVALID')
        platforms.add(`${item.platform}/${item.arch}`)
        safeRelative(item.name)
        const suffix = item.platform === 'darwin' ? `-${item.arch}.dmg` : '.exe'
        if(item.name !== `ChurWorld-Launcher-setup-${payload.version}${suffix}`) fail('TRUST_UPDATE_INVALID')
        const url = approvedUrl(item.url)
        if(url.hostname !== 'github.com' || decodeURIComponent(url.pathname.split('/').pop()) !== item.name || semver.valid(decodeURIComponent(url.pathname.split('/')[5] || '')) !== payload.version) fail('TRUST_UPDATE_INVALID')
        if(item.teamId !== undefined && !/^[A-Z0-9]{10}$/.test(item.teamId)) fail('TRUST_TEAM_INVALID')
    }
}
function verifyEnvelope(input, { purpose, keys, now = Date.now(), previous, allowExpired = false } = {}) {
    let envelope
    try {
        if(Buffer.isBuffer(input) || typeof input === 'string') {
            if(Buffer.byteLength(input) > MAX_MANIFEST_BYTES) fail('TRUST_MANIFEST_TOO_LARGE')
            envelope = JSON.parse(input.toString())
        } else envelope = input
    } catch(error) { if(error instanceof TrustError) throw error; fail('TRUST_JSON_INVALID') }
    if(!object(envelope) || envelope.schema !== 1 || typeof envelope.keyId !== 'string' || !object(keys) || keys.schema !== 1 || !Array.isArray(keys.keys)) fail('TRUST_ENVELOPE_INVALID')
    const key = keys.keys.find(entry => entry.id === envelope.keyId)
    if(!key || key.algorithm !== 'Ed25519' || !Array.isArray(key.purposes) || !key.purposes.includes(purpose)) fail('TRUST_KEY_UNKNOWN')
    const bytes = decode64(envelope.payload, 4 * 1024 * 1024)
    const signature = decode64(envelope.signature, 64)
    if(signature.length !== 64) fail('TRUST_SIGNATURE_INVALID')
    try {
        const publicKey = crypto.createPublicKey({ key: decode64(key.publicKeySpki, 256), format: 'der', type: 'spki' })
        if(publicKey.asymmetricKeyType !== 'ed25519' || !crypto.verify(null, Buffer.concat([SIGNING_PREFIX, bytes]), publicKey, signature)) fail('TRUST_SIGNATURE_INVALID')
    } catch(error) { if(error instanceof TrustError) throw error; fail('TRUST_SIGNATURE_INVALID') }
    let payload
    try { payload = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)) } catch(_error) { fail('TRUST_JSON_INVALID') }
    if(!object(payload) || payload.schema !== 1 || payload.purpose !== purpose || !Number.isSafeInteger(payload.sequence) || payload.sequence < 1) fail('TRUST_PAYLOAD_INVALID')
    const issuedAt = iso(payload.issuedAt), expiresAt = iso(payload.expiresAt)
    if(issuedAt < iso(key.notBefore) || expiresAt > iso(key.notAfter) || now < iso(key.notBefore) - 300000 || (!allowExpired && now >= iso(key.notAfter))) fail('TRUST_KEY_EXPIRED')
    if(expiresAt <= issuedAt || expiresAt - issuedAt > MAX_VALIDITY_MS || issuedAt > now + 300000) fail('TRUST_DATE_INVALID')
    if(!allowExpired && expiresAt <= now) fail('TRUST_MANIFEST_EXPIRED')
    const digest = crypto.createHash('sha256').update(bytes).digest('hex')
    const floor = keys.minimumSequence?.[purpose] || 1
    if(payload.sequence < floor || (previous && (payload.sequence < previous.payload.sequence || (payload.sequence === previous.payload.sequence && digest !== previous.digest) || issuedAt < iso(previous.payload.issuedAt)))) fail('TRUST_ROLLBACK')
    if(purpose === 'launcher-update' && previous?.payload.version && semver.valid(payload.version) && semver.lt(payload.version, previous.payload.version)) fail('TRUST_ROLLBACK')
    if(purpose === 'distribution') validateDistribution(payload.distribution)
    else if(purpose === 'launcher-update') validateLauncher(payload)
    else fail('TRUST_PURPOSE_INVALID')
    return { envelope, payload, digest }
}
module.exports = { SIGNING_PREFIX, MAX_MANIFEST_BYTES, TrustError, fail, safeRelative, approvedUrl, artifact, isMutable, validateDistribution, verifyEnvelope }
