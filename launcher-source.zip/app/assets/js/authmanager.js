const ConfigManager = require('./configmanager')
const { LoggerUtil } = require('helios-core')
const { RestResponseStatus } = require('helios-core/common')
const { MicrosoftAuth, MicrosoftErrorCode } = require('helios-core/microsoft')
const { AZURE_CLIENT_ID } = require('./ipcconstants')
const { AuthError, isAuthError } = require('./auth-errors')
const Lang = require('./langloader')

const log = LoggerUtil.getLogger('AuthManager')
const AUTH_MODE = Object.freeze({ FULL: 0, MS_REFRESH: 1, MC_REFRESH: 2 })
const inFlightRefreshes = new WeakMap()

// helios-core otherwise logs complete HTTP errors, response bodies and headers
// before returning its error result. Never forward those objects to a logger.
MicrosoftAuth.logger = Object.freeze({
    error: () => log.warn('Microsoft authentication request failed.'),
    warn: () => log.warn('Microsoft authentication request could not be completed.'),
    debug: () => {},
    info: () => {}
})

function accountDisplay(errorCode) {
    const keys = new Map([
        [MicrosoftErrorCode.NO_PROFILE, 'noProfile'],
        [MicrosoftErrorCode.NO_XBOX_ACCOUNT, 'noXboxAccount'],
        [MicrosoftErrorCode.XBL_BANNED, 'xblBanned'],
        [MicrosoftErrorCode.UNDER_18, 'under18']
    ])
    const key = keys.get(errorCode)
    return key == null ? undefined : {
        title: Lang.queryJS('auth.microsoft.error.' + key + 'Title'),
        desc: Lang.queryJS('auth.microsoft.error.' + key + 'Desc')
    }
}

function safeFailure(response, stage) {
    const error = response?.error
    const status = Number(error?.response?.statusCode)
    // Transport/status checks take precedence over any untrusted response body.
    if(!Number.isFinite(status) || status === 408 || status === 429 || status >= 500) {
        return new AuthError('AUTH_TEMPORARY_FAILURE')
    }
    const oauthError = error?.response?.body?.error
    if(stage === 'microsoft' && (status === 400 || status === 401)
        && ['invalid_grant', 'interaction_required', 'login_required', 'consent_required'].includes(oauthError)) {
        return new AuthError('AUTH_REAUTH_REQUIRED')
    }
    const display = accountDisplay(response?.microsoftErrorCode)
    if(display != null) {
        return new AuthError('AUTH_ACCOUNT_ACTION_REQUIRED', display)
    }
    if(status === 401 && stage !== 'microsoft') {
        return new AuthError('AUTH_REAUTH_REQUIRED')
    }
    return new AuthError('AUTH_TEMPORARY_FAILURE')
}

async function request(stage, action) {
    let response
    try {
        response = await action()
    } catch(error) {
        if(isAuthError(error)) throw error
        throw new AuthError('AUTH_TEMPORARY_FAILURE')
    }
    if(response?.responseStatus === RestResponseStatus.ERROR) {
        throw safeFailure(response, stage)
    }
    if(response?.responseStatus !== RestResponseStatus.SUCCESS || response.data == null || typeof response.data !== 'object') {
        throw new AuthError('AUTH_INVALID_RESPONSE')
    }
    return response.data
}

function isToken(value) {
    return typeof value === 'string' && value.length > 0
}

function isExpiry(value) {
    return typeof value === 'number' && Number.isSafeInteger(value) && value > 0
}

function requireAccessToken(token) {
    if(!isToken(token?.access_token) || typeof token.expires_in !== 'number'
        || !Number.isSafeInteger(token.expires_in) || token.expires_in <= 10) {
        throw new AuthError('AUTH_INVALID_RESPONSE')
    }
}

function captureState() {
    return { revision: ConfigManager.getAuthRevision(), selected: ConfigManager.getSelectedAccount() }
}

function requireCurrentState(state, account) {
    if(ConfigManager.getAuthRevision() !== state.revision || ConfigManager.getSelectedAccount() !== state.selected
        || (account != null && ConfigManager.getAuthAccount(account.uuid) !== account)) {
        throw new AuthError('AUTH_STATE_CHANGED')
    }
}

function commit(state, account, action) {
    requireCurrentState(state, account)
    try {
        return ConfigManager.transactionAuth(action)
    } catch(error) {
        if(isAuthError(error)) throw error
        throw new AuthError('AUTH_STORAGE_FAILURE')
    }
}

async function fullMicrosoftAuthFlow(entryCode, authMode) {
    let accessToken
    let accessTokenRaw = entryCode
    if(authMode !== AUTH_MODE.MC_REFRESH) {
        accessToken = await request('microsoft', () => MicrosoftAuth.getAccessToken(entryCode, authMode === AUTH_MODE.MS_REFRESH, AZURE_CLIENT_ID))
        requireAccessToken(accessToken)
        if(!isToken(accessToken.refresh_token)) throw new AuthError('AUTH_INVALID_RESPONSE')
        accessTokenRaw = accessToken.access_token
    }
    const xbl = await request('xbox', () => MicrosoftAuth.getXBLToken(accessTokenRaw))
    if(!isToken(xbl.Token)) throw new AuthError('AUTH_INVALID_RESPONSE')
    const xsts = await request('xsts', () => MicrosoftAuth.getXSTSToken(xbl))
    if(!isToken(xsts.Token) || !isToken(xsts.DisplayClaims?.xui?.[0]?.uhs)) throw new AuthError('AUTH_INVALID_RESPONSE')
    const mcToken = await request('minecraft', () => MicrosoftAuth.getMCAccessToken(xsts))
    requireAccessToken(mcToken)
    const mcProfile = await request('profile', () => MicrosoftAuth.getMCProfile(mcToken.access_token))
    if(!isToken(mcProfile.id) || !isToken(mcProfile.name)) throw new AuthError('AUTH_INVALID_RESPONSE')
    return { accessToken, mcToken, mcProfile }
}

function calculateExpiryDate(nowMs, expiresInS) {
    const expiry = nowMs + ((expiresInS - 10) * 1000)
    if(!isExpiry(expiry)) throw new AuthError('AUTH_INVALID_RESPONSE')
    return expiry
}

exports.addMicrosoftAccount = async function(authCode) {
    if(!isToken(authCode)) throw new AuthError('AUTH_REAUTH_REQUIRED')
    const state = captureState()
    let result
    try {
        result = await fullMicrosoftAuthFlow(authCode, AUTH_MODE.FULL)
    } catch(error) {
        requireCurrentState(state)
        throw error
    }
    const now = Date.now()
    return commit(state, null, () => ConfigManager.addMicrosoftAuthAccount(
        result.mcProfile.id,
        result.mcToken.access_token,
        result.mcProfile.name,
        calculateExpiryDate(now, result.mcToken.expires_in),
        result.accessToken.access_token,
        result.accessToken.refresh_token,
        calculateExpiryDate(now, result.accessToken.expires_in)
    ))
}

// Password-based Mojang authentication is obsolete. Do not accept, submit or log
// credentials through its former endpoint, even if an old UI calls this export.
exports.addMojangAccount = async function() {
    throw new AuthError('AUTH_LEGACY_DISABLED')
}

async function removeLocalAccount(uuid) {
    const account = ConfigManager.getAuthAccount(uuid)
    if(account == null) return
    const state = captureState()
    commit(state, account, () => ConfigManager.removeAuthAccount(uuid))
}

exports.removeMicrosoftAccount = removeLocalAccount
exports.removeMojangAccount = removeLocalAccount

async function refreshMicrosoftAccount(current, state) {
    const now = Date.now()
    const microsoft = current.microsoft
    if(!isToken(current.uuid) || !isToken(current.accessToken) || !isExpiry(current.expiresAt)
        || !isToken(microsoft?.access_token) || !isToken(microsoft?.refresh_token) || !isExpiry(microsoft?.expires_at)) {
        return false
    }
    if(now < current.expiresAt) return true

    const refreshMicrosoft = now >= microsoft.expires_at
    let result
    try {
        result = await fullMicrosoftAuthFlow(
            refreshMicrosoft ? microsoft.refresh_token : microsoft.access_token,
            refreshMicrosoft ? AUTH_MODE.MS_REFRESH : AUTH_MODE.MC_REFRESH
        )
    } catch(error) {
        // Do not show a stale re-login failure for a newly selected account.
        requireCurrentState(state, current)
        if(isAuthError(error) && error.reauthRequired) return false
        throw error
    }
    requireCurrentState(state, current)
    if(result.mcProfile.id !== current.uuid) throw new AuthError('AUTH_INVALID_RESPONSE')
    commit(state, current, () => ConfigManager.updateMicrosoftAuthAccount(
        current.uuid,
        result.mcToken.access_token,
        refreshMicrosoft ? result.accessToken.access_token : microsoft.access_token,
        refreshMicrosoft ? result.accessToken.refresh_token : microsoft.refresh_token,
        refreshMicrosoft ? calculateExpiryDate(now, result.accessToken.expires_in) : microsoft.expires_at,
        calculateExpiryDate(now, result.mcToken.expires_in)
    ))
    return true
}

exports.validateSelected = async function() {
    const current = ConfigManager.getSelectedAccount()
    if(current == null || current.type !== 'microsoft') return false
    const state = captureState()
    const existing = inFlightRefreshes.get(current)
    if(existing?.revision === state.revision) return existing.promise
    const promise = refreshMicrosoftAccount(current, state)
    inFlightRefreshes.set(current, { revision: state.revision, promise })
    try {
        return await promise
    } finally {
        if(inFlightRefreshes.get(current)?.promise === promise) inFlightRefreshes.delete(current)
    }
}
