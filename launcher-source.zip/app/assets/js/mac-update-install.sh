#!/bin/bash
# This helper runs after Electron exits. Arguments are data, never shell code.
set -euo pipefail
umask 077

main() {
    [[ $# == 12 ]] || exit 2
    local parent_pid="$1" app="$2" work="$3" token="$4" version="$5" previous="$6" arch="$7" identity="$8" relaunch="$9"
    local parent="${app%/*}" next="$work/next.app" backup="$work/previous.app"
    local bundle_digest="${10}" dmg_digest="${11}" team_id="${12}"
    [[ "$bundle_digest" =~ ^[a-f0-9]{64}$ && "$dmg_digest" =~ ^[a-f0-9]{64}$ ]] || exit 2
    [[ "$team_id" == none || "$team_id" =~ ^[A-Z0-9]{10}$ ]] || exit 2
    [[ "$parent_pid" =~ ^[0-9]+$ && "$parent_pid" -gt 1 && "$token" =~ ^[a-f0-9]{32}$ ]] || exit 2
    [[ "$app" == /*.app && "$work" == "$parent"/.churworld-update-* && "${work%/*}" == "$parent" ]] || exit 2
    [[ "$arch" == arm64 || "$arch" == x64 ]] || exit 2
    [[ -d "$work" && ! -L "$work" && ! -L "$app" && ! -L "$next" ]] || exit 2
    [[ "$(cd "$parent" && pwd -P)" == "$parent" && "$(cd "$work" && pwd -P)" == "$work" ]] || exit 2
    [[ "$(/bin/cat "$work/token")" == "$token" && ! -e "$work/mounted" && ! -e "$backup" ]] || exit 2
    [[ "${BASH_SOURCE[0]}" == "$work/install.sh" ]] || exit 2
    # The mkdir is exclusive, so even repeated quit events cannot swap twice.
    /bin/mkdir "$work/installing"
    : > "$work/ready-to-quit"
    echo "Waiting for launcher exit before installing $version"
    local attempt=0
    while /bin/kill -0 "$parent_pid" 2>/dev/null; do
        attempt=$((attempt + 1))
        if [[ "$attempt" -ge 120 ]]; then
            /bin/rmdir "$work/installing"
            echo 'Launcher did not exit; update cancelled.'
            exit 1
        fi
        /bin/sleep 1
    done
    [[ "$(/usr/bin/stat -f '%d:%i' "$app")" == "$identity" ]] || exit 2
    [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$app/Contents/Info.plist")" == helioslauncher ]] || exit 2
    [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$app/Contents/Info.plist")" == "$previous" ]] || exit 2
    [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$next/Contents/Info.plist")" == helioslauncher ]] || exit 2
    [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$next/Contents/Info.plist")" == "$version" ]] || exit 2
    [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$next/Contents/Info.plist")" == 'ChurWorld Launcher' ]] || exit 2
    /usr/bin/codesign --verify --deep --strict "$next"
    [[ ! -L "$work/update.dmg" && ! -L "$work/bundle-digest.sh" ]] || exit 2
    local actual_dmg
    actual_dmg="$(/usr/bin/shasum -a 256 < "$work/update.dmg")"
    [[ "${actual_dmg%% *}" == "$dmg_digest" ]] || exit 2
    [[ "$(/bin/bash "$work/bundle-digest.sh" "$next")" == "$bundle_digest" ]] || exit 2
    if [[ "$team_id" != none ]]; then
        /usr/bin/codesign -dv --verbose=4 "$next" 2>&1 | /usr/bin/grep -Fx "TeamIdentifier=$team_id" >/dev/null || exit 2
    fi
    local binary_arch=arm64 binary_format
    [[ "$arch" == arm64 ]] || binary_arch=x86_64
    binary_format="$(/usr/bin/file -b "$next/Contents/MacOS/ChurWorld Launcher")"
    [[ "$binary_format" == *Mach-O* && "$binary_format" == *"$binary_arch"* ]] || exit 2
    # Both moves stay on the app's filesystem. Never remove the working app first.
    trap 'if [[ -d "$backup" && ! -e "$app" ]]; then /bin/mv "$backup" "$app"; fi' EXIT
    trap 'exit 1' HUP INT TERM
    /bin/mv "$app" "$backup"
    if ! /bin/mv "$next" "$app"; then
        /bin/mv "$backup" "$app"
        /bin/rmdir "$work/installing"
        echo 'Replacement failed; original app restored.'
        exit 1
    fi
    if ! /usr/bin/codesign --verify --deep --strict "$app"; then
        /bin/mv "$app" "$next"
        /bin/mv "$backup" "$app"
        /bin/rmdir "$work/installing"
        echo 'Verification failed; original app restored.'
        exit 1
    fi
    echo "Installed $version"
    trap - EXIT HUP INT TERM
    # No quarantine removal, re-signing, privilege escalation, or Gatekeeper changes.
    # Only this exact, token-verified workspace contains the temporary backup.
    /bin/rm -rf -- "$work"
    if [[ "$relaunch" == 1 ]]; then /usr/bin/open "$app"; fi
}
main "$@"
