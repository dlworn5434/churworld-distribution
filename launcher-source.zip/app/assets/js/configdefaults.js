module.exports = function createConfigDefaults(dataPath) {
    return {
        settings: {
            game: {resWidth: 1280, resHeight: 720, fullscreen: false, autoConnect: true, launchDetached: true},
            launcher: {allowPrerelease: false, dataDirectory: dataPath}
        },
        newsCache: {date: null, content: null, dismissed: false},
        clientToken: null,
        selectedServer: null,
        selectedDestination: 'life',
        selectedAccount: null,
        authenticationDatabase: {},
        modConfigurations: [],
        javaConfig: {}
    }
}
