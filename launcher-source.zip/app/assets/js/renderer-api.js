'use strict'
// This script has no Node capabilities. All privileged operations use named bridge methods.
const BOOT = window.launcher.bootstrap()
const launcherPlatform = BOOT.platform
const launcherVersion = BOOT.version
const isDev = BOOT.isDev
const Type = BOOT.Type
const $ = window.jQuery
const LoggerUtil = {getLogger: () => ({info() {}, debug() {}, warn() {}, error() {}})}
const Lang = {
    query(id, values = {}) { let value = id.split('.').reduce((v, k) => v?.[k], BOOT.language); if(typeof value !== 'string') return id;
        for(const [key, val] of Object.entries(values)) value = value.replaceAll('{' + key + '}', String(val)); return value },
    queryJS(id, values) { return this.query('js.' + id, values) }, queryEJS(id, values) { return this.query('ejs.' + id, values) }
}
let publicConfiguration = BOOT.state
function replacePublicState(state) { publicConfiguration = state; return state }
window.launcher.accounts.onChanged(replacePublicState)
const ConfigManager = {
    reload() { replacePublicState(window.launcher.preferences.read()) },
    save() { try { replacePublicState(window.launcher.preferences.save(Object.fromEntries(
        ['settings', 'javaConfig', 'modConfigurations', 'newsCache', 'selectedServer', 'selectedDestination'].map(key => [key, publicConfiguration[key]])))) }
        catch(error) { this.reload(); throw error } },
    isFirstLaunch: () => publicConfiguration.firstLaunch,
    getAuthRevision: () => publicConfiguration.authRevision,
    getAuthAccounts: () => publicConfiguration.authenticationDatabase,
    getAuthAccount: uuid => publicConfiguration.authenticationDatabase[uuid],
    getSelectedAccount: () => publicConfiguration.authenticationDatabase[publicConfiguration.selectedAccount] || null,
    setSelectedAccount(uuid) { replacePublicState(window.launcher.accounts.select(uuid)); return this.getSelectedAccount() },
    transactionAuth(mutator) { return mutator() },
    getSelectedServer: () => publicConfiguration.selectedServer,
    setSelectedServer(value) { publicConfiguration.selectedServer = value },
    getSelectedDestination: () => publicConfiguration.selectedDestination === 'tower' ? 'tower' : 'life',
    setSelectedDestination(value) { publicConfiguration.selectedDestination = value },
    getNewsCache: () => publicConfiguration.newsCache,
    setNewsCache(value) { publicConfiguration.newsCache = value },
    setNewsCacheDismissed(value) { publicConfiguration.newsCache.dismissed = value },
    getModConfiguration: id => publicConfiguration.modConfigurations.find(value => value.id === id),
    setModConfiguration(id, configuration) { const index = publicConfiguration.modConfigurations.findIndex(value => value.id === id); if(index >= 0) publicConfiguration.modConfigurations[index] = configuration; else publicConfiguration.modConfigurations.push(configuration) },
    getCommonDirectory: () => publicConfiguration.paths.common,
    getInstanceDirectory: () => publicConfiguration.paths.instances,
    getLauncherDirectory: () => publicConfiguration.paths.launcher,
    getAbsoluteMinRAM: ram => ram?.minimum != null ? ram.minimum / 1024 : BOOT.memory.total >= 6 * 1073741824 ? 3 : 2,
    getAbsoluteMaxRAM() { const mem = BOOT.memory.total, extra = mem - 16 * 1073741824; return Math.floor((mem - (extra > 0 ? Math.trunc(extra / 8) + 4 * 1073741824 : mem / 4)) / 1073741824) }
}
for(const [name, group, key] of [['GameWidth', 'game', 'resWidth'], ['GameHeight', 'game', 'resHeight'],
    ['Fullscreen', 'game', 'fullscreen'], ['AutoConnect', 'game', 'autoConnect'], ['LaunchDetached', 'game', 'launchDetached'],
    ['AllowPrerelease', 'launcher', 'allowPrerelease'], ['DataDirectory', 'launcher', 'dataDirectory']]) {
    ConfigManager['get' + name] = (defaults = false) => (defaults ? publicConfiguration.defaults : publicConfiguration).settings[group][key]
    ConfigManager['set' + name] = value => { publicConfiguration.settings[group][key] = /^Game(?:Width|Height)$/.test(name) ? Number(value) : value }
}
for(const [name, key] of [['MinRAM', 'minRAM'], ['MaxRAM', 'maxRAM'], ['JavaExecutable', 'executable'], ['JVMOptions', 'jvmOptions']]) {
    ConfigManager['get' + name] = id => publicConfiguration.javaConfig[id]?.[key]
    ConfigManager['set' + name] = (id, value) => { publicConfiguration.javaConfig[id][key] = value }
}
ConfigManager.validateGameWidth = ConfigManager.validateGameHeight = value => Number.isInteger(Number(value)) && Number(value) >= 0 && Number(value) <= 16384
let rendererDistribution
function hydrateDistribution(reply) {
    replacePublicState(reply.state)
    const value = reply.distribution
    const module = entry => Object.assign(entry, {getRequired: () => entry.required,
        getVersionlessMavenIdentifier: () => entry.versionlessId, hasSubModules: () => entry.subModules.length > 0,
        subModules: entry.subModules.map(module)})
    for(const server of value.servers) server.modules = server.modules.map(module)
    value.getServerById = id => value.servers.find(server => server.rawServer.id === id)
    value.getMainServer = () => value.getServerById(value.mainServerId)
    rendererDistribution = value
    return value
}
window.launcher.distribution.onChanged(hydrateDistribution)
const DistroAPI = {
    getDistribution: async () => rendererDistribution || hydrateDistribution(await window.launcher.distribution.read()),
    refreshDistributionOrFallback: async () => hydrateDistribution(await window.launcher.distribution.refresh())
}
const AuthManager = {
    async validateSelected() { try { return await window.launcher.accounts.validate() } finally { ConfigManager.reload() } },
    async removeMicrosoftAccount(uuid) { replacePublicState(await window.launcher.accounts.remove(uuid)) },
    async removeMojangAccount(uuid) { replacePublicState(await window.launcher.accounts.remove(uuid)) }
}
const windowControls = {close: () => window.launcher.window.close(), minimize: () => window.launcher.window.minimize(),
    maximize: () => window.launcher.window.maximize(), unmaximize: () => window.launcher.window.maximize(),
    isMaximized: () => window.launcher.window.maximized()}
const shell = {openExternal: value => window.launcher.content.openExternal(value).catch(() => {})}
const os = {totalmem: () => BOOT.memory.total, freemem: () => BOOT.memory.free}
const semver = {prerelease: value => String(value).includes('-') ? String(value).split('-').slice(1) : null}
// Display-only path formatting. It grants no filesystem access.
const path = {join: (...parts) => parts.join(launcherPlatform === 'win32' ? '\\' : '/')}
const validateSelectedJvm = file => window.launcher.game.checkJava(file)
const ensureJavaDirIsRoot = file => file
const MojangRestAPI = {status: () => window.launcher.status.mojang(), getDefaultStatuses: () => [],
    statusToHex: status => ({green: '#a5c325', yellow: '#eac918', red: '#c32625', grey: '#848484'})[status] || '#848484'}
const getServerStatus = () => window.launcher.status.server()
const RestResponseStatus = {SUCCESS: 0}
const DropinModUtil = {
    scanForDropinMods: () => window.launcher.files.scanMods(),
    isDropinModEnabled: name => !name.endsWith('.disabled'),
    toggleDropinMod: (_root, name, enabled) => window.launcher.files.toggleMod(name, enabled),
    deleteDropinMod: (_root, name) => window.launcher.files.removeMod(name),
    addDropinMods: files => window.launcher.files.importMods(Array.from(files)),
    scanForShaderpacks: () => window.launcher.files.scanShaders(),
    getEnabledShaderpack: () => window.launcher.files.selectedShader(),
    setEnabledShaderpack: (_root, name) => window.launcher.files.selectShader(name),
    addShaderpacks: files => window.launcher.files.importShaders(Array.from(files))
}
const MSFT_OPCODE = {OPEN_LOGIN: 'login', OPEN_BROWSER_LOGIN: 'browserLogin', OPEN_LOGOUT: 'logout', REPLY_LOGIN: 'loginReply', REPLY_LOGOUT: 'logoutReply'}
const MSFT_REPLY_TYPE = {SUCCESS: 'success', ERROR: 'error'}
const MSFT_ERROR = {NOT_FINISHED: 'cancelled'}
// Local UI events preserve animation/view transitions. No raw Electron IPC is exposed.
const uiListeners = new Map()
let loginRequestPending = false
function uiEmit(name, ...args) { for(const callback of uiListeners.get(name) || []) callback(null, ...args) }
const ipcRenderer = {
    on(name, callback) { if(!['autoUpdateNotification', 'loginReply', 'logoutReply'].includes(name)) throw new Error('Unknown UI event');
        if(!uiListeners.has(name)) uiListeners.set(name, []); uiListeners.get(name).push(callback) },
    send(name, ...args) {
        if(name === 'autoUpdateAction') {
            const [action, value] = args
            const actions = {initAutoUpdater: () => window.launcher.updates.initialize(value), checkForUpdate: () => window.launcher.updates.check(),
                installUpdateNow: () => window.launcher.updates.install(), allowPrereleaseChange: () => window.launcher.updates.allowPrerelease(value)}
            if(!Object.hasOwn(actions, action)) throw new Error('Unknown update action')
            actions[action]().catch(error => uiEmit('autoUpdateNotification', 'realerror', {code: error.code, message: error.message}))
        } else if(name === MSFT_OPCODE.OPEN_LOGIN || name === MSFT_OPCODE.OPEN_BROWSER_LOGIN) {
            if(loginRequestPending) return
            loginRequestPending = true
            const start = name === MSFT_OPCODE.OPEN_BROWSER_LOGIN ? () => window.launcher.accounts.openBrowserLogin() : () => window.launcher.accounts.openLogin()
            Promise.resolve().then(start).then(state => {
                loginRequestPending = false
                replacePublicState(state); uiEmit('loginReply', MSFT_REPLY_TYPE.SUCCESS, ConfigManager.getSelectedAccount(), args[0])
            }).catch(error => {
                loginRequestPending = false
                uiEmit('loginReply', MSFT_REPLY_TYPE.ERROR, error.code === 'AUTH_STATE_CHANGED' ? MSFT_ERROR.NOT_FINISHED : error, args[1])
            })
        } else if(name === MSFT_OPCODE.OPEN_LOGOUT) {
            window.launcher.accounts.openLogout(args[0]).then(() => uiEmit('logoutReply', MSFT_REPLY_TYPE.SUCCESS, args[0], args[1]))
                .catch(error => uiEmit('logoutReply', MSFT_REPLY_TYPE.ERROR, error.code === 'AUTH_STATE_CHANGED' ? MSFT_ERROR.NOT_FINISHED : error))
        } else throw new Error('Unknown UI action')
    }
}
window.launcher.updates.onProgress(({type, info}) => uiEmit('autoUpdateNotification', type, info))
function escapeHTML(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'})[char]) }
function safeContentURL(value) { try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password ? url.href : '#' } catch { return '#' } }
function sanitizeContent(value) {
    const source = new DOMParser().parseFromString(String(value || ''), 'text/html')
    const allowed = new Set(['P', 'DIV', 'SPAN', 'BR', 'HR', 'H1', 'H2', 'H3', 'H4', 'UL', 'OL', 'LI', 'B', 'STRONG', 'I', 'EM', 'U', 'S', 'BLOCKQUOTE', 'PRE', 'CODE', 'A', 'IMG', 'TABLE', 'THEAD', 'TBODY', 'TR', 'TH', 'TD', 'BUTTON'])
    const discarded = new Set(['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'SVG', 'MATH', 'FORM', 'INPUT', 'TEMPLATE', 'LINK', 'META', 'BASE'])
    function clean(node) {
        if(node.nodeType === Node.TEXT_NODE) return document.createTextNode(node.textContent)
        if(node.nodeType !== Node.ELEMENT_NODE || discarded.has(node.tagName)) return document.createDocumentFragment()
        const result = allowed.has(node.tagName) ? document.createElement(node.tagName.toLowerCase()) : document.createDocumentFragment()
        if(node.tagName === 'A') result.setAttribute('href', safeContentURL(node.getAttribute('href')))
        if(node.tagName === 'IMG') { const url = safeContentURL(node.getAttribute('src')); if(url !== '#') result.setAttribute('src', url); result.setAttribute('alt', node.getAttribute('alt') || ''); result.setAttribute('loading', 'lazy') }
        if(node.tagName === 'BUTTON') result.setAttribute('type', 'button')
        const classes = Array.from(node.classList).filter(value => /^bbCode(?:Spoiler|Block|Quote|Code)[A-Za-z_-]*$/.test(value))
        if(classes.length && result.setAttribute) result.setAttribute('class', classes.join(' '))
        for(const child of node.childNodes) result.appendChild(clean(child))
        return result
    }
    const output = document.createElement('div')
    for(const child of source.body.childNodes) output.appendChild(clean(child))
    return output.innerHTML
}
