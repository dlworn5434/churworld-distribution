const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const https = require('node:https')
const { pipeline } = require('node:stream/promises')
const { Transform } = require('node:stream')
const { approvedUrl, fail, artifact } = require('./trusted-manifest')

function absolutePath(value) {
    const absolute = path.resolve(value)
    // macOS exposes these system-owned aliases. Canonicalize only the known
    // OS mapping; arbitrary user-created aliases/junctions remain forbidden.
    if(process.platform === 'darwin') {
        for(const alias of ['/var', '/tmp']) {
            if((absolute === alias || absolute.startsWith(`${alias}/`)) && fs.realpathSync(alias) === `/private${alias}`) return `/private${absolute}`
        }
    }
    return absolute
}
// Walk each component: a lexical containment check alone does not stop junctions.
function safeDestination(destination, root = path.dirname(destination), create = false) {
    const base = absolutePath(root), target = absolutePath(destination)
    const relative = path.relative(base, target)
    if(!relative || relative.startsWith(`..${path.sep}`) || relative === '..' || path.isAbsolute(relative)) fail('TRUST_PATH_ESCAPE')
    const check = value => {
        let stat
        try { stat = fs.lstatSync(value) } catch(error) { if(error.code === 'ENOENT') return false; throw error }
        if(stat.isSymbolicLink() || (!stat.isFile() && !stat.isDirectory())) fail('TRUST_PATH_LINK')
        return stat
    }
    // Check from the existing filesystem root, including a caller-supplied root.
    let current = path.parse(base).root
    for(const component of base.slice(current.length).split(path.sep).filter(Boolean)) {
        current = path.join(current, component)
        let stat = check(current)
        if(!stat && create) { fs.mkdirSync(current, { mode: 0o700 }); stat = check(current) }
        if(stat && !stat.isDirectory()) fail('TRUST_PATH_INVALID')
    }
    for(const component of relative.split(path.sep)) {
        current = path.join(current, component)
        let stat = check(current)
        if(current !== target) {
            if(!stat && create) { fs.mkdirSync(current, { mode: 0o700 }); stat = check(current) }
            if(stat && !stat.isDirectory()) fail('TRUST_PATH_INVALID')
        } else if(stat && !stat.isFile()) fail('TRUST_PATH_INVALID')
    }
    return target
}
function openHttps(url, { request = https.get, manifest = false, redirects = 0, validateUrl = approvedUrl } = {}) {
    const parsed = validateUrl(url, { redirect: redirects > 0, manifest })
    if(redirects > 5) fail('TRUST_REDIRECT_LIMIT')
    return new Promise((resolve, reject) => {
        const req = request(parsed, { headers: { 'User-Agent': 'ChurWorld-Secure-Updater', 'Accept-Encoding': 'identity' }, rejectUnauthorized: true, timeout: 30000 }, response => {
            if([301, 302, 303, 307, 308].includes(response.statusCode)) {
                response.resume()
                let next
                try { next = new URL(response.headers.location, parsed).href; validateUrl(next, { redirect: true, manifest }) } catch(error) { reject(error); return }
                openHttps(next, { request, manifest, redirects: redirects + 1, validateUrl }).then(resolve, reject)
                return
            }
            if(response.statusCode !== 200 || (response.headers['content-encoding'] && response.headers['content-encoding'] !== 'identity')) {
                response.resume(); reject(Object.assign(new Error('TRUST_HTTP_FAILED'), { code: 'TRUST_HTTP_FAILED' })); return
            }
            resolve(response)
        })
        req.once('error', () => reject(Object.assign(new Error('TRUST_NETWORK_FAILED'), { code: 'TRUST_NETWORK_FAILED' })))
        req.once('timeout', () => req.destroy(new Error('timeout')))
    })
}
async function fetchBytes(url, { maxBytes, request, manifest = false, validateUrl } = {}) {
    const response = await openHttps(url, { request, manifest, validateUrl })
    const chunks = []; let length = 0
    const timer = setTimeout(() => response.destroy(new Error('TRUST_NETWORK_TIMEOUT')), 60000)
    try {
        for await(const chunk of response) {
            length += chunk.length
            if(length > maxBytes) fail('TRUST_MANIFEST_TOO_LARGE')
            chunks.push(chunk)
        }
        return Buffer.concat(chunks)
    } finally { clearTimeout(timer); response.destroy() }
}
async function verifyFile(descriptor, filename, root) {
    artifact(descriptor)
    const target = safeDestination(filename, root)
    const before = fs.lstatSync(target)
    if(!before.isFile() || before.size !== descriptor.size) fail('TRUST_FILE_SIZE')
    const hash = crypto.createHash('sha256')
    const stream = fs.createReadStream(target)
    for await(const chunk of stream) hash.update(chunk)
    const after = fs.lstatSync(target)
    if(before.dev !== after.dev || before.ino !== after.ino || before.size !== after.size || before.mtimeMs !== after.mtimeMs || after.isSymbolicLink()) fail('TRUST_FILE_CHANGED')
    if(hash.digest('hex') !== (descriptor.SHA256 || descriptor.sha256)) fail('TRUST_FILE_HASH')
    return true
}
function atomicWrite(filename, bytes, root) {
    const target = safeDestination(filename, root, true)
    const temporary = `${target}.${crypto.randomBytes(12).toString('hex')}.tmp`
    let fd
    try {
        fd = fs.openSync(temporary, 'wx', 0o600)
        fs.writeFileSync(fd, bytes); fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined
        safeDestination(target, root)
        fs.renameSync(temporary, target)
    } finally {
        if(fd !== undefined) fs.closeSync(fd)
        if(fs.existsSync(temporary)) fs.unlinkSync(temporary)
    }
}
async function downloadFile(descriptor, destination, progress = () => {}, { root = path.dirname(destination), request } = {}) {
    artifact(descriptor)
    return downloadHashedFile({ url: descriptor.url, size: descriptor.size, hash: descriptor.SHA256 || descriptor.sha256, algorithm: 'sha256' }, destination, progress, { root, request })
}
async function downloadHashedFile(descriptor, destination, progress = () => {}, { root = path.dirname(destination), request, validateUrl = approvedUrl } = {}) {
    if(!['sha1', 'sha256'].includes(descriptor.algorithm) || !Number.isSafeInteger(descriptor.size) || descriptor.size <= 0 || descriptor.size > 2 * 1024 * 1024 * 1024
        || !(descriptor.algorithm === 'sha1' ? /^[a-f0-9]{40}$/ : /^[a-f0-9]{64}$/).test(descriptor.hash)) fail('TRUST_ARTIFACT_INVALID')
    validateUrl(descriptor.url)
    const target = safeDestination(destination, root, true)
    const temporary = `${target}.${crypto.randomBytes(12).toString('hex')}.download`
    let response, timer
    try {
        response = await openHttps(descriptor.url, { request, validateUrl })
        const length = response.headers['content-length']
        if(length !== undefined && (!/^\d+$/.test(length) || Number(length) !== descriptor.size)) fail('TRUST_FILE_SIZE')
        let bytes = 0
        const hash = crypto.createHash(descriptor.algorithm)
        const meter = new Transform({ transform(chunk, _encoding, callback) {
            bytes += chunk.length
            if(bytes > descriptor.size) return callback(Object.assign(new Error('TRUST_FILE_SIZE'), { code: 'TRUST_FILE_SIZE' }))
            hash.update(chunk)
            try { progress({ percent: bytes * 100 / descriptor.size, transferred: bytes, total: descriptor.size }) }
            catch(error) { callback(error); return }
            callback(null, chunk)
        } })
        timer = setTimeout(() => response.destroy(new Error('TRUST_NETWORK_TIMEOUT')), 600000)
        await pipeline(response, meter, fs.createWriteStream(temporary, { flags: 'wx', mode: 0o600 }))
        if(bytes !== descriptor.size) fail('TRUST_FILE_SIZE')
        if(hash.digest('hex') !== descriptor.hash) fail('TRUST_FILE_HASH')
        const fd = fs.openSync(temporary, 'r+'); try { fs.fsyncSync(fd) } finally { fs.closeSync(fd) }
        safeDestination(target, root)
        fs.renameSync(temporary, target)
        return target
    } finally {
        clearTimeout(timer)
        if(response) response.destroy()
        if(fs.existsSync(temporary)) fs.unlinkSync(temporary)
    }
}
module.exports = { safeDestination, openHttps, fetchBytes, verifyFile, atomicWrite, downloadFile, downloadHashedFile }
