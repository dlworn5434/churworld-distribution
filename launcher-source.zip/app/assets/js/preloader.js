// The only renderer bridge. This file uses only Electron's sandbox preload API.
const {contextBridge, ipcRenderer, webUtils} = require('electron')

function result(reply) {
    if(!reply?.ok) {
        const error = new Error(reply?.error?.message || '요청을 완료하지 못했습니다.')
        error.code = reply?.error?.code || 'REQUEST_FAILED'
        throw error
    }
    return reply.value
}
const sync = (operation, data) => result(ipcRenderer.sendSync('churu-ui-sync', {operation, data}))
const invoke = (operation, data) => ipcRenderer.invoke('churu-ui', {operation, data}).then(result)
const subscribe = (channel, listener) => {
    if(typeof listener !== 'function') throw new TypeError('Listener required')
    const handler = (_event, ...data) => listener(...data)
    ipcRenderer.on(channel, handler)
    return () => ipcRenderer.removeListener(channel, handler)
}
const importedFiles = files => Array.from(files).map(file => webUtils.getPathForFile(file)).filter(Boolean)

contextBridge.exposeInMainWorld('launcher', Object.freeze({
    bootstrap: () => sync('bootstrap'),
    preferences: Object.freeze({read: () => sync('preferences.read'), save: value => sync('preferences.save', value)}),
    accounts: Object.freeze({select: uuid => sync('accounts.select', uuid), validate: () => invoke('accounts.validate'),
        remove: uuid => invoke('accounts.remove', uuid), openLogin: () => invoke('accounts.login'),
        openLogout: uuid => invoke('accounts.logout', uuid), onChanged: listener => subscribe('churu-accounts', listener)}),
    distribution: Object.freeze({read: () => invoke('distribution.read'), refresh: () => invoke('distribution.refresh'),
        onChanged: listener => subscribe('churu-distribution', listener)}),
    window: Object.freeze({close: () => invoke('window.close'), minimize: () => invoke('window.minimize'),
        maximize: () => invoke('window.maximize'), maximized: () => sync('window.maximized')}),
    updates: Object.freeze({initialize: allow => invoke('updates.initialize', allow), check: () => invoke('updates.check'),
        install: () => invoke('updates.install'), allowPrerelease: allow => invoke('updates.prerelease', allow),
        onProgress: listener => subscribe('churu-update', listener)}),
    game: Object.freeze({launch: () => invoke('game.launch'), scanJava: () => invoke('game.scanJava'),
        installJava: () => invoke('game.installJava'), checkJava: file => invoke('game.checkJava', file),
        onProgress: listener => subscribe('churu-game', listener)}),
    files: Object.freeze({choose: kind => invoke('files.choose', kind), openFolder: kind => invoke('files.openFolder', kind),
        scanMods: () => sync('files.scanMods'), toggleMod: (name, enabled) => invoke('files.toggleMod', {name, enabled}),
        removeMod: name => invoke('files.removeMod', name), importMods: files => invoke('files.importMods', importedFiles(files)),
        scanShaders: () => sync('files.scanShaders'), selectedShader: () => sync('files.selectedShader'),
        selectShader: name => sync('files.selectShader', name), importShaders: files => invoke('files.importShaders', importedFiles(files))}),
    content: Object.freeze({news: () => invoke('content.news'), releases: () => invoke('content.releases'),
        openExternal: url => invoke('content.external', url)}),
    status: Object.freeze({server: () => invoke('status.server'), mojang: () => invoke('status.mojang')}),
    diagnostics: Object.freeze({export: () => invoke('diagnostics.export')})
}))
