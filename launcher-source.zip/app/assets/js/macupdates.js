const semver = require('semver')
const { getTrustedUpdate } = require('./trusted-updates')

const RELEASES_URL = 'https://github.com/dlworn5434/churworld-distribution/releases'

function escapeHtml(value){
    return String(value == null ? '' : value).replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        '\'': '&#39;'
    })[character])
}

/**
 * Legacy display-only release selection. Its result carries no signed approval
 * and is deliberately rejected by the automatic downloader.
 */
function selectMacUpdate(releases, currentVersion, arch, allowPrerelease = false){
    if(!Array.isArray(releases)){
        throw new TypeError('Invalid GitHub releases response.')
    }
    if(!semver.valid(currentVersion)){
        throw new TypeError('Invalid current launcher version.')
    }
    if(arch !== 'arm64' && arch !== 'x64'){
        return null
    }

    let newest = null
    for(const release of releases){
        if(!release || release.draft || typeof release.tag_name !== 'string'){
            continue
        }
        const version = semver.valid(release.tag_name)
        if(!version || !semver.gt(version, currentVersion)){
            continue
        }
        if(!allowPrerelease && (release.prerelease || semver.prerelease(version))){
            continue
        }
        if(newest && !semver.gt(version, newest.version)){
            continue
        }

        const assetName = `ChurWorld-Launcher-setup-${version}-${arch}.dmg`
        const expectedUrl = `${RELEASES_URL}/download/${encodeURIComponent(release.tag_name)}/${assetName}`
        const asset = Array.isArray(release.assets) && release.assets.find(candidate =>
            candidate && candidate.name === assetName && candidate.state === 'uploaded'
            && candidate.browser_download_url === expectedUrl && candidate.size > 0
        )
        if(!asset){
            continue
        }

        newest = {
            version,
            releaseName: escapeHtml(release.name || `ChurWorld Launcher ${version}`),
            releaseNotes: escapeHtml(release.body || '').replace(/\r?\n/g, '<br>'),
            releaseDate: release.published_at,
            darwindownload: asset.browser_download_url,
            size: asset.size,
            digest: asset.digest,
            arch
        }
    }
    return newest
}

async function checkMacUpdate(currentVersion, arch, allowPrerelease = false){
    const ConfigManager = require('./configmanager')
    return getTrustedUpdate({ platform: 'darwin', arch, currentVersion, allowPrerelease, cacheDirectory: ConfigManager.getLauncherDirectory() })
}

module.exports = { checkMacUpdate, selectMacUpdate }
