const got = require('got')
const semver = require('semver')

const RELEASES_API = 'https://api.github.com/repos/dlworn5434/churworld-distribution/releases'
const RELEASES_URL = 'https://github.com/dlworn5434/churworld-distribution/releases'

function escapeHtml(value){
    return String(value == null ? '' : value).replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        '\'': '&#39;'
    })[character])
}

/**
 * Unsigned macOS builds use DMG replacement instead of electron-updater's
 * signed ZIP installation. Only offer a release after its matching DMG exists.
 */
function selectMacUpdate(releases, currentVersion, arch, allowPrerelease = false){
    if(!Array.isArray(releases)){
        throw new TypeError('Invalid GitHub releases response.')
    }
    if(!semver.valid(currentVersion)){
        throw new TypeError('Invalid current launcher version.')
    }
    if(arch !== 'arm64' && arch !== 'x64'){
        return null
    }

    let newest = null
    for(const release of releases){
        if(!release || release.draft || typeof release.tag_name !== 'string'){
            continue
        }
        const version = semver.valid(release.tag_name)
        if(!version || !semver.gt(version, currentVersion)){
            continue
        }
        if(!allowPrerelease && (release.prerelease || semver.prerelease(version))){
            continue
        }
        if(newest && !semver.gt(version, newest.version)){
            continue
        }

        const assetName = `ChurWorld-Launcher-setup-${version}-${arch}.dmg`
        const expectedUrl = `${RELEASES_URL}/download/${encodeURIComponent(release.tag_name)}/${assetName}`
        const asset = Array.isArray(release.assets) && release.assets.find(candidate =>
            candidate && candidate.name === assetName && candidate.state === 'uploaded'
            && candidate.browser_download_url === expectedUrl && candidate.size > 0
        )
        if(!asset){
            continue
        }

        newest = {
            version,
            releaseName: escapeHtml(release.name || `ChurWorld Launcher ${version}`),
            releaseNotes: escapeHtml(release.body || '').replace(/\r?\n/g, '<br>'),
            releaseDate: release.published_at,
            darwindownload: asset.browser_download_url
        }
    }
    return newest
}

async function checkMacUpdate(currentVersion, arch, allowPrerelease = false){
    const releases = await got.get(RELEASES_API, {
        searchParams: { per_page: 100 },
        headers: {
            Accept: 'application/vnd.github+json',
            'User-Agent': `ChurWorld-Launcher/${currentVersion}`,
            'X-GitHub-Api-Version': '2022-11-28'
        },
        timeout: { request: 15000 },
        retry: { limit: 1 }
    }).json()
    return selectMacUpdate(releases, currentVersion, arch, allowPrerelease)
}

module.exports = { checkMacUpdate, selectMacUpdate }
