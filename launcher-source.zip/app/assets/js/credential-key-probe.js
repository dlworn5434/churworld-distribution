'use strict'

const fs = require('node:fs')
const path = require('node:path')

function plainDirectory(directory) {
    const stat = fs.lstatSync(directory)
    const normalize = value => process.platform === 'win32' ? path.resolve(value).toLowerCase() : path.resolve(value)
    if(!stat.isDirectory() || stat.isSymbolicLink() || normalize(fs.realpathSync(directory)) !== normalize(directory)) {
        throw new Error('Invalid probe directory')
    }
}

function runCredentialKeyProbe({ app, safeStorage, output = process.stdout, argv = process.argv }) {
    // This entry is selected before loading any launcher account, renderer, updater or logger module.
    let finished = false
    let stage = 'path'
    const finish = ok => {
        if(finished) return
        finished = true
        output.write(JSON.stringify(ok ? { ok } : { ok, stage }), () => {
            process.exitCode = ok ? 0 : 1
            if(app.isReady()) app.quit()
            else app.exit(ok ? 0 : 1)
        })
    }
    try {
        if(process.platform !== 'win32') throw new Error('Unsupported probe platform')
        const prefixes = argv.filter(value => value.startsWith('--churu-credential-key-profile='))
        if(prefixes.length !== 1) throw new Error('Invalid probe path')
        const profile = prefixes[0].slice('--churu-credential-key-profile='.length)
        if(!path.isAbsolute(profile) || path.basename(profile) !== 'profile') throw new Error('Invalid probe path')
        const work = path.dirname(profile)
        if(!/^probe-[0-9a-f]{32}$/.test(path.basename(work))) throw new Error('Invalid probe owner')
        plainDirectory(work)
        plainDirectory(profile)
        const ownerPath = path.join(work, 'owner.json')
        const ownerStat = fs.lstatSync(ownerPath)
        if(!ownerStat.isFile() || ownerStat.isSymbolicLink() || ownerStat.size > 4096) throw new Error('Invalid probe owner')
        const owner = JSON.parse(fs.readFileSync(ownerPath, 'utf8'))
        if(owner.kind !== 'churu-credential-key-probe-v1' || `probe-${owner.id}` !== path.basename(work)
            || path.resolve(owner.profile) !== path.resolve(profile)) throw new Error('Invalid probe owner')
        const statePath = path.join(profile, 'Local State')
        const stateStat = fs.lstatSync(statePath)
        if(!stateStat.isFile() || stateStat.isSymbolicLink() || stateStat.size > 32768) throw new Error('Invalid probe state')
        app.setPath('userData', profile)
        app.setPath('sessionData', profile)
        app.disableHardwareAcceleration()
        stage = 'input'
        const challenges = argv.filter(value => value.startsWith('--churu-credential-key-challenge='))
        if(challenges.length !== 1) throw new Error('Invalid probe challenge')
        const encoded = challenges[0].slice('--churu-credential-key-challenge='.length)
        if(encoded.length > 4096) throw new Error('Invalid probe input')
        const bytes = Buffer.from(encoded, 'base64')
        if(bytes.toString('base64') !== encoded) throw new Error('Invalid probe input')
        const value = JSON.parse(bytes.toString('utf8'))
        app.whenReady().then(() => {
            stage = 'request-validation'
            if(value?.schema !== 1 || typeof value.nonce !== 'string' || !/^[0-9a-f]{64}$/.test(value.nonce)
                || typeof value.ciphertext !== 'string' || value.ciphertext.length > 1024) throw new Error('Invalid probe request')
            const bytes = Buffer.from(value.ciphertext, 'base64')
            stage = 'availability'
            if(bytes.toString('base64') !== value.ciphertext || !safeStorage.isEncryptionAvailable()) throw new Error('Invalid probe ciphertext')
            stage = 'decrypt'
            finish(safeStorage.decryptString(bytes) === value.nonce)
        }).catch(() => finish(false))
    } catch {
        finish(false)
    }
}

module.exports = { runCredentialKeyProbe }
