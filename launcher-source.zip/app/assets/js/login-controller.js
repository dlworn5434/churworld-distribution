'use strict'

// Main-process coordinator. Browser URLs, clipboard contents and tokens never
// leave this module through status notifications or return values.
const {randomBytes} = require('node:crypto')

function failure(code) {
    const error = new Error(code)
    error.code = code
    return error
}

function createLoginController({beginAttempt, acquireBrowserToken, openExternal, readClipboard, clearClipboard, notify = () => {}}) {
    let active = null
    const report = (op, status) => {
        if(active === op && op.kind === 'browser') {
            try { notify({id: op.id, status}) } catch { /* A closed UI cannot change an authentication result. */ }
        }
    }
    const assertActive = op => {
        if(active !== op || op.controller.signal.aborted) throw failure('AUTH_STATE_CHANGED')
    }
    async function run(kind, action) {
        if(active) throw failure('AUTH_LOGIN_BUSY')
        const op = {id: randomBytes(16).toString('hex'), kind, controller: new AbortController()}
        active = op
        let removeAbort
        try {
            const context = {id: op.id, signal: op.controller.signal,
                assertActive: () => assertActive(op), cancel: () => op.controller.abort(),
                attempt: kind === 'logout' ? null : beginAttempt(op.controller.signal)}
            const aborted = new Promise((_resolve, reject) => {
                const onAbort = () => reject(failure('AUTH_STATE_CHANGED'))
                op.controller.signal.addEventListener('abort', onAbort, {once: true})
                removeAbort = () => op.controller.signal.removeEventListener('abort', onAbort)
                if(op.controller.signal.aborted) onAbort()
            })
            // Downstream libraries may finish their network request after a
            // cancellation. Release the UI now; context/credential guards keep
            // that late result from opening a browser or committing an account.
            assertActive(op)
            const actionResult = action(context, op)
            const result = await Promise.race([actionResult, aborted])
            assertActive(op)
            report(op, 'complete')
            return result
        } catch(error) {
            report(op, op.controller.signal.aborted || error?.code === 'AUTH_STATE_CHANGED' ? 'cancelled' : 'error')
            throw error
        } finally {
            removeAbort?.()
            op.controller.abort()
            op.acceptCallback = null
            op.reopen = null
            if(active === op) active = null
        }
    }
    function browserOperation(id) {
        if(typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)
            || active?.kind !== 'browser' || active.id !== id) throw failure('AUTH_STATE_CHANGED')
        assertActive(active)
        return active
    }
    return {
        run,
        startBrowser() {
            return run('browser', async(context, op) => {
                report(op, 'opening_browser')
                const tokens = await acquireBrowserToken({mode: 'copy-link', signal: context.signal,
                    openBrowser: async url => { context.assertActive(); await openExternal(url); context.assertActive() },
                    onStatus: status => {
                        if(['opening_browser', 'waiting_for_browser', 'exchanging_token'].includes(status)) report(op, status)
                        else if(status === 'complete') report(op, 'checking_account')
                    },
                    onCallbackReady: accept => { context.assertActive(); op.acceptCallback = accept },
                    onReopenReady: reopen => { context.assertActive(); op.reopen = reopen }
                })
                context.assertActive()
                report(op, 'checking_account')
                await context.attempt.addTokens(tokens)
                context.assertActive()
                return true
            })
        },
        completeBrowser(id) {
            const op = browserOperation(id)
            if(typeof op.acceptCallback !== 'function') throw failure('AUTH_BROWSER_LINK_INVALID')
            // Explicit button press only. No background clipboard observation.
            const value = readClipboard()
            if(typeof value !== 'string' || value.length > 32768 || !op.acceptCallback(value.trim())) {
                throw failure('AUTH_BROWSER_LINK_INVALID')
            }
            // Avoid leaving a valid authorization response on the clipboard;
            // never clear content that the user replaced in the meantime.
            try { if(readClipboard() === value) clearClipboard?.() } catch { /* Login can continue. */ }
            return true
        },
        async reopenBrowser(id) {
            const op = browserOperation(id)
            if(typeof op.reopen !== 'function') throw failure('AUTH_STATE_CHANGED')
            try { return Boolean(await op.reopen()) }
            catch { throw failure('AUTH_BROWSER_OPEN_FAILED') }
        },
        cancelBrowser(id) { browserOperation(id).controller.abort(); return true },
        cancelAll() { active?.controller.abort() }
    }
}

module.exports = {createLoginController}
