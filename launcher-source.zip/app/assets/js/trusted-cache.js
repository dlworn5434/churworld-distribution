const fs = require('node:fs')
const path = require('node:path')
const { verifyEnvelope, MAX_MANIFEST_BYTES, fail } = require('./trusted-manifest')
const { fetchBytes, safeDestination, atomicWrite } = require('./secure-download')
function trustedKeys() { return require('./security/trust-keys.json') }
class TrustedCache {
    constructor({ directory, purpose, url, keys = trustedKeys(), fetch = fetchBytes, now = Date.now, allowExpiredFallback = false }) {
        this.directory = path.resolve(directory)
        this.filename = path.join(this.directory, `${purpose}.signed.json`)
        this.purpose = purpose; this.url = url; this.keys = keys; this.fetch = fetch; this.now = now
        this.pending = null
        this.allowExpiredFallback = allowExpiredFallback && purpose === 'distribution'
    }
    verify(envelope, extra = {}) { return verifyEnvelope(envelope, { purpose: this.purpose, keys: this.keys, now: this.now(), ...extra }) }
    read(allowExpired = false) {
        safeDestination(this.filename, this.directory)
        let stat
        try { stat = fs.statSync(this.filename) } catch(error) { if(error.code === 'ENOENT') return null; throw error }
        if(stat.size > MAX_MANIFEST_BYTES) fail('TRUST_MANIFEST_TOO_LARGE')
        return this.verify(fs.readFileSync(this.filename), { allowExpired })
    }
    async refresh() {
        if(this.pending) return this.pending
        this.pending = this.refreshOnce()
        try { return await this.pending } finally { this.pending = null }
    }
    async refreshOnce() {
        // Expired signed metadata still supplies a rollback floor. Never discard
        // a corrupt cache and silently promote unverified distribution data.
        const previous = this.read(true)
        let input
        try { input = await this.fetch(this.url, { maxBytes: MAX_MANIFEST_BYTES, manifest: true }) }
        catch(error) {
            if(!['TRUST_NETWORK_FAILED', 'TRUST_HTTP_FAILED', 'TRUST_NETWORK_TIMEOUT'].includes(error.code || error.message)) throw error
            if(previous) return this.verify(previous.envelope, { allowExpired: this.allowExpiredFallback })
            throw error
        }
        let current
        try { current = this.verify(input, { previous }) }
        catch(error) {
            if(this.allowExpiredFallback && previous && ['TRUST_MANIFEST_EXPIRED', 'TRUST_KEY_EXPIRED'].includes(error.code)) return this.verify(previous.envelope, { allowExpired: true })
            throw error
        }
        this.verify(current.envelope, { previous: this.read(true) })
        atomicWrite(this.filename, JSON.stringify(current.envelope), this.directory)
        return current
    }
}
module.exports = { TrustedCache, trustedKeys }
