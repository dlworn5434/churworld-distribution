const path = require('node:path')
const semver = require('semver')
const { TrustedCache } = require('./trusted-cache')
const { verifyEnvelope, fail } = require('./trusted-manifest')
const { downloadFile, verifyFile } = require('./secure-download')
const UPDATE_URL = 'https://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/launcher-updates.signed.json'
const approvals = new WeakMap(), caches = new Map()
function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', '\'': '&#39;' })[character])
}
async function getTrustedUpdate({ platform, arch, currentVersion, cacheDirectory, allowPrerelease = false }) {
    if(!['win32', 'darwin'].includes(platform) || !['x64', 'arm64'].includes(arch) || !semver.valid(currentVersion)) fail('TRUST_UPDATE_INVALID')
    const directory = path.join(path.resolve(cacheDirectory), 'trusted-metadata')
    if(!caches.has(directory)) caches.set(directory, new TrustedCache({ directory, purpose: 'launcher-update', url: UPDATE_URL }))
    const cache = caches.get(directory), verified = await cache.refresh(), payload = verified.payload
    if(!semver.gt(payload.version, currentVersion) || (!allowPrerelease && semver.prerelease(payload.version))) return null
    const artifact = payload.artifacts.find(item => item.platform === platform && item.arch === arch)
    if(!artifact) return null
    const info = Object.freeze({
        version: payload.version, releaseName: escapeHtml(payload.releaseName || `ChurWorld Launcher ${payload.version}`),
        releaseNotes: escapeHtml(payload.releaseNotes).replace(/\r?\n/g, '<br>'), releaseDate: payload.issuedAt,
        artifact: Object.freeze({ ...artifact }), arch,
        ...(platform === 'darwin' ? { darwindownload: artifact.url, size: artifact.size, digest: `sha256:${artifact.sha256}` } : {})
    })
    approvals.set(info, { verified, cache })
    return info
}
function assertTrustedUpdate(info) {
    const proof = approvals.get(info)
    if(!proof) fail('TRUST_UPDATE_NOT_APPROVED')
    verifyEnvelope(proof.verified.envelope, { purpose: 'launcher-update', keys: proof.cache.keys, previous: proof.cache.read(true) })
    return info.artifact
}
async function downloadTrustedUpdate(info, destination, progress) { return downloadFile(assertTrustedUpdate(info), destination, progress) }
async function verifyTrustedUpdate(info, filename) { return verifyFile(assertTrustedUpdate(info), filename) }
module.exports = { UPDATE_URL, getTrustedUpdate, downloadTrustedUpdate, verifyTrustedUpdate, assertTrustedUpdate }
