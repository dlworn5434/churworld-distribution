#!/bin/bash
# BSD find -s preserves byte-sorted traversal. Hash names, modes, links and
# regular-file contents without following bundle symlinks. macOS system tools.
set -euo pipefail
export LC_ALL=C
[[ $# == 1 && -d "$1" && ! -L "$1" ]] || exit 2
cd "$1"
(
    while IFS= read -r -d '' entry; do
        mode="$(/usr/bin/stat -f '%Lp' "$entry")"
        if [[ -L "$entry" ]]; then
            printf 'L\0%s\0%s\0%s\0' "$entry" "$mode" "$(/usr/bin/readlink "$entry")"
        elif [[ -f "$entry" ]]; then
            digest="$(/usr/bin/shasum -a 256 < "$entry")"
            printf 'F\0%s\0%s\0%s\0' "$entry" "$mode" "${digest%% *}"
        elif [[ -d "$entry" ]]; then
            printf 'D\0%s\0%s\0' "$entry" "$mode"
        else exit 2
        fi
    done < <(/usr/bin/find -s . -print0)
) | /usr/bin/shasum -a 256 | /usr/bin/awk '{print $1}'
