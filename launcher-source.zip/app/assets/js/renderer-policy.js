'use strict'
const path = require('node:path')
const fs = require('node:fs')

const EXTERNAL_HOSTS = new Set(['github.com', 'www.github.com', 'discord.gg', 'discord.com',
    'churworld.kr', 'www.churworld.kr', 'wiki.churworld.kr', 'docs.oracle.com',
    'minecraft.net', 'www.minecraft.net', 'help.minecraft.net', 'adoptium.net'])

function invalid() {
    const error = new Error('허용되지 않은 요청입니다.')
    error.code = 'REQUEST_DENIED'
    return error
}

function externalURL(value) {
    if(typeof value !== 'string' || value.length > 4096) throw invalid()
    const url = new URL(value)
    if(url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443')
        || !EXTERNAL_HOSTS.has(url.hostname)) throw invalid()
    return url.href
}

function trustedSender(event, window, documentURL) {
    return !!window && !window.isDestroyed() && event.sender === window.webContents
        && event.senderFrame === window.webContents.mainFrame && event.senderFrame.url === documentURL
}

function jsonObject(value, maxBytes = 1024 * 1024) {
    if(!value || typeof value !== 'object' || Array.isArray(value)) throw invalid()
    const text = JSON.stringify(value)
    if(Buffer.byteLength(text) > maxBytes) throw invalid()
    const inspect = item => {
        if(item && typeof item === 'object') for(const [key, child] of Object.entries(item)) {
            if(['__proto__', 'prototype', 'constructor'].includes(key)) throw invalid()
            inspect(child)
        }
    }
    inspect(value)
    return JSON.parse(text)
}

function boundedPath(root, relative, allowMissing = false) {
    if(typeof relative !== 'string' || relative.length > 1024 || !relative || path.isAbsolute(relative)
        || relative.split(/[\\/]/).some(p => !p || p === '.' || p === '..') || relative.includes(':') || relative.includes('\0')) throw invalid()
    root = path.resolve(root)
    const target = path.resolve(root, relative)
    if(!target.startsWith(root + path.sep)) throw invalid()
    let current = path.parse(root).root
    for(const part of path.relative(current, target).split(path.sep)) {
        current = path.join(current, part)
        let stat
        try { stat = fs.lstatSync(current) }
        catch(error) { if(allowMissing && error.code === 'ENOENT') continue; throw invalid() }
        if(stat.isSymbolicLink()) throw invalid()
    }
    return target
}

function validatePreferences(value, previous, serverIds, approvedPaths) {
    const next = jsonObject(value)
    const keys = ['settings', 'javaConfig', 'modConfigurations', 'newsCache', 'selectedServer', 'selectedDestination']
    if(Object.keys(next).some(k => !keys.includes(k)) || keys.some(k => !(k in next))) throw invalid()
    if(!serverIds.includes(next.selectedServer) || !['life', 'tower'].includes(next.selectedDestination)) throw invalid()
    const game = next.settings?.game, launcher = next.settings?.launcher
    if(!game || !launcher || Object.keys(next.settings).some(k => !['game', 'launcher'].includes(k))) throw invalid()
    if(Object.keys(game).some(k => !['resWidth', 'resHeight', 'fullscreen', 'autoConnect', 'launchDetached'].includes(k))
        || Object.keys(launcher).some(k => !['allowPrerelease', 'dataDirectory'].includes(k))) throw invalid()
    for(const k of ['resWidth', 'resHeight']) if(!Number.isInteger(game[k]) || game[k] < 0 || game[k] > 16384) throw invalid()
    for(const k of ['fullscreen', 'autoConnect', 'launchDetached']) if(typeof game[k] !== 'boolean') throw invalid()
    if(typeof launcher.allowPrerelease !== 'boolean' || typeof launcher.dataDirectory !== 'string'
        || !path.isAbsolute(launcher.dataDirectory)) throw invalid()
    if(launcher.dataDirectory !== previous.settings.launcher.dataDirectory && !approvedPaths.has(launcher.dataDirectory)) throw invalid()
    if(!Array.isArray(next.modConfigurations) || next.modConfigurations.length > 100) throw invalid()
    for(const entry of next.modConfigurations) if(!serverIds.includes(entry.id) || !entry.mods || typeof entry.mods !== 'object') throw invalid()
    const mods = (value, depth = 0) => {
        if(depth > 30) throw invalid()
        if(typeof value === 'boolean') return
        if(!value || typeof value !== 'object' || Array.isArray(value)) throw invalid()
        for(const child of Object.values(value)) mods(child, depth + 1)
    }
    for(const entry of next.modConfigurations) mods(entry.mods)
    if(!next.javaConfig || Array.isArray(next.javaConfig)) throw invalid()
    for(const [id, java] of Object.entries(next.javaConfig)) {
        // Keep saved configurations for servers no longer in the distribution unchanged.
        if(!serverIds.includes(id)) {
            if(JSON.stringify(java) !== JSON.stringify(previous.javaConfig[id])) throw invalid()
            continue
        }
        if(!java || Object.keys(java).some(k => !['minRAM', 'maxRAM', 'executable', 'jvmOptions'].includes(k))) throw invalid()
        for(const key of ['minRAM', 'maxRAM']) if(typeof java[key] !== 'string' || !/^\d+(?:\.\d+)?[MG]$/.test(java[key])) throw invalid()
        const memory = value => parseFloat(value) * (value.endsWith('G') ? 1024 : 1)
        if(java.minRAM !== previous.javaConfig[id]?.minRAM || java.maxRAM !== previous.javaConfig[id]?.maxRAM) {
            if(memory(java.minRAM) < 128 || memory(java.maxRAM) > 1024 * 1024 || memory(java.minRAM) > memory(java.maxRAM)) throw invalid()
        }
        if(java.executable !== null && (typeof java.executable !== 'string' || !path.isAbsolute(java.executable))) throw invalid()
        if(java.executable !== previous.javaConfig[id]?.executable && java.executable !== null && !approvedPaths.has(java.executable)) throw invalid()
        if(JSON.stringify(java.jvmOptions) !== JSON.stringify(previous.javaConfig[id]?.jvmOptions)) validateJVMOptions(java.jvmOptions)
    }
    const news = next.newsCache
    if(!news || Object.keys(news).some(k => !['date', 'content', 'dismissed'].includes(k)) || typeof news.dismissed !== 'boolean') throw invalid()
    if(news.content !== null && (typeof news.content !== 'string' || news.content.length > 256)) throw invalid()
    if(news.date !== null && typeof news.date !== 'string' && typeof news.date !== 'number') throw invalid()
    return next
}

// Renderer preferences may tune performance, never load code, debug agents or command hooks.
function validateJVMOptions(options) {
    const booleans = new Set(['UseG1GC','UseZGC','UseParallelGC','UseSerialGC','UseShenandoahGC','UseConcMarkSweepGC',
        'CMSIncrementalMode','UseAdaptiveSizePolicy','UnlockExperimentalVMOptions','UnlockDiagnosticVMOptions',
        'AlwaysPreTouch','DisableExplicitGC','ParallelRefProcEnabled','UseStringDeduplication','PerfDisableSharedMem',
        'UseNUMA','UseLargePages','UseTransparentHugePages','UseCompressedOops','UseCompressedClassPointers'])
    const numbers = new Set(['G1NewSizePercent','G1MaxNewSizePercent','G1ReservePercent','G1HeapRegionSize','MaxGCPauseMillis',
        'InitiatingHeapOccupancyPercent','G1MixedGCLiveThresholdPercent','G1MixedGCCountTarget','G1RSetUpdatingPauseTimePercent',
        'SurvivorRatio','TargetSurvivorRatio','MaxTenuringThreshold','ParallelGCThreads','ConcGCThreads','ActiveProcessorCount',
        'MaxDirectMemorySize','ReservedCodeCacheSize','InitialCodeCacheSize','SoftRefLRUPolicyMSPerMB','MinHeapFreeRatio',
        'MaxHeapFreeRatio','NewRatio','MaxRAMPercentage','InitialRAMPercentage','MinRAMPercentage'])
    if(!Array.isArray(options) || options.length > 64) throw invalid()
    for(const option of options) {
        if(typeof option !== 'string' || option.length > 256) throw invalid()
        if(/^-Xm[nxs]\d+[kKmMgG]$/.test(option) || /^-Xss\d+[kKmMgG]$/.test(option)) continue
        if(/^-Dfile\.encoding=(?:UTF-8|UTF8)$/.test(option)) continue
        let match = /^-XX:[+-]([A-Za-z0-9]+)$/.exec(option)
        if(match && booleans.has(match[1])) continue
        match = /^-XX:([A-Za-z0-9]+)=(\d+(?:\.\d+)?[kKmMgG]?)$/.exec(option)
        if(match && numbers.has(match[1])) continue
        throw invalid()
    }
    return options
}

const PUBLIC_FAILURE_CODES = new Set([
    "AUTH_LOGIN_BUSY",
    "AUTH_BROWSER_LINK_INVALID",
    "AUTH_BROWSER_OPEN_FAILED",
    "AUTH_BROWSER_TIMEOUT",
    "AUTH_BROWSER_DENIED",
    "AUTH_BROWSER_CONFIG_REQUIRED",
    "AUTH_ACCOUNT_ACTION_REQUIRED",
    "AUTH_INVALID_RESPONSE",
    "AUTH_LEGACY_DISABLED",
    "AUTH_REAUTH_REQUIRED",
    "AUTH_STATE_CHANGED",
    "AUTH_STORAGE_FAILURE",
    "AUTH_TEMPORARY_FAILURE",
    "CONFIG_CORRUPT",
    "CONFIG_DURABILITY_UNCONFIRMED",
    "CONFIG_EXTERNAL_CHANGE",
    "CONFIG_INVALID",
    "CONFIG_INVALID_ACCOUNT",
    "CONFIG_INVALID_FILE",
    "CONFIG_KEY_UNAVAILABLE",
    "CONFIG_LEGACY_CLEANUP_PENDING",
    "CONFIG_MIXED_VERSIONS",
    "CONFIG_READ_FAILED",
    "CONFIG_RECOVERY_REQUIRED",
    "CONFIG_STALE_WRITE",
    "CONFIG_TOO_LARGE",
    "CONFIG_UNAVAILABLE",
    "CONFIG_UNSUPPORTED_VERSION",
    "CONFIG_VERIFY_FAILED",
    "CONFIG_WRITE_FAILED",
    "NETWORK_UNAVAILABLE",
    "REQUEST_DENIED",
    "REQUEST_FAILED",
    "TRUST_ARTIFACT_INVALID",
    "TRUST_DATE_INVALID",
    "TRUST_DIRECT_PULL_DISABLED",
    "TRUST_DISTRIBUTION_INVALID",
    "TRUST_DISTRIBUTION_NOT_APPROVED",
    "TRUST_DISTRIBUTION_UNAVAILABLE",
    "TRUST_ENCODING_INVALID",
    "TRUST_ENVELOPE_INVALID",
    "TRUST_EXPIRED_DOWNLOAD_DISABLED",
    "TRUST_FILE_CHANGED",
    "TRUST_FILE_HASH",
    "TRUST_FILE_SIZE",
    "TRUST_HTTP_FAILED",
    "TRUST_JSON_INVALID",
    "TRUST_KEY_EXPIRED",
    "TRUST_KEY_UNKNOWN",
    "TRUST_MANIFEST_EXPIRED",
    "TRUST_MANIFEST_TOO_LARGE",
    "TRUST_MAVEN_INVALID",
    "TRUST_METADATA_TOO_LARGE",
    "TRUST_MODULE_INVALID",
    "TRUST_MODULE_LIMIT",
    "TRUST_MUTABLE_INVALID",
    "TRUST_NETWORK_FAILED",
    "TRUST_NETWORK_TIMEOUT",
    "TRUST_OFFLINE_INSTALL_NOT_VERIFIED",
    "TRUST_PATH_DUPLICATE",
    "TRUST_PATH_ESCAPE",
    "TRUST_PATH_INVALID",
    "TRUST_PATH_LINK",
    "TRUST_PAYLOAD_INVALID",
    "TRUST_PURPOSE_INVALID",
    "TRUST_REDIRECT_LIMIT",
    "TRUST_REPAIR_NOT_STARTED",
    "TRUST_REPAIR_NOT_VERIFIED",
    "TRUST_ROLLBACK",
    "TRUST_SERVER_INVALID",
    "TRUST_SIGNATURE_INVALID",
    "TRUST_TEAM_INVALID",
    "TRUST_UNSIGNED_CACHE_DISABLED",
    "TRUST_UPDATE_INVALID",
    "TRUST_UPDATE_NOT_APPROVED",
    "TRUST_URL_INVALID",
    "TRUST_URL_NOT_APPROVED",
    "TRUST_VENDOR_DOWNLOAD_INVALID",
    "TRUST_VENDOR_METADATA_HASH",
    "TRUST_VENDOR_METADATA_INVALID",
    "TRUST_VENDOR_URL_INVALID"
])

function publicError(error) {
    const network = new Set(['ENETUNREACH','EHOSTUNREACH','ENOTFOUND','EAI_AGAIN','ETIMEDOUT','ECONNRESET','ECONNREFUSED','ERR_NETWORK'])
    const code = PUBLIC_FAILURE_CODES.has(error?.code) ? error.code : network.has(error?.code) ? 'NETWORK_UNAVAILABLE' : 'REQUEST_FAILED'
    return {code, message: '요청을 완료하지 못했습니다. 기존 계정과 파일은 유지됩니다.'}
}

module.exports = {externalURL, trustedSender, boundedPath, validatePreferences, jsonObject, invalid, publicError, validateJVMOptions}
