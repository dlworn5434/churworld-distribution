
// Requirements
const { app, BrowserWindow, ipcMain, Menu, shell, dialog, safeStorage, clipboard } = require('electron')
const ejse                              = require('ejs-electron')
const fs                                = require('fs')
const isDev                             = require('./app/assets/js/isdev')
const path                              = require('path')
const semver                            = require('semver')
const { pathToFileURL }                 = require('url')
const { AZURE_CLIENT_ID } = require('./app/assets/js/ipcconstants')
const LangLoader                        = require('./app/assets/js/langloader')
const { checkMacUpdate }                 = require('./app/assets/js/macupdates')
const { MacAutoUpdater }                 = require('./app/assets/js/macautoupdater')
const { ProtectedConfigStore }           = require('./app/assets/js/protectedconfig')
const { prepareCredentialCrypto }        = require('./app/assets/js/credentialcrypto')
const createConfigDefaults              = require('./app/assets/js/configdefaults')

// One writer per user profile; a second launcher focuses the existing window.
const ownsProfile = app.requestSingleInstanceLock()
if(!ownsProfile) app.quit()
app.on('second-instance', () => {
    if(win && !win.isDestroyed()) {
        if(win.isMinimized()) win.restore()
        win.show()
        win.focus()
    }
})
let configStore
let storageStarting = false
let storageWarningShown = false
const mainDocumentURL = pathToFileURL(path.join(__dirname, 'app', 'app.ejs')).toString()

function showStorageWarning(result) {
    if(result?.warning && !storageWarningShown) {
        storageWarningShown = true
        const cleanupPending = result.warning === 'CONFIG_LEGACY_CLEANUP_PENDING'
        setImmediate(() => { dialog.showMessageBox({type: 'warning', title: '설정 저장 확인',
            message: cleanupPending ? '보호된 로그인 정보는 저장되었지만 이전 설정 파일 정리가 남아 있습니다.' : '변경된 설정은 저장되었지만 파일시스템의 저장 완료 확인에 실패했습니다.',
            detail: cleanupPending ? '기존 파일의 접근 권한을 확인해 주세요. 다음 실행 때 다시 정리합니다.' : '현재 계정과 저장 파일은 같은 상태로 유지됩니다. 저장장치 상태를 확인해 주세요.', buttons: ['확인']}).catch(() => {}) })
    }
    return result
}

// Setup Lang
LangLoader.setupLanguage()

// Only signed descriptors held in main may authorize an installer.
const {getTrustedUpdate, downloadTrustedUpdate, verifyTrustedUpdate} = require('./app/assets/js/trusted-updates')
const {publicError} = require('./app/assets/js/renderer-policy')
const {spawn} = require('node:child_process')
const {randomBytes} = require('node:crypto')
let launcherService, macUpdater, windowsReady
let allowPrerelease = Boolean(semver.prerelease(app.getVersion()))
let checkingUpdate = false, launcherInstallInProgress = false, quitAllowed = false
function notifyUpdate(type, info) {
    if(type === 'realerror') launcherService?.recordFault(info, 'launcher-update')
    if(win && !win.isDestroyed()) win.webContents.send('churu-update', {type, info})
}
function updateView(info) {
    if(!info) return null
    return {version: info.version, releaseName: info.releaseName, releaseNotes: info.releaseNotes,
        releaseDate: info.releaseDate, automatic: true}
}
function getMacUpdater() {
    if(!macUpdater) macUpdater = new MacAutoUpdater({
        appPath: path.dirname(path.dirname(path.dirname(process.execPath))), currentVersion: app.getVersion(),
        arch: process.arch, logPath: path.join(app.getPath('userData'), 'launcher-update.log')})
    return macUpdater
}
async function checkLauncherUpdates() {
    if(isDev || checkingUpdate) return
    checkingUpdate = true
    notifyUpdate('checking-for-update')
    try {
        if(process.platform === 'darwin') {
            if(getMacUpdater().ready) {
                try { await getMacUpdater().verifyReady(); notifyUpdate('update-downloaded', updateView(getMacUpdater().ready)); return }
                catch { await getMacUpdater().invalidateReady() }
            }
            const info = await checkMacUpdate(app.getVersion(), process.arch, allowPrerelease)
            if(!info) notifyUpdate('update-not-available', null)
            else await getMacUpdater().prepare(info, (type, data) => notifyUpdate(type,
                type === 'download-progress' ? {percent: data.percent} : updateView(data)))
        } else if(process.platform === 'win32') {
            if(windowsReady) {
                try { await verifyTrustedUpdate(windowsReady.info, windowsReady.installer); notifyUpdate('update-downloaded', updateView(windowsReady.info)); return }
                catch { windowsReady = null }
            }
            const cacheDirectory = path.join(app.getPath('userData'), 'signed-updates')
            const info = await getTrustedUpdate({platform: process.platform, arch: process.arch,
                currentVersion: app.getVersion(), cacheDirectory, allowPrerelease})
            if(!info) { notifyUpdate('update-not-available', null); return }
            if(!/^[A-Za-z0-9][A-Za-z0-9._-]*\.exe$/i.test(info.artifact.name)) throw new Error('Invalid installer')
            fs.mkdirSync(cacheDirectory, {recursive: true})
            const installer = path.join(cacheDirectory, info.artifact.name)
            notifyUpdate('update-available', updateView(info))
            await downloadTrustedUpdate(info, installer, progress => notifyUpdate('download-progress',
                {percent: Number.isFinite(progress.percent) ? progress.percent : progress.transferred / info.artifact.size * 100}))
            await verifyTrustedUpdate(info, installer)
            windowsReady = {info, installer}
            notifyUpdate('update-downloaded', updateView(info))
        }
    } catch(error) { notifyUpdate('realerror', publicError(error)) }
    finally { checkingUpdate = false }
}
async function installLauncherUpdate(relaunch = true) {
    if(isDev || launcherInstallInProgress) return false
    launcherInstallInProgress = true
    try {
        let installed = false
        if(process.platform === 'darwin') installed = await getMacUpdater().install(relaunch)
        else if(process.platform === 'win32' && windowsReady) {
            const {info, installer} = windowsReady
            await verifyTrustedUpdate(info, installer)
            await new Promise((resolve, reject) => {
                const child = spawn(installer, ['/S', '--updated', ...(relaunch ? ['--force-run'] : [])],
                    {detached: true, stdio: 'ignore', windowsHide: true, shell: false})
                child.once('error', reject)
                child.once('spawn', () => { child.unref(); resolve() })
            })
            installed = true
        }
        if(installed) { quitAllowed = true; app.quit() }
        return installed
    } catch(error) {
        windowsReady = null
        if(macUpdater) await macUpdater.invalidateReady()
        throw error
    } finally { launcherInstallInProgress = false }
}
app.on('before-quit', event => {
    loginController?.cancelAll()
    if(!isDev && !quitAllowed && (windowsReady || macUpdater?.ready)) {
        event.preventDefault()
        installLauncherUpdate(false).catch(error => {
            notifyUpdate('realerror', publicError(error)); quitAllowed = true; app.quit()
        })
    }
})
const updateService = {
    initialize(allow) { allowPrerelease = allow || Boolean(semver.prerelease(app.getVersion())); notifyUpdate('ready'); return true },
    check: checkLauncherUpdates, install: installLauncherUpdate,
    prerelease(allow) { allowPrerelease = allow || Boolean(semver.prerelease(app.getVersion())); return true }
}
app.disableHardwareAcceleration()

// OAuth codes and tokens never cross the renderer bridge.
const OAUTH_CALLBACK = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
let oauthWindow
let loginController
function getLoginController() {
    if(!loginController) loginController = require('./app/assets/js/login-controller').createLoginController({
        beginAttempt: signal => require('./app/assets/js/authmanager').beginMicrosoftLogin(signal),
        acquireBrowserToken: options => require('./app/assets/js/microsoft-browser-login.cjs').acquireMicrosoftBrowserToken({...options, clientId: AZURE_CLIENT_ID}),
        openExternal: url => shell.openExternal(url),
        readClipboard: () => clipboard.readText(), clearClipboard: () => clipboard.clear(),
        notify: value => { if(win && !win.isDestroyed()) win.webContents.send('churu-browser-login', value) }
    })
    return loginController
}
function authCancelled() { const error = new Error('Authentication cancelled'); error.code = 'AUTH_STATE_CHANGED'; return error }
function openOAuth(logout = false) {
    return getLoginController().run(logout ? 'logout' : 'embedded', context => openEmbeddedOAuth(logout, context))
}
function openEmbeddedOAuth(logout, context) {
    if(oauthWindow) return Promise.reject(authCancelled())
    return new Promise((resolve, reject) => {
        const state = randomBytes(32).toString('hex')
        let settled = false, exchanging = false
        const child = new BrowserWindow({title: LangLoader.queryJS(logout ? 'index.microsoftLogoutTitle' : 'index.microsoftLoginTitle'),
            backgroundColor: '#222222', width: 520, height: 600, frame: true,
            icon: getPlatformIcon('ChurWorldApp'),
            webPreferences: {nodeIntegration: false, contextIsolation: true, sandbox: true, devTools: false}})
        oauthWindow = child
        const finish = (error, result) => {
            if(settled) return
            settled = true
            context.signal.removeEventListener('abort', cancelled)
            if(error) reject(error); else resolve(result)
            if(!child.isDestroyed()) child.close()
        }
        const cancelled = () => finish(authCancelled())
        context.signal.addEventListener('abort', cancelled, {once: true})
        child.on('closed', () => { if(oauthWindow === child) oauthWindow = null; if(!settled) { context.cancel(); finish(authCancelled()) } })
        if(context.signal.aborted) { finish(authCancelled()); return }
        child.webContents.setWindowOpenHandler(() => ({action: 'deny'}))
        const navigate = async (event, value) => {
            let url
            try { url = new URL(value) } catch { event.preventDefault?.(); return }
            const officialHost = ['microsoftonline.com', 'live.com', 'microsoft.com', 'windows.net'].some(host => url.hostname === host || url.hostname.endsWith('.' + host))
            if(url.protocol !== 'https:' || url.username || url.password || !officialHost) { event.preventDefault?.(); return }
            if(logout && url.origin === 'https://login.microsoftonline.com' && url.pathname === '/common/oauth2/v2.0/logoutsession') {
                finish(null, true); return
            }
            if(!logout && url.origin + url.pathname === OAUTH_CALLBACK) {
                event.preventDefault?.()
                if(exchanging || settled) return
                if(url.searchParams.get('state') !== state || !url.searchParams.get('code') || url.searchParams.has('error')) {
                    finish(authCancelled()); return
                }
                exchanging = true
                try {
                    await context.attempt.addCode(url.searchParams.get('code'))
                    context.assertActive()
                    finish(null, true)
                } catch(error) { finish(error) }
            }
        }
        child.webContents.on('will-navigate', navigate)
        child.webContents.on('will-redirect', navigate)
        child.webContents.on('did-navigate', navigate)
        child.removeMenu()
        const target = new URL(logout ? 'https://login.microsoftonline.com/common/oauth2/v2.0/logout' : 'https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize')
        if(!logout) for(const [key, value] of Object.entries({prompt: 'select_account', client_id: AZURE_CLIENT_ID,
            response_type: 'code', scope: 'XboxLive.signin offline_access', redirect_uri: OAUTH_CALLBACK, state})) target.searchParams.set(key, value)
        child.loadURL(target.href).catch(() => finish(authCancelled()))
    })
}

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let win

function createWindow() {

    win = new BrowserWindow({
        width: 980,
        height: 552,
        icon: getPlatformIcon('ChurWorldApp'),
        frame: false,
        webPreferences: {
            preload: path.join(__dirname, 'app', 'assets', 'js', 'preloader.js'),
            nodeIntegration: false,
            contextIsolation: true, sandbox: true, devTools: false
        },
        backgroundColor: '#171614'
    })
    win.webContents.on('preload-error', () => {
        dialog.showErrorBox('ChurWorld Launcher', '런처 화면을 준비하지 못했습니다. 기존 계정과 설정은 초기화하지 않았습니다. 런처를 다시 실행해 주세요.')
        app.quit()
    })

    const data = {
        bkid: Math.floor((Math.random() * fs.readdirSync(path.join(__dirname, 'app', 'assets', 'images', 'backgrounds')).length)),
        lang: (str, placeHolders) => LangLoader.queryEJS(str, placeHolders)
    }
    Object.entries(data).forEach(([key, val]) => ejse.data(key, val))

    win.webContents.on('will-navigate', (event, url) => {
        if(url !== mainDocumentURL) event.preventDefault()
    })
    win.webContents.setWindowOpenHandler(() => ({action: 'deny'}))
    win.webContents.on('will-attach-webview', event => event.preventDefault())
    win.webContents.on('before-input-event', (event, input) => {
        if(input.key === 'F12' || ((input.control || input.meta) && input.shift && ['i', 'j', 'c'].includes(input.key.toLowerCase()))) event.preventDefault()
    })
    win.webContents.setZoomFactor(1)
    win.webContents.setVisualZoomLevelLimits(1, 1)
    win.webContents.session.setPermissionRequestHandler((_contents, _permission, callback) => callback(false))
    win.loadURL(mainDocumentURL)

    /*win.once('ready-to-show', () => {
        win.show()
    })*/

    win.removeMenu()

    win.resizable = true

    win.on('closed', () => {
        loginController?.cancelAll()
        win = null
    })
}

function createMenu() {
    
    if(process.platform === 'darwin') {

        // Extend default included application menu to continue support for quit keyboard shortcut
        let applicationSubMenu = {
            label: 'Application',
            submenu: [{
                label: 'About Application',
                selector: 'orderFrontStandardAboutPanel:'
            }, {
                type: 'separator'
            }, {
                label: 'Quit',
                accelerator: 'Command+Q',
                click: () => {
                    app.quit()
                }
            }]
        }

        // New edit menu adds support for text-editing keyboard shortcuts
        let editSubMenu = {
            label: 'Edit',
            submenu: [{
                label: 'Undo',
                accelerator: 'CmdOrCtrl+Z',
                selector: 'undo:'
            }, {
                label: 'Redo',
                accelerator: 'Shift+CmdOrCtrl+Z',
                selector: 'redo:'
            }, {
                type: 'separator'
            }, {
                label: 'Cut',
                accelerator: 'CmdOrCtrl+X',
                selector: 'cut:'
            }, {
                label: 'Copy',
                accelerator: 'CmdOrCtrl+C',
                selector: 'copy:'
            }, {
                label: 'Paste',
                accelerator: 'CmdOrCtrl+V',
                selector: 'paste:'
            }, {
                label: 'Select All',
                accelerator: 'CmdOrCtrl+A',
                selector: 'selectAll:'
            }]
        }

        // Bundle submenus into a single template and build a menu object with it
        let menuTemplate = [applicationSubMenu, editSubMenu]
        let menuObject = Menu.buildFromTemplate(menuTemplate)

        // Assign it to the application
        Menu.setApplicationMenu(menuObject)

    }

}

function getPlatformIcon(filename){
    let ext
    switch(process.platform) {
        case 'win32':
            ext = 'ico'
            break
        case 'darwin':
        case 'linux':
        default:
            ext = 'png'
            break
    }

    return path.join(__dirname, 'app', 'assets', 'images', `${filename}.${ext}`)
}

async function startLauncher() {
    if(!ownsProfile || storageStarting) return
    storageStarting = true
    const progress = new BrowserWindow({width: 430, height: 170, show: true, resizable: false,
        title: 'ChurWorld Launcher', backgroundColor: '#171614',
        webPreferences: {nodeIntegration: false, contextIsolation: true, sandbox: true}})
    progress.removeMenu()
    const progressHTML = '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><body style="background:#171614;color:#f3e9d8;font:16px sans-serif;padding:20px"><b>로그인 정보 보호 준비 중</b><p>처음 실행할 때는 잠시 걸릴 수 있습니다.</p></body>'
    await progress.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(progressHTML))
    let cancelled = false
    progress.on('closed', () => { cancelled = true })
    try {
        while(!cancelled) {
            try {
                const encryption = await prepareCredentialCrypto({app, safeStorage})
                if(cancelled) break
                const sysRoot = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Application Support' : process.env.HOME)
                const dataPath = path.join(sysRoot, '.helioslauncher')
                configStore = new ProtectedConfigStore({directory: app.getPath('userData'), legacyPath: path.join(dataPath, 'config.json'), encryption})
                configStore.load(createConfigDefaults(dataPath))
                if(!launcherService) launcherService = require('./app/assets/js/launcher-service').createLauncherService({
                    app, ipcMain, dialog, shell, windowFor: () => win, documentURL: mainDocumentURL,
                    store: {result: () => showStorageWarning(configStore.result()), save: (value, revision) => showStorageWarning(configStore.save(value, revision))},
                    update: updateService, login: () => openOAuth(), logout: () => openOAuth(true),
                    browserLogin: {
                        start: () => getLoginController().startBrowser(),
                        complete: id => getLoginController().completeBrowser(id),
                        cancel: id => getLoginController().cancelBrowser(id),
                        reopen: id => getLoginController().reopenBrowser(id)
                    }})
                createMenu()
                createWindow()
                progress.destroy()
                return
            } catch(error) {
                const code = /^[A-Z_]+$/.test(error.code || '') ? error.code : 'CONFIG_UNAVAILABLE'
                const canRecover = code === 'CONFIG_RECOVERY_REQUIRED'
                const description = canRecover
                    ? '현재 설정 파일이 없고 보호된 이전 설정이 남아 있습니다. 복구하면 이전 저장 시점의 계정과 설정으로 돌아갑니다.'
                    : '기존 계정과 설정을 초기화하지 않았습니다.\n맥에서는 키체인 접근을 허용한 뒤 다시 시도해 주세요.'
                const choice = await dialog.showMessageBox(progress, {type: 'warning', title: '로그인 정보 보호',
                    message: '저장된 로그인 정보를 안전하게 열지 못했습니다.',
                    detail: `${description}\n문제가 계속되면 아래 코드만 알려 주세요.\n\n${code}`,
                    buttons: canRecover ? ['이전 설정 복구', '설정 폴더 열기', '닫기'] : ['다시 시도', '설정 폴더 열기', '닫기'], defaultId: canRecover ? 2 : 0, cancelId: 2})
                if(choice.response === 1) await shell.openPath(app.getPath('userData'))
                else if(choice.response === 2) break
                else if(canRecover) {
                    try { configStore.recoverPrevious() }
                    catch { await dialog.showMessageBox(progress, {type: 'warning', message: '이전 설정을 복구하지 못했습니다. 파일은 보존됩니다.', buttons: ['확인']}) }
                }
            }
        }
    } finally {
        storageStarting = false
        if(!progress.isDestroyed()) progress.destroy()
        if(!configStore?.loaded) app.quit()
    }
}

app.on('ready', () => { startLauncher().catch(() => {
    dialog.showErrorBox('ChurWorld Launcher', '런처를 준비하지 못했습니다. 기존 설정은 보존됩니다. 다시 실행해 주세요.')
    app.quit()
}) })

app.on('window-all-closed', () => {
    // On macOS it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin' && !storageStarting) {
        app.quit()
    }
})

app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (win === null && configStore?.loaded && !storageStarting) {
        createWindow()
    }
})
