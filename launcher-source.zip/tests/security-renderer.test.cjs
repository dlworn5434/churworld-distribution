'use strict'
const {test} = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), vm = require('node:vm')
const {EventEmitter} = require('node:events')
const {validatePreferences, validateJVMOptions, externalURL, boundedPath, trustedSender, publicError} = require('../app/assets/js/renderer-policy')
const root = path.resolve(__dirname, '..')
const clone = structuredClone
function preferences(directory) { return {settings:{game:{resWidth:1280,resHeight:720,fullscreen:false,autoConnect:true,launchDetached:true},launcher:{allowPrerelease:false,dataDirectory:directory}},javaConfig:{s:{minRAM:'2G',maxRAM:'4G',executable:null,jvmOptions:['-XX:+UseG1GC']}},modConfigurations:[{id:'s',mods:{a:true}}],newsCache:{content:null,date:null,dismissed:false},selectedServer:'s',selectedDestination:'life'} }
function load(name, mocks) {
    const module={exports:{}}; const context={module,exports:module.exports,require(id){return Object.hasOwn(mocks,id)?mocks[id]:require(id)},
        __dirname:path.join(root,'app/assets/js'),process,Buffer,console:{log(){},warn(){},error(){}},structuredClone,URL,Set,Map,setTimeout,clearTimeout}
    vm.runInNewContext(fs.readFileSync(path.join(root,'app/assets/js',name),'utf8'),context,{filename:name});return module.exports
}
test('bridge denies wrong window, child frame and changed URL',()=>{
    const mainFrame={url:'file:///app.ejs'}, webContents={mainFrame}, win={webContents,isDestroyed:()=>false}, e={sender:webContents,senderFrame:mainFrame}
    assert.equal(trustedSender(e,win,mainFrame.url),true)
    for(const event of [{...e,sender:{}},{...e,senderFrame:{url:mainFrame.url}}])assert.equal(trustedSender(event,win,mainFrame.url),false)
    assert.equal(trustedSender(e,win,'https://foreign.invalid'),false)
})
test('external links are HTTPS and explicit hosts only',()=>{
    assert.equal(externalURL('https://github.com/owner/repo'),'https://github.com/owner/repo')
    for(const url of ['file:///x','javascript:alert(1)','http://github.com','https://github.com.evil.invalid','https://user:pass@github.com','https://github.com:1234'])assert.throws(()=>externalURL(url))
})
test('paths reject traversal, absolute paths and links without touching outside file',()=>{
    const temp=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'churu-path-test-')));fs.writeFileSync(path.join(temp,'inside.jar'),'test')
    try{assert.equal(boundedPath(temp,'inside.jar'),path.join(temp,'inside.jar'));for(const input of ['../outside','/absolute','C:\\outside','folder/../../x','x:stream','./inside.jar','a//b'])assert.throws(()=>boundedPath(temp,input,true))
        fs.symlinkSync(temp,path.join(temp,'link'),'junction');assert.throws(()=>boundedPath(temp,'link/inside.jar'))
    }finally{try{fs.unlinkSync(path.join(temp,'link'))}catch(error){if(error.code!=='ENOENT')throw error}fs.rmSync(temp,{recursive:true,force:true})}
})
test('preferences reject credentials, unknown fields, arbitrary executable and JVM execution options',()=>{
    const previous=preferences(os.tmpdir()), validate=value=>validatePreferences(value,previous,['s'],new Set())
    assert.deepEqual(validate(clone(previous)),previous)
    for(const change of [n=>n.authenticationDatabase={},n=>n.settings.launcher.dataDirectory=path.resolve(os.tmpdir(),'unapproved'),n=>n.javaConfig.s.executable=process.execPath,n=>n.selectedServer='../escape',n=>n.settings.game.resWidth=-1,n=>n.javaConfig.s.minRAM='999999999999999999999999999G',n=>n.javaConfig.s.maxRAM='0M']){const next=clone(previous);change(next);assert.throws(()=>validate(next))}
    for(const option of ['-javaagent:x','-agentpath:x','-Xrunjdwp:transport=dt_socket,server=n,address=x:1','--class-path=x','--module-path=x','--upgrade-module-path=x','--patch-module=x','-Djava.system.class.loader=x','-Dsun.boot.library.path=x','-XX:SharedArchiveFile=x','-XX:OnError=anything']){const next=clone(previous);next.javaConfig.s.jvmOptions=[option];assert.throws(()=>validate(next),option)}
    const poisoned=JSON.parse(JSON.stringify(previous).replace('"a":true','"__proto__":{"x":true}'));assert.throws(()=>validate(poisoned))
})
test('existing custom JVM choices survive unrelated settings, only edited options are restricted',()=>{
    const previous=preferences(os.tmpdir());previous.javaConfig.s.jvmOptions=['-Dold.user.preference=true']
    const next=clone(previous);next.settings.game.resWidth=1920
    assert.deepEqual(validatePreferences(next,previous,['s'],new Set()).javaConfig.s.jvmOptions,previous.javaConfig.s.jvmOptions)
    next.javaConfig.s.jvmOptions=['-Dnew.unapproved=true'];assert.throws(()=>validatePreferences(next,previous,['s'],new Set()))
    validateJVMOptions(['-XX:+UnlockExperimentalVMOptions','-XX:+UseG1GC','-XX:G1NewSizePercent=20','-XX:G1ReservePercent=20','-XX:MaxGCPauseMillis=50','-XX:G1HeapRegionSize=32M'])
})
function gameFixture() {
    const state={uuid:'a',revision:1,server:'s',destination:'life',directory:os.tmpdir(),validation:0,builds:0,downloads:0,finished:0,order:[],events:[],failedSpawn:false,offline:false,manifestFailure:false}
    const account={uuid:'a',displayName:'Fixture',accessToken:'FAKE_PRIVATE_TOKEN'}
    const config={getSelectedAccount:()=>state.uuid?{...account,uuid:state.uuid}:null,getAuthRevision:()=>state.revision,getSelectedServer:()=>state.server,getSelectedDestination:()=>state.destination,getDataDirectory:()=>state.directory,
        getCommonDirectory:()=>state.directory,getInstanceDirectory:()=>state.directory,getLauncherDirectory:()=>state.directory,getJavaExecutable:()=>null,setJavaExecutable(){},save(){}}
    const serv={rawServer:{id:'s',minecraftVersion:'1.21.4'},effectiveJavaOptions:{suggestedMajor:21,supported:'>=21'}},distro={getServerById:()=>serv,rawDistribution:{}}
    const distribution={DistroAPI:{getDistribution:async()=>{if(state.manifestFailure)throw Error('manifest');return distro},refreshDistributionOrFallback:async()=>distro,isOfflineOnly:()=>state.offline,
        prepareServerFiles:async()=>state.order.push('signed-prepare')},beginManagedUpdate:async()=>({finish(){state.finished++}}),launchWithManagedMods:async(_d,_s,build)=>{state.order.push('cleanup');return build()}}
    class Repair {constructor(opts){assert.equal(opts.distribution,distro);this.childProcess=new EventEmitter();state.order.push('repair-create')}
        spawnReceiver(){state.order.push('repair-start')} async verifyFiles(){state.order.push('verify');return 0} async download(){state.downloads++}
        async getLaunchMetadata(){return {vanilla:{},mod:{}}}destroyReceiver(){state.order.push('repair-stop')}}
    class Builder {build(){state.builds++;state.order.push('spawn');const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.churuSpawnFailed=state.failedSpawn;return child}}
    const auth={validateSelected:async()=>{state.validation++;if(state.validateHook)return state.validateHook(state.validation);return true}}
    const Java={validateSelectedJvm:async()=>null,discoverBestJvmInstallation:async()=>null,latestOpenJDK:async()=>{state.downloads++;throw Error('no synthetic download')}}
    class AuthError extends Error{constructor(code){super(code);this.code=code}}
    const module=load('game-service.js',{'helios-core/dl':{downloadFile:async()=>{throw Error('network forbidden')}},'helios-core/common':{},'helios-core/java':Java,'helios-core':{LoggerUtil:{getLogger:()=>({warn(){}})}},
        './trusted-repair':{TrustedRepair:Repair},'./configmanager':config,'./authmanager':auth,'./processbuilder':Builder,'./discordwrapper':{},'./auth-errors':{AuthError},'./langloader':{queryJS:x=>x},'./configuration-sync':{syncModConfigurations(){},ensureJavaSettings(){}}})
    const service=module.createGameService({distribution,version:'test',emit:event=>state.events.push(event),approvedPaths:new Set()})
    return {state,service}
}
test('main launch validates twice, signed prepare precedes repair and cleanup precedes spawn',async()=>{
    const {state,service}=gameFixture();assert.equal(await service.launch(),true);assert.equal(state.validation,2);assert.equal(state.builds,1);assert.equal(state.finished,1);assert.equal(service.isBusy(),false)
    assert.ok(state.order.indexOf('signed-prepare')<state.order.indexOf('repair-start'));assert.ok(state.order.indexOf('repair-stop')<state.order.indexOf('cleanup'));assert.ok(state.order.indexOf('cleanup')<state.order.indexOf('spawn'))
})
for(const change of ['uuid','server','destination','directory'])test('final authentication await cannot silently change launch '+change,async()=>{
    const {state,service}=gameFixture();state.validateHook=async n=>{if(n===2){state[change]='changed';state.revision++}return true}
    await assert.rejects(service.launch(),e=>e.code==='AUTH_STATE_CHANGED');assert.equal(state.builds,0);assert.equal(state.finished,1);assert.equal(service.isBusy(),false)
})
test('refresh of same selected account may advance only credential revision',async()=>{
    const {state,service}=gameFixture();state.validateHook=async n=>{if(n===2)state.revision++;return true};await service.launch();assert.equal(state.builds,1)
})
test('invalid and temporary authentication keep account and never prepare game',async()=>{
    for(const result of [false,'temporary']){const {state,service}=gameFixture();state.validateHook=async()=>{if(result==='temporary')throw Object.assign(Error('private'),{code:'AUTH_TEMPORARY_FAILURE'});return result};await assert.rejects(service.launch());assert.equal(state.uuid,'a');assert.equal(state.builds,0);assert.equal(state.finished,0);assert.equal(service.isBusy(),false)}
})
test('Java manifest failure clears busy and offline install never starts download',async()=>{
    const {state,service}=gameFixture();state.manifestFailure=true;await assert.rejects(service.installJava());assert.equal(service.isBusy(),false)
    state.manifestFailure=false;state.offline=true;await assert.rejects(service.installJava());assert.equal(state.downloads,0);assert.equal(service.isBusy(),false)
    state.offline=false;await assert.rejects(service.installJava());assert.equal(state.downloads,1);assert.equal(service.isBusy(),false)
})
test('public failures never return raw network/request secret details',()=>{
    const view=publicError(Object.assign(Error('FAKE_PRIVATE_PASSWORD'),{code:'AUTH_TEMPORARY_FAILURE',request:{password:'FAKE_PRIVATE_PASSWORD'}}))
    assert.equal(view.code,'AUTH_TEMPORARY_FAILURE');assert.equal(JSON.stringify(view).includes('FAKE_PRIVATE_PASSWORD'),false)
})

test('immediate spawn failure rejects launch and restores preparation state without exposing child error',async()=>{
    const {state,service}=gameFixture();state.failedSpawn=true
    await assert.rejects(service.launch(),{message:'Minecraft process could not be started'})
    assert.equal(state.builds,1);assert.equal(state.finished,1);assert.equal(service.isBusy(),false)
    assert.equal(JSON.stringify(state.events).includes('FAKE_PRIVATE_TOKEN'),false)
})
