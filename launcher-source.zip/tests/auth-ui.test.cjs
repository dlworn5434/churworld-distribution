'use strict'
// Actual UI function bodies in isolated VMs; no Electron, account files, network or Java.
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const { test } = require('node:test')
const ROOT = path.resolve(__dirname, '..')
const read = name => fs.readFileSync(path.join(ROOT, 'app', name), 'utf8')
const script = name => read('assets/js/scripts/' + name)
function body(source, name) {
    const match = new RegExp('^(?:(?:async )?function ' + name + '\\(|(?:const|let) ' + name + ' = )', 'm').exec(source)
    assert.ok(match, 'actual function exists: ' + name)
    const end = source.indexOf('\n}', match.index)
    assert.ok(end > match.index)
    const extracted = source.slice(match.index, end + 2)
    new vm.Script(extracted)
    return extracted
}
function element(id) {
    const callbacks = {}
    const attrs = new Map()
    return { id, value: '', disabled: false, style: {}, innerHTML: '', textContent: '', callbacks,
        classList: { add() {}, remove() {} },
        addEventListener(event, fn) { callbacks[event] = fn },
        setAttribute(key, value) { attrs.set(key, value) },
        getAttribute(key) { return attrs.get(key) },
        removeAttribute(key) { attrs.delete(key) }, hasAttribute(key) { return attrs.has(key) },
        click() { return this.onclick ? this.onclick({ preventDefault() {} }) : callbacks.click?.({ preventDefault() {} }) },
        remove() { this.removed = true }, closest() { return this }, getElementsByClassName() { return [] }
    }
}
function fixture(options = {}) {
    const A = { uuid: 'fake-a', type: 'microsoft', displayName: 'FakeA', accessToken: 'FAKE_MC_A' }
    const B = { uuid: 'fake-b', type: 'microsoft', displayName: 'FakeB', accessToken: 'FAKE_MC_B' }
    const state = { accounts: { [A.uuid]: A, [B.uuid]: B }, selected: A.uuid, revision: 0, saves: 0,
        removals: 0, additions: 0, validationCalls: 0, validation: async () => true,
        overlay: [], logs: [], ipc: [], replies: {}, elements: new Map(), views: [], updates: [],
        launchVisible: false, launchEnabled: true, builds: [], repairs: 0, finished: 0, progress: [], verifyCalls: 0,
        view: '#landing', success: '#landing', showFailures: [], createdBuilders: 0, ...options }
    const get = id => {
        if(state.missingIds?.includes(id)) return null
        if(!state.elements.has(id)) state.elements.set(id, element(id))
        return state.elements.get(id)
    }
    const config = {
        getSelectedAccount: () => state.accounts[state.selected], getAuthAccounts: () => state.accounts,
        getAuthAccount: id => state.accounts[id], getAuthRevision: () => state.revision,
        getSelectedServer: () => 'fake-server', getCommonDirectory: () => '/fixture/common',
        getInstanceDirectory: () => '/fixture/instances', getLauncherDirectory: () => '/fixture/launcher',
        setSelectedAccount(id) { state.selected = id; state.revision++; return state.accounts[id] },
        save() { state.saves++ },
        removeAuthAccount(id) { state.removals++; delete state.accounts[id]; state.selected = Object.keys(state.accounts)[0]; state.revision++ },
        addMicrosoftAuthAccount() { state.additions++ }, addMojangAuthAccount() { state.additions++ },
        transactionAuth(fn) {
            const selected = state.selected
            try { const value = fn(); if(state.storageFailure) throw Object.assign(new Error('FAKE_PRIVATE_ERROR'), { code: 'CONFIG_WRITE_FAILED' }); state.saves++; return value }
            catch(e) { state.selected = selected; state.revision++; throw e }
        }
    }
    const log = { info: (...args) => state.logs.push(args), error: (...args) => state.logs.push(args), debug: (...args) => state.logs.push(args) }
    const child = () => ({ stdout: { on() {}, removeListener() {} }, stderr: { on() {}, removeListener() {} }, on() {} })
    const serv = { rawServer: { id: 'fake-server', minecraftVersion: '1.21.4' } }
    const distro = { getServerById: () => serv, rawDistribution: {} }
    const ctx = vm.createContext({
        ConfigManager: config,
        AuthManager: {
            async validateSelected() { state.validationCalls++; return state.validation() },
            addMojangAccount(...args) { state.legacyCalls = (state.legacyCalls || 0) + 1; state.legacyArgs = args; return Promise.resolve(A) },
            addMicrosoftAccount: async () => { state.microsoftCalls = (state.microsoftCalls || 0) + 1; if(state.loginError) throw state.loginError; return A },
            removeMicrosoftAccount: async () => { if(state.logoutError) throw state.logoutError; config.removeAuthAccount(A.uuid) },
            removeMojangAccount: async () => { if(state.logoutError) throw state.logoutError; config.removeAuthAccount(A.uuid) }
        },
        VIEWS: { landing: '#landing', settings: '#settings', loginOptions: '#loginOptions', login: '#login', waiting: '#waiting', welcome: '#welcome' },
        document: { getElementById: get, addEventListener() {}, getElementsByClassName: name => state.classes?.[name] || [] },
        Lang: { queryJS: id => id }, LoggerUtil: { getLogger: () => log }, loggerLanding: log,
        console: log, getCurrentView: () => state.view,
        switchView(from, to, _a, _b, onCurrent, onNext) { state.view = to; state.views.push(to); onCurrent?.(); onNext?.() },
        setOverlayContent(...args) { state.overlay.push(args) }, setOverlayHandler(fn) { state.confirm = fn }, setDismissHandler(fn) { state.dismiss = fn },
        toggleOverlay(value) { state.overlayVisible = value }, loginOptionsCancelEnabled(value) { state.cancelEnabled = value },
        updateSelectedAccount(value) { state.updates.push(value?.uuid) }, prepareSettings: async () => {},
        loginOptionsViewOnLoginSuccess: '#landing', loginOptionsViewOnLoginCancel: '#loginOptions',
        loginOptionsViewOnCancel: '#landing', loginOptionsViewCancelHandler: () => { state.staleCancelCalled = true },
        loginUsername: get('loginUsername'), loginPassword: get('loginPassword'), validateEmail() {},
        MSFT_OPCODE: { OPEN_LOGIN: 'OPEN_LOGIN', REPLY_LOGIN: 'REPLY_LOGIN', OPEN_LOGOUT: 'OPEN_LOGOUT', REPLY_LOGOUT: 'REPLY_LOGOUT' },
        MSFT_REPLY_TYPE: { ERROR: 'ERROR', SUCCESS: 'SUCCESS' }, MSFT_ERROR: { NOT_FINISHED: 'NOT_FINISHED' },
        ipcRenderer: { send(...args) { state.ipc.push(args) }, on(name, fn) { state.replies[name] = fn } },
        isDisplayableError: error => !!error?.title,
        $: () => ({ fadeOut(_time, cb) { cb?.() }, fadeIn(_time, cb) { cb?.() }, show() {}, hide() {}, toggle() {}, toggleClass() {} }),
        setTimeout(fn) { return fn() }, setInterval() {}, clearInterval() {},
        setLaunchDetails() {}, setLaunchPercentage() {}, setDownloadPercentage() {},
        toggleLaunchArea(value) { state.launchVisible = value }, setLaunchEnabled(value) { state.launchEnabled = value },
        showLaunchFailure(...args) { state.showFailures.push(args); state.launchEnabled = true; state.launchVisible = false },
        remote: { app: { getVersion: () => 'fixture' }, getCurrentWindow: () => ({ setProgressBar: value => state.progress.push(value) }) },
        DistroAPI: { refreshDistributionOrFallback: async () => distro, isDevMode: () => false }, onDistroRefresh() {},
        FullRepair: class { constructor() { state.repairs++; this.childProcess = child() } spawnReceiver() {} destroyReceiver() {}
            async verifyFiles() { state.verifyCalls++; await state.onVerify?.(); return 0 } },
        DistributionIndexProcessor: class { async loadModLoaderVersionJson() { return {} } },
        MojangIndexProcessor: class { async getVersionJson() { return {} } },
        ProcessBuilder: class { constructor(_s, _v, _m, account) { state.createdBuilders++; this.account = account } build() { state.builds.push(this.account.uuid); return child() } },
        beginManagedUpdate: async () => ({ finish() { state.finished++ } }),
        launchWithManagedMods: async (_d, _s, build) => { await state.beforeBuild?.(); return build() },
        DiscordWrapper: {}, GAME_JOINED_REGEX: /never/, GAME_LAUNCH_REGEX: /never/, MIN_LINGER: 0,
        proc: null, hasRPC: false, Date, Promise
    })
    const helpers = ['authFailureDetails', 'showAuthFailure', 'showAccountReauthentication', 'validateSelectedAccount', 'setSelectedAccount']
    vm.runInContext(helpers.map(n => body(script('uibinder.js'), n)).join('\n'), ctx)
    return { state, ctx, get, config, A, B }
}
function loadLaunch(f) {
    const c = f.ctx, module = {exports:{}}
    f.config.reload = () => {}
    f.config.getSelectedDestination = () => 'life'
    f.config.getDataDirectory = () => '/fixture'
    c.FullRepair.prototype.getLaunchMetadata = async () => ({vanilla:{},mod:{}})
    c.DistroAPI.prepareServerFiles = async () => {}
    c.DistroAPI.isOfflineOnly = () => false
    const imports = {'helios-core/dl':{},'helios-core/common':{},'helios-core/java':{},
        'helios-core':{LoggerUtil:{getLogger:()=>({warn(){}})}}, './trusted-repair':{TrustedRepair:c.FullRepair},
        './configmanager':f.config,'./authmanager':c.AuthManager,'./processbuilder':c.ProcessBuilder,'./discordwrapper':{},
        './auth-errors':{AuthError:class extends Error{constructor(code){super(code);this.code=code}}},'./langloader':c.Lang,
        './configuration-sync':{syncModConfigurations(){},ensureJavaSettings(){}}}
    vm.runInNewContext(fs.readFileSync(path.join(ROOT,'app/assets/js/game-service.js'),'utf8'),
        {module,exports:module.exports,require:id=>Object.hasOwn(imports,id)?imports[id]:require(id),process,console})
    const game = module.exports.createGameService({distribution:{DistroAPI:c.DistroAPI,
        beginManagedUpdate:c.beginManagedUpdate,launchWithManagedMods:c.launchWithManagedMods},version:'fixture',emit(){},approvedPaths:new Set()})
    c.window = {launcher:{game}}
    vm.runInContext(body(script('landing.js'),'dlAsync'),c)
}

function loadSettingsAuth(f) {
    const source = script('settings.js')
    const start = source.indexOf('const msftLoginLogger')
    const end = source.indexOf('const settingsCurrentMicrosoftAccounts', start)
    assert.ok(end > start)
    vm.runInContext(source.slice(start, end), f.ctx)
}
const flush = async () => { for(let n = 0; n < 8; n++) await Promise.resolve() }

test('valid account is retained without unnecessary save or overlay', async () => {
    const f = fixture(); assert.equal(await f.ctx.validateSelectedAccount(), true)
    assert.equal(f.state.removals, 0); assert.equal(f.state.saves, 0); assert.equal(f.state.overlay.length, 0)
})
test('definitive reauth and cancel preserve all accounts with no restore callback', async () => {
    const f = fixture(); f.state.validation = async () => false
    assert.equal(await f.ctx.validateSelectedAccount(), false)
    f.state.confirm()
    assert.equal(f.state.view, '#loginOptions'); assert.equal(f.state.cancelEnabled, true)
    assert.equal(f.ctx.loginOptionsViewCancelHandler, null)
    assert.equal(f.ctx.loginOptionsViewOnCancel, '#landing')
    assert.equal(f.state.accounts[f.A.uuid], f.A); assert.equal(f.state.removals, 0); assert.equal(f.state.saves, 0)
})
for(const code of ['AUTH_TEMPORARY_FAILURE', 'AUTH_STORAGE_FAILURE', 'AUTH_INVALID_RESPONSE', 'AUTH_ACCOUNT_ACTION_REQUIRED', 'CONFIG_WRITE_FAILED', 'unknown-secret-code']) {
    test('safe account-preserving UI for ' + code, async () => {
        const f = fixture(); f.state.validation = async () => { throw Object.assign(new Error('FAKE_PRIVATE_ERROR'), { code, request: { password: 'FAKE_PRIVATE_ERROR' } }) }
        assert.equal(await f.ctx.validateSelectedAccount(), false)
        assert.equal(f.state.removals, 0); assert.equal(f.state.saves, 0); assert.equal(f.state.overlay.length, 1)
        assert.ok(!JSON.stringify(f.state.overlay).includes('FAKE_PRIVATE_ERROR'))
        assert.ok(!JSON.stringify(f.state.logs).includes('FAKE_PRIVATE_ERROR'))
    })
}
test('cancelled authentication state change is silent', async () => {
    const f = fixture(); f.state.validation = async () => { throw { code: 'AUTH_STATE_CHANGED' } }
    assert.equal(await f.ctx.validateSelectedAccount(), false); assert.equal(f.state.overlay.length, 0)
})
test('selection changes while validation is pending cannot validate the replacement', async () => {
    const f = fixture(); let resolve
    f.state.validation = () => new Promise(r => { resolve = r })
    const pending = f.ctx.validateSelectedAccount(); f.config.setSelectedAccount(f.B.uuid); resolve(true)
    assert.equal(await pending, false); assert.equal(f.state.overlay.length, 0)
})
test('selection storage failure rolls back before updating account UI', () => {
    const f = fixture({ storageFailure: true })
    assert.equal(f.ctx.setSelectedAccount(f.B.uuid), false)
    assert.equal(f.state.selected, f.A.uuid); assert.equal(f.state.updates.length, 0)
})
test('committed selection updates UI and starts validation', async () => {
    const f = fixture(); assert.equal(f.ctx.setSelectedAccount(f.B.uuid), true); await flush()
    assert.equal(f.state.selected, f.B.uuid); assert.deepEqual(f.state.updates, [f.B.uuid]); assert.equal(f.state.validationCalls, 1)
})
test('no account cannot pass launch authentication', async () => {
    const f = fixture({ selected: null }); assert.equal(await f.ctx.validateSelectedAccount(), false)
    assert.equal(f.state.overlay.length, 1)
})

test('normal launch validates before downloads and immediately before the managed spawn', async () => {
    const f = fixture(); loadLaunch(f); await f.ctx.dlAsync(true)
    assert.deepEqual(f.state.builds, [f.A.uuid]); assert.equal(f.state.validationCalls, 2)
    assert.equal(f.state.verifyCalls, 1); assert.equal(f.state.finished, 1)
})
for(const condition of ['reauth', 'temporary', 'storage', 'cancelled']) {
    test('launch authentication failure restores controls: ' + condition, async () => {
        const f = fixture({ launchEnabled: false, launchVisible: true }); loadLaunch(f)
        f.state.validation = async () => {
            if(condition === 'reauth') return false
            throw { code: { temporary: 'AUTH_TEMPORARY_FAILURE', storage: 'AUTH_STORAGE_FAILURE', cancelled: 'AUTH_STATE_CHANGED' }[condition] }
        }
        await f.ctx.dlAsync(true)
        assert.equal(f.state.builds.length, 0); assert.equal(f.state.repairs, 0)
        assert.equal(f.state.launchEnabled, true); assert.equal(f.state.launchVisible, false)
        assert.equal(f.state.finished, 0); assert.equal(f.state.removals, 0)
    })
}
test('selection changes during file verification cancel before building', async () => {
    const f = fixture(); loadLaunch(f); f.state.onVerify = () => f.config.setSelectedAccount(f.B.uuid)
    await f.ctx.dlAsync(true); assert.equal(f.state.createdBuilders, 0); assert.equal(f.state.builds.length, 0)
    assert.equal(f.state.launchEnabled, true); assert.equal(f.state.overlay.length, 0)
})
test('last-moment change after managed-mod await blocks process creation', async () => {
    const f = fixture(); loadLaunch(f); f.state.beforeBuild = () => f.config.setSelectedAccount(f.B.uuid)
    await f.ctx.dlAsync(true); assert.equal(f.state.createdBuilders, 1); assert.equal(f.state.builds.length, 0)
    assert.equal(f.state.launchEnabled, true); assert.equal(f.state.overlay.length, 0)
})
test('switch away and back to the same UUID is detected by revision', async () => {
    const f = fixture(); loadLaunch(f); f.state.beforeBuild = () => { f.config.setSelectedAccount(f.B.uuid); f.config.setSelectedAccount(f.A.uuid) }
    await f.ctx.dlAsync(true); assert.equal(f.state.builds.length, 0)
})
test('token refresh revision is accepted when authentication itself succeeds', async () => {
    const f = fixture(); loadLaunch(f); f.state.validation = async () => { f.state.revision++; return true }
    await f.ctx.dlAsync(true); assert.deepEqual(f.state.builds, [f.A.uuid])
})
test('token expiration during downloads requests reauth without spawning', async () => {
    const f = fixture(); loadLaunch(f); f.state.validation = async () => f.state.validationCalls === 1
    await f.ctx.dlAsync(true); assert.equal(f.state.builds.length, 0); assert.equal(f.state.overlay.length, 1)
})
test('obsolete renderer debug argument cannot bypass main authentication', async () => {
    const f = fixture(); loadLaunch(f); f.state.validation = async () => false; await f.ctx.dlAsync(false)
    assert.equal(f.state.validationCalls, 1); assert.equal(f.state.builds.length, 0); assert.equal(f.state.verifyCalls, 0)
})

test('old password form is inert and redirects click or submit to Microsoft', () => {
    const f = fixture()
    // Remove predeclared names so the actual script can own its const bindings.
    delete f.ctx.loginUsername; delete f.ctx.loginPassword; delete f.ctx.validateEmail
    vm.runInContext(script('login.js'), f.ctx)
    assert.equal(f.get('loginPassword').disabled, true); assert.equal(f.get('loginUsername').disabled, true)
    f.get('loginUsername').value = 'fake@example.invalid'; f.get('loginPassword').value = 'FAKE_PRIVATE_ERROR'
    f.get('loginButton').click()
    assert.equal(f.get('loginPassword').value, ''); assert.equal(f.state.legacyCalls || 0, 0)
    assert.equal(f.state.ipc[0][0], 'OPEN_LOGIN')
    f.get('loginPassword').value = 'FAKE_PRIVATE_ERROR'; let prevented = false
    f.get('loginForm').onsubmit({ preventDefault() { prevented = true } })
    assert.equal(prevented, true); assert.equal(f.get('loginPassword').value, '')
    f.ctx.formDisabled(false); assert.equal(f.get('loginPassword').disabled, true)
})
for(const legacyPresent of [false, true]) {
    test('Microsoft-only login options handle ' + (legacyPresent ? 'old' : 'new') + ' template', () => {
        const f = fixture({ missingIds: legacyPresent ? [] : ['loginOptionMojang'] })
        delete f.ctx.loginOptionsViewOnLoginSuccess; delete f.ctx.loginOptionsViewOnLoginCancel
        delete f.ctx.loginOptionsViewOnCancel; delete f.ctx.loginOptionsViewCancelHandler; delete f.ctx.loginOptionsCancelEnabled
        vm.runInContext(script('loginOptions.js'), f.ctx)
        if(legacyPresent) f.get('loginOptionMojang').onclick({})
        else f.get('loginOptionMicrosoft').onclick({})
        assert.equal(f.state.ipc[0][0], 'OPEN_LOGIN'); assert.equal(f.state.view, '#waiting')
    })
}
test('templates contain no Mojang add/login action while old account list is retained', () => {
    assert.ok(!read('loginOptions.ejs').includes('id="loginOptionMojang"'))
    assert.ok(!read('settings.ejs').includes('id="settingsAddMojangAccount"'))
    assert.ok(read('settings.ejs').includes('id="settingsCurrentMojangAccounts"'))
})
test('OAuth error query and description never enter logs or HTML', async () => {
    const f = fixture({ missingIds: ['settingsAddMojangAccount'] }); loadSettingsAuth(f)
    f.state.replies.REPLY_LOGIN(null, 'SUCCESS', { error: 'FAKE_PRIVATE_ERROR', error_description: '<img src=x>FAKE_PRIVATE_ERROR', code: 'FAKE_PRIVATE_ERROR' }, '#settings')
    await flush(); assert.equal(f.state.microsoftCalls || 0, 0)
    assert.ok(!JSON.stringify([f.state.logs, f.state.overlay]).includes('FAKE_PRIVATE_ERROR'))
})
test('normal Microsoft reply carries only the completed account summary and keeps success UI', async () => {
    const f = fixture(); loadSettingsAuth(f)
    f.state.replies.REPLY_LOGIN(null, 'SUCCESS', {uuid:f.A.uuid,displayName:f.A.displayName,type:'microsoft'}, '#settings'); await flush()
    assert.equal(f.state.microsoftCalls || 0, 0); assert.deepEqual(f.state.updates, [f.A.uuid]); assert.equal(f.state.view, '#settings')
})
test('raw login error is replaced by fixed safe text; cancelled stale login is silent', async () => {
    for(const code of ['AUTH_STORAGE_FAILURE', 'AUTH_STATE_CHANGED']) {
        const f = fixture({ loginError: { code, message: 'FAKE_PRIVATE_ERROR', cause: { password: 'FAKE_PRIVATE_ERROR' } } }); loadSettingsAuth(f)
        f.state.replies.REPLY_LOGIN(null, 'ERROR', f.state.loginError, '#settings'); await flush()
        assert.ok(!JSON.stringify([f.state.logs, f.state.overlay]).includes('FAKE_PRIVATE_ERROR'))
        assert.equal(f.state.overlay.length, code === 'AUTH_STATE_CHANGED' ? 0 : 1)
    }
})
test('cancelled stale Microsoft login exits the waiting screen without an error overlay', async () => {
    const f = fixture({ view: '#waiting', loginError: { code: 'AUTH_STATE_CHANGED' } }); loadSettingsAuth(f)
    f.state.replies.REPLY_LOGIN(null, 'SUCCESS', { code: 'FAKE_CODE' }, '#settings'); await flush()
    assert.equal(f.state.view, '#settings'); assert.equal(f.state.overlay.length, 0)
})
for(const type of ['microsoft', 'mojang']) {
    for(const last of [false, true]) {
        test(type + ' logout storage failure retains account and visible row; last=' + last, async () => {
            const f = fixture({ view: '#settings', logoutError: { code: 'AUTH_STORAGE_FAILURE', message: 'FAKE_PRIVATE_ERROR' } })
            f.A.type = type
            if(last) delete f.state.accounts[f.B.uuid]
            loadSettingsAuth(f)
            const row = element('row'); row.setAttribute('uuid', f.A.uuid)
            f.ctx.processLogOut(row, last)
            if(type === 'microsoft') f.state.replies.REPLY_LOGOUT(null, 'SUCCESS', f.A.uuid, last)
            await flush()
            assert.equal(f.state.accounts[f.A.uuid], f.A); assert.equal(f.state.selected, f.A.uuid)
            assert.equal(row.removed, undefined); assert.equal(f.state.view, '#settings')
            assert.equal(f.state.overlay.length, 1)
            assert.ok(!JSON.stringify([f.state.logs, f.state.overlay]).includes('FAKE_PRIVATE_ERROR'))
        })
    }
}
test('settings selection storage failure leaves the selected row unchanged', () => {
    const f = fixture({ storageFailure: true }); loadSettingsAuth(f)
    const button = element('select-b'); button.setAttribute('uuid', f.B.uuid)
    f.state.classes = { settingsAuthAccountSelect: [button] }
    f.ctx.bindAuthAccountSelect(); button.onclick({})
    assert.equal(f.state.selected, f.A.uuid); assert.equal(button.hasAttribute('selected'), false)
})
