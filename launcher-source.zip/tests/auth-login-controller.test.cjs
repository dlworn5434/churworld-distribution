'use strict'
const {test} = require('node:test')
const assert = require('node:assert/strict')
const {createLoginController} = require('../app/assets/js/login-controller')
const {createMicrosoftBrowserLogin} = require('../app/assets/js/microsoft-browser-login.cjs')
const turn = () => new Promise(resolve => setImmediate(resolve))
const token = {access_token:'FAKE_PRIVATE_MS',refresh_token:'FAKE_PRIVATE_REFRESH',expires_in:3600,token_type:'Bearer'}
const defer = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a;reject=b}); return {resolve,reject,promise} }
function fixture(options = {}) {
    const events=[], order=[], saved=[], opened=[]
    let clip='', reads=0, clears=0
    const controller = createLoginController({
        beginAttempt: signal => {
            order.push('capture')
            if(options.captureError) throw options.captureError
            return {addTokens: async value => {
                assert.equal(signal.aborted,false)
                order.push('account')
                await options.accountGate?.promise
                if(signal.aborted) throw Object.assign(new Error('cancelled'),{code:'AUTH_STATE_CHANGED'})
                saved.push(value)
            }}
        },
        acquireBrowserToken: args => createMicrosoftBrowserLogin({timeoutMs:500,
            requestToken: async request => {
                order.push('token')
                assert.equal(request.form.code,'FAKE_PRIVATE_CODE')
                await options.tokenGate?.promise
                return {statusCode:200,headers:{'content-type':'application/json'},body:JSON.stringify(token)}
            }} )({...args,clientId:'1ce6e35a-126f-48fd-97fb-54d143ac6d45'}),
        openExternal: async url => { order.push('open'); opened.push(url); if(options.openError) throw options.openError },
        readClipboard: () => {reads++;return options.readClipboard ? options.readClipboard(reads,clip) : clip},
        clearClipboard: () => {clears++;clip=''},
        notify: event => {events.push(event);if(options.notifyError)throw new Error('closed')}
    })
    return {controller,events,order,saved,opened,setClip:value=>{clip=value},
        get reads(){return reads},get clears(){return clears},
        get id(){return events[0]?.id},
        callback(){const auth = new URL(opened[0]);return auth.searchParams.get('redirect_uri')+'?code=FAKE_PRIVATE_CODE&state='+auth.searchParams.get('state')}}
}
test('browser completion keeps secrets in main, captures before browser, and reports success only after account save',async()=>{
    const gate=defer(),f=fixture({accountGate:gate})
    const p=f.controller.startBrowser();await turn()
    assert.deepEqual(f.order,['capture','open']);assert.equal(f.reads,0)
    assert.match(f.id,/^[a-f0-9]{32}$/)
    f.setClip(f.callback());assert.equal(f.controller.completeBrowser(f.id),true)
    await turn();assert.deepEqual(f.order,['capture','open','token','account'])
    assert.equal(f.events.at(-1).status,'checking_account');assert.equal(f.saved.length,0)
    assert.equal(f.clears,1);gate.resolve();assert.equal(await p,true)
    assert.deepEqual(f.saved,[token]);assert.equal(f.events.at(-1).status,'complete')
    assert.equal(JSON.stringify(f.events).includes('FAKE_PRIVATE'),false)
    for(const event of f.events)assert.deepEqual(Object.keys(event),['id','status'])
    assert.throws(()=>f.controller.completeBrowser(f.id),{code:'AUTH_STATE_CHANGED'})
})
test('invalid URL, huge text and wrong operation never clear clipboard or kill a waiting login',async()=>{
    const f=fixture(),p=f.controller.startBrowser();await turn()
    const result=assert.rejects(p,{code:'AUTH_STATE_CHANGED'})
    assert.throws(()=>f.controller.completeBrowser('f'.repeat(32)),{code:'AUTH_STATE_CHANGED'})
    assert.equal(f.reads,0)
    for(const value of ['unrelated text','https://evil.invalid/?code=FAKE_PRIVATE','x'.repeat(32769)]){
        f.setClip(value);assert.throws(()=>f.controller.completeBrowser(f.id),{code:'AUTH_BROWSER_LINK_INVALID'})
    }
    assert.equal(f.clears,0);assert.equal(f.saved.length,0)
    f.controller.cancelBrowser(f.id);await result
    assert.equal(f.events.at(-1).status,'cancelled')
})
test('clipboard changed after acceptance is preserved',async()=>{
    const f=fixture({readClipboard:(reads,value)=>reads===1?value:'new user data'})
    const p=f.controller.startBrowser();await turn();f.setClip(f.callback())
    f.controller.completeBrowser(f.id);await p;assert.equal(f.clears,0)
})
test('cancel during Microsoft exchange blocks downstream account write',async()=>{
    const gate=defer(),f=fixture({tokenGate:gate}),p=f.controller.startBrowser();await turn()
    const rejected=assert.rejects(p,{code:'AUTH_STATE_CHANGED'})
    f.setClip(f.callback());f.controller.completeBrowser(f.id);await turn()
    f.controller.cancelBrowser(f.id);gate.resolve();await rejected;assert.equal(f.saved.length,0)
})
test('cancel during downstream authentication blocks account commit',async()=>{
    const gate=defer(),f=fixture({accountGate:gate}),p=f.controller.startBrowser();await turn()
    const rejected=assert.rejects(p,{code:'AUTH_STATE_CHANGED'})
    f.setClip(f.callback());f.controller.completeBrowser(f.id);await turn()
    f.controller.cancelAll()
    await Promise.race([rejected,new Promise((_resolve,reject)=>setTimeout(()=>reject(new Error('Cancellation waited for network')),100))])
    assert.equal(await f.controller.run('logout',async()=>true),true)
    gate.resolve();await turn();assert.equal(f.saved.length,0)
})
test('one gate covers browser, embedded popup and logout until previous operation settles',async()=>{
    const f=fixture(),gate=defer();let context
    const p=f.controller.run('embedded',async value=>{context=value;await gate.promise;value.assertActive();return true})
    const rejected=assert.rejects(p,{code:'AUTH_STATE_CHANGED'})
    await assert.rejects(f.controller.startBrowser(),{code:'AUTH_LOGIN_BUSY'})
    await assert.rejects(f.controller.run('logout',async()=>true),{code:'AUTH_LOGIN_BUSY'})
    f.controller.cancelAll();assert.equal(context.signal.aborted,true)
    await assert.rejects(f.controller.startBrowser(),{code:'AUTH_LOGIN_BUSY'})
    gate.resolve();await rejected
    assert.equal(await f.controller.run('logout',async c=>{assert.equal(c.attempt,null);return true}),true)
})
test('reopen is bound to one generated URL and stale operation cannot affect retry',async()=>{
    const f=fixture(),p=f.controller.startBrowser();await turn()
    const rejected=assert.rejects(p,{code:'AUTH_STATE_CHANGED'}),old=f.id
    assert.equal(await f.controller.reopenBrowser(old),true);assert.equal(f.opened[0],f.opened[1])
    assert.equal(f.reads,0);f.controller.cancelBrowser(old);await rejected
    const q=f.controller.startBrowser();await turn();const id=f.events.at(-1).id
    const rejected2=assert.rejects(q,{code:'AUTH_STATE_CHANGED'})
    assert.notEqual(id,old);assert.throws(()=>f.controller.cancelBrowser(old),{code:'AUTH_STATE_CHANGED'})
    f.controller.cancelBrowser(id);await rejected2
})
test('capture failure, browser open failure and closed UI leave gate reusable',async()=>{
    const f=fixture({captureError:Object.assign(new Error('storage'),{code:'AUTH_STORAGE_FAILURE'})})
    await assert.rejects(f.controller.startBrowser(),{code:'AUTH_STORAGE_FAILURE'});assert.equal(f.opened.length,0)
    assert.equal(await f.controller.run('logout',async()=>true),true)
    const g=fixture({openError:new Error('RAW_PRIVATE_URL')})
    await assert.rejects(g.controller.startBrowser(),error=>!error.message.includes('RAW_PRIVATE'))
    assert.equal(await g.controller.run('logout',async()=>true),true)
    const h=fixture({notifyError:true}),p=h.controller.startBrowser();await turn()
    h.setClip(h.callback());h.controller.completeBrowser(h.id);await p;assert.equal(h.saved.length,1)
})
