const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const crypto = require('node:crypto')
const vm = require('node:vm')
const {ProtectedConfigStore} = require('../app/assets/js/protectedconfig')
const defaults = require('../app/assets/js/configdefaults')

function cipher(key = crypto.randomBytes(32)) {
    return {
        encryptString(text) {
            const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', key, iv)
            const body = Buffer.concat([c.update(text, 'utf8'), c.final()])
            return Buffer.concat([iv, c.getAuthTag(), body])
        },
        decryptString(bytes) {
            const c = crypto.createDecipheriv('aes-256-gcm', key, bytes.subarray(0,12))
            c.setAuthTag(bytes.subarray(12,28))
            return Buffer.concat([c.update(bytes.subarray(28)), c.final()]).toString('utf8')
        }
    }
}
function fixture(t) {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'churu-storage-test-'))
    t.after(() => fs.rmSync(directory, {recursive:true,force:true}))
    const encryption = cipher()
    const make = extra => new ProtectedConfigStore({directory, encryption, ...extra})
    const data = defaults(path.join(directory, 'game'))
    data.selectedAccount = 'fake-a'
    data.clientToken = 'SYNTHETIC-CLIENT-SECRET'
    data.authenticationDatabase = {
        'fake-a': {uuid:'fake-a',type:'microsoft',username:'Fake',displayName:'Fake',accessToken:'SYNTHETIC-MC-SECRET',expiresAt:9999999999999,
            microsoft:{access_token:'SYNTHETIC-MS-SECRET',refresh_token:'SYNTHETIC-REFRESH-SECRET',expires_at:9999999999999}},
        'fake-b': {uuid:'fake-b',type:'mojang',username:'fake@example.invalid',displayName:'FakeOld',accessToken:'SYNTHETIC-OLD-SECRET'}
    }
    const file = path.join(directory,'config.json')
    const write = value => fs.writeFileSync(file, JSON.stringify(value))
    const original = () => fs.readFileSync(file)
    return {directory,encryption,make,data,file,write,original}
}
function noSecrets(directory) {
    for(const name of fs.readdirSync(directory)) {
        const file = path.join(directory,name)
        if(fs.statSync(file).isFile()) assert.doesNotMatch(fs.readFileSync(file,'utf8'), /SYNTHETIC-(MC|MS|REFRESH|OLD|CLIENT)-SECRET/)
    }
}
function configManager(f, store, shouldFail = () => false) {
    const exports = {}
    const requireStub = id => {
        if(id === 'electron') return {app:{getPath(){ return f.directory }}}
        if(id === 'helios-core') return {LoggerUtil:{getLogger(){ return {info(){},error(){}} }}}
        if(id === './configdefaults') return defaults
        return require(id)
    }
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../app/assets/js/configmanager.js'),'utf8'), {
        exports, require:requireStub, structuredClone, console,
        process:{platform:process.platform, arch:process.arch, env:{APPDATA:f.directory, HOME:f.directory}}
    })
    exports.bindStorage({
        result: () => store.result(),
        save(config, revision) {
            if(shouldFail()) throw Object.assign(new Error('Synthetic storage failure'), {code:'CONFIG_WRITE_FAILED'})
            return store.save(config, revision)
        }
    })
    exports.load()
    return exports
}

test('legacy credentials migrate without changing account, preferences or runtime token shape', t => {
    const f=fixture(t);f.write(f.data)
    const store=f.make(), loaded=store.load(defaults('unused'))
    assert.deepEqual(loaded.config,f.data);assert.equal(loaded.firstLaunch,false)
    assert.equal(loaded.config.authenticationDatabase['fake-a'].accessToken,'SYNTHETIC-MC-SECRET')
    noSecrets(f.directory)
    assert.deepEqual(f.make().load(defaults('unused')).config,f.data)
    noSecrets(f.directory)
})
test('first launch remains first launch after main persisted defaults', t => {
    const f=fixture(t),store=f.make(), first=store.load(defaults('game'))
    assert.equal(first.firstLaunch,true);assert.equal(store.result().firstLaunch,true)
    assert.equal(f.make().load(defaults('game')).firstLaunch,false)
})
test('settings saves preserve credentials encrypted and backup is encrypted too', t => {
    const f=fixture(t);f.write(f.data);const store=f.make(),loaded=store.load(defaults('unused'))
    loaded.config.settings.game.resWidth=1920
    const saved=store.save(loaded.config,loaded.revision)
    assert.ok(saved.revision>loaded.revision);noSecrets(f.directory)
    assert.equal(f.make().load(defaults('unused')).config.settings.game.resWidth,1920)
    assert.equal(fs.existsSync(store.previousFile),true)
})
test('legacy separate path is removed only after encrypted destination verifies', t => {
    const f=fixture(t),legacy=path.join(f.directory,'legacy.json')
    fs.writeFileSync(legacy,JSON.stringify(f.data))
    const store=f.make({legacyPath:legacy});assert.deepEqual(store.load(defaults('unused')).config,f.data)
    assert.equal(fs.existsSync(legacy),false);noSecrets(f.directory)
})
test('encryption failure leaves original plaintext migration source exact', t => {
    const f=fixture(t);f.write(f.data);const before=f.original()
    const store=f.make({encryption:{encryptString(){throw Error('SYNTHETIC-secret')},decryptString(){throw Error('SYNTHETIC-secret')}}})
    assert.throws(()=>store.load(defaults('unused')), {code:'CONFIG_KEY_UNAVAILABLE'})
    assert.deepEqual(f.original(),before)
    assert.deepEqual(fs.readdirSync(f.directory),['config.json'])
})
test('malformed JSON is not replaced with defaults', t => {
    const f=fixture(t);fs.writeFileSync(f.file,'{"broken":');const before=f.original()
    assert.throws(()=>f.make().load(defaults('unused')),{code:'CONFIG_CORRUPT'})
    assert.deepEqual(f.original(),before)
})
test('locked or changed OS key preserves exact encrypted file', t => {
    const f=fixture(t);f.write(f.data);f.make().load(defaults('unused'));const before=f.original()
    assert.throws(()=>f.make({encryption:cipher()}).load(defaults('unused')),{code:'CONFIG_KEY_UNAVAILABLE'})
    assert.deepEqual(f.original(),before)
})
test('tampering is rejected with file unchanged', t => {
    const f=fixture(t);f.write(f.data);f.make().load(defaults('unused'))
    const d=JSON.parse(f.original());const b=Buffer.from(d.protectedConfig.ciphertext,'base64');b[31]^=1
    d.protectedConfig.ciphertext=b.toString('base64');f.write(d);const before=f.original()
    assert.throws(()=>f.make().load(defaults('unused')),{code:'CONFIG_KEY_UNAVAILABLE'})
    assert.deepEqual(f.original(),before)
})
test('future schema is not overwritten', t => {
    const f=fixture(t);f.write(f.data);f.make().load(defaults('unused'))
    const d=JSON.parse(f.original());d.protectedConfig.version=200;f.write(d);const before=f.original()
    assert.throws(()=>f.make().load(defaults('unused')),{code:'CONFIG_UNSUPPORTED_VERSION'})
    assert.deepEqual(f.original(),before)
})
test('old-version fresh plaintext mixed with protected generation is preserved for recovery', t => {
    const f=fixture(t);f.write(f.data);f.make().load(defaults('unused'))
    const d=JSON.parse(f.original());d.authenticationDatabase=f.data.authenticationDatabase;f.write(d);const before=f.original()
    assert.throws(()=>f.make().load(defaults('unused')),{code:'CONFIG_MIXED_VERSIONS'})
    assert.deepEqual(f.original(),before)
})
test('stale renderer cannot overwrite a later save', t => {
    const f=fixture(t);f.write(f.data);const store=f.make(),r=store.load(defaults('unused'))
    store.save(r.config,r.revision);const before=f.original()
    assert.throws(()=>store.save(r.config,r.revision),{code:'CONFIG_STALE_WRITE'})
    assert.deepEqual(f.original(),before)
})
test('external file change cannot be overwritten by settings save', t => {
    const f=fixture(t);f.write(f.data);const store=f.make(),r=store.load(defaults('unused'))
    fs.appendFileSync(f.file,' ');const before=f.original()
    assert.throws(()=>store.save(r.config,r.revision),{code:'CONFIG_EXTERNAL_CHANGE'})
    assert.deepEqual(f.original(),before)
})
test('failed atomic replacement retains original and clears only its own temporary file', t => {
    const f=fixture(t);f.write(f.data);const store=f.make(),r=store.load(defaults('unused')),before=f.original()
    const rename=fs.renameSync
    fs.renameSync=(a,b)=>{if(b===f.file){const e=new Error('disk blocked');e.code='EACCES';throw e}return rename(a,b)}
    try { assert.throws(()=>store.save(r.config,r.revision),{code:'CONFIG_WRITE_FAILED'}) }
    finally { fs.renameSync=rename }
    assert.deepEqual(f.original(),before)
    assert.equal(fs.readdirSync(f.directory).some(n=>n.endsWith('.tmp')),false)
    noSecrets(f.directory)
})
test('actual main ConfigManager transaction rolls back account and selection after failed save', t => {
    const f=fixture(t);f.write(f.data);const store=f.make();store.load(defaults('unused'))
    let fail=false
    const exports=configManager(f,store,()=>fail)
    const old=exports.getSelectedAccount(),revision=exports.getAuthRevision();fail=true
    assert.throws(()=>exports.transactionAuth(()=>exports.removeAuthAccount('fake-a')),{code:'CONFIG_WRITE_FAILED'})
    assert.equal(exports.getSelectedAccount(),old);assert.equal(exports.getAuthAccount('fake-a'),old)
    assert.ok(exports.getAuthRevision()>revision)
    assert.throws(()=>exports.transactionAuth(()=>exports.updateMicrosoftAuthAccount('fake-a','new','new','new',111,222)),{code:'CONFIG_WRITE_FAILED'})
    assert.equal(exports.getSelectedAccount().accessToken,'SYNTHETIC-MC-SECRET')
    fail=false;exports.transactionAuth(()=>exports.removeAuthAccount('fake-a'))
    assert.equal(exports.getSelectedAccount().uuid,'fake-b')
    noSecrets(f.directory)
})
test('UI snapshot excludes credentials and cannot mutate the main account database', t => {
    const f=fixture(t);f.write(f.data);const store=f.make();store.load(defaults('unused'))
    const manager=configManager(f,store), snapshot=manager.getPublicState()
    assert.doesNotMatch(JSON.stringify(snapshot), /SYNTHETIC-(MC|MS|REFRESH|OLD|CLIENT)-SECRET/)
    assert.deepEqual(Object.keys(snapshot.authenticationDatabase['fake-a']).sort(), ['displayName','type','uuid'])
    assert.equal(snapshot.authenticationDatabase['fake-a'].displayName, 'Fake')
    snapshot.authenticationDatabase['fake-a'].displayName='Changed only in renderer'
    snapshot.settings.game.resWidth=999
    assert.equal(manager.getSelectedAccount().displayName, 'Fake')
    assert.notEqual(manager.getPublicState().settings.game.resWidth,999)
    assert.equal(manager.getSelectedAccount().accessToken, 'SYNTHETIC-MC-SECRET')
})
test('validated public preference save retains encrypted accounts and rolls back failed settings', t => {
    const f=fixture(t);f.write(f.data);const store=f.make();store.load(defaults('unused'))
    let fail=false
    const manager=configManager(f,store,()=>fail)
    const next=manager.getPublicState()
    next.settings.game.resWidth=1920
    manager.commitPublicPreferences(next)
    assert.equal(manager.getPublicState().settings.game.resWidth,1920)
    assert.equal(f.make().load(defaults('unused')).config.authenticationDatabase['fake-a'].accessToken,'SYNTHETIC-MC-SECRET')
    const before=f.original(), changed=manager.getPublicState()
    changed.settings.game.resWidth=2000
    fail=true
    assert.throws(()=>manager.commitPublicPreferences(changed),{code:'CONFIG_WRITE_FAILED'})
    assert.equal(manager.getPublicState().settings.game.resWidth,1920)
    assert.deepEqual(f.original(),before)
    noSecrets(f.directory)
})
test('missing primary never overwrites the only protected recovery copy', t => {
    const f=fixture(t);f.write(f.data);const first=f.make(),loaded=first.load(defaults('unused'))
    first.save(loaded.config,loaded.revision)
    const previous=fs.readFileSync(first.previousFile)
    fs.unlinkSync(f.file)
    const recovery=f.make()
    assert.throws(()=>recovery.load(defaults('unused')),{code:'CONFIG_RECOVERY_REQUIRED'})
    assert.equal(fs.existsSync(f.file),false)
    assert.deepEqual(fs.readFileSync(first.previousFile),previous)
    recovery.recoverPrevious()
    assert.equal(recovery.load(defaults('unused')).config.selectedAccount,'fake-a')
    assert.throws(()=>recovery.recoverPrevious(),{code:'CONFIG_EXTERNAL_CHANGE'})
})
