'use strict'
// Offline: generated fake auth codes/tokens; only real network traffic is local loopback HTTP.
const {test} = require('node:test')
const assert = require('node:assert/strict')
const http = require('node:http')
const https = require('node:https')
const crypto = require('node:crypto')
const {EventEmitter} = require('node:events')
const {PassThrough} = require('node:stream')
const {createMicrosoftBrowserLogin, MicrosoftBrowserLoginError} = require('../app/assets/js/microsoft-browser-login.cjs')

const CLIENT = '1ce6e35a-126f-48fd-97fb-54d143ac6d45'
const NATIVE = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
const TOKEN_URL = 'https://login.microsoftonline.com/consumers/oauth2/v2.0/token'
const GOOD_TOKEN = {access_token: 'FAKE_PRIVATE_ACCESS_TOKEN', refresh_token: 'FAKE_PRIVATE_REFRESH_TOKEN', expires_in: 3600, token_type: 'Bearer'}
const CODE = 'FAKE_PRIVATE_AUTH_CODE'
const nextTurn = () => new Promise(resolve => setImmediate(resolve))
const response = (body = GOOD_TOKEN, statusCode = 200, headers = {'content-type': 'application/json; charset=utf-8'}) => ({statusCode, headers, body: JSON.stringify(body)})

function start({requestToken, timeoutMs = 1500, requestTimeoutMs, nativeRequest = false, mode = 'copy-link', openBrowser, onStatus, signal} = {}) {
    const controller = new AbortController(), statuses = [], opens = [], calls = []
    let accept, reopen, resolveReady
    const ready = new Promise(resolve => { resolveReady = resolve })
    const dependencies = {timeoutMs}
    if (requestTimeoutMs != null) dependencies.requestTimeoutMs = requestTimeoutMs
    if (!nativeRequest) dependencies.requestToken = async args => {
        calls.push(args)
        return requestToken ? requestToken(args) : response()
    }
    const login = createMicrosoftBrowserLogin(dependencies)
    const result = login({clientId: CLIENT, mode, signal: signal || controller.signal,
        onStatus: (...args) => { assert.equal(args.length, 1); statuses.push(args[0]); return onStatus?.(args[0]) },
        onCallbackReady: callback => { accept = callback }, onReopenReady: callback => { reopen = callback },
        openBrowser: async url => { opens.push(url); resolveReady(new URL(url)); if (openBrowser) await openBrowser(url) }
    })
    const observed = result.then(value => ({value}), error => ({error}))
    return {result, observed, ready, controller, statuses, opens, calls, accept: value => accept(value), reopen: () => reopen()}
}

function callback(authorize, {code = CODE, error, state = authorize.searchParams.get('state'), description} = {}) {
    const url = new URL(authorize.searchParams.get('redirect_uri'))
    url.searchParams.set('state', state)
    if (error) url.searchParams.set('error', error)
    else url.searchParams.set('code', code)
    if (description) url.searchParams.set('error_description', description)
    return url
}

function localRequest(authorize, {target = callback(authorize), method = 'GET', host, path} = {}) {
    const redirect = new URL(authorize.searchParams.get('redirect_uri'))
    return new Promise((resolve, reject) => {
        const request = http.request({hostname: '127.0.0.1', port: Number(redirect.port), method, path: path ?? target.pathname + target.search,
            headers: {Host: host ?? 'localhost:' + redirect.port}, agent: false}, incoming => {
            const chunks = []
            incoming.on('data', data => chunks.push(data))
            incoming.on('end', () => resolve({status: incoming.statusCode, headers: incoming.headers, body: Buffer.concat(chunks).toString('utf8')}))
        })
        request.on('error', reject)
        request.end()
    })
}

function assertSafeError(error, expectedCode, expectedReason) {
    assert.ok(error instanceof MicrosoftBrowserLoginError)
    assert.equal(error.code, expectedCode)
    if (expectedReason) assert.equal(error.reason, expectedReason)
    assert.equal(error.message, expectedCode)
    const serialized = JSON.stringify(error) + String(error.stack)
    for (const secret of [CODE, GOOD_TOKEN.access_token, GOOD_TOKEN.refresh_token, 'SENSITIVE_DESCRIPTION', 'https://attacker.invalid']) assert.ok(!serialized.includes(secret))
    assert.equal(error.cause, undefined)
}

test('copy-link is the default; same native redirect/client/scopes and PKCE-bound main-only token result', async () => {
    const flow = start(), authorize = await flow.ready
    assert.equal(authorize.origin + authorize.pathname, 'https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize')
    assert.equal(authorize.searchParams.get('redirect_uri'), NATIVE)
    assert.equal(authorize.searchParams.get('client_id'), CLIENT)
    assert.equal(authorize.searchParams.get('scope'), 'XboxLive.signin offline_access')
    assert.equal(authorize.searchParams.get('response_type'), 'code')
    assert.equal(authorize.searchParams.get('response_mode'), 'query')
    assert.equal(authorize.searchParams.get('code_challenge_method'), 'S256')
    assert.match(authorize.searchParams.get('state'), /^[A-Za-z0-9_-]{43}$/)
    assert.equal(authorize.searchParams.has('code_verifier'), false)
    assert.equal(flow.accept(callback(authorize).href), true)
    assert.deepEqual(await flow.result, GOOD_TOKEN)
    assert.equal(flow.calls.length, 1)
    const request = flow.calls[0]
    assert.equal(request.url, TOKEN_URL)
    assert.equal(request.form.client_id, CLIENT)
    assert.equal(request.form.code, CODE)
    assert.equal(request.form.redirect_uri, NATIVE)
    assert.equal(request.form.grant_type, 'authorization_code')
    assert.match(request.form.code_verifier, /^[A-Za-z0-9_-]{86}$/)
    assert.equal(crypto.createHash('sha256').update(request.form.code_verifier).digest('base64url'), authorize.searchParams.get('code_challenge'))
    assert.equal(request.timeoutMs, 15000)
    assert.equal(request.maxBytes, 65536)
    assert.ok(flow.statuses.includes('complete'))
    assert.ok(flow.statuses.every(value => ['opening_browser', 'waiting_for_browser', 'exchanging_token', 'complete'].includes(value)))
    assert.ok(!JSON.stringify(flow.statuses).includes(CODE))
})

test('malformed, unrelated, foreign, duplicate, oversize clipboard values leave the legitimate attempt pending', async () => {
    const flow = start(), authorize = await flow.ready, good = callback(authorize)
    const duplicateState = new URL(good); duplicateState.searchParams.append('state', authorize.searchParams.get('state'))
    const duplicateCode = new URL(good); duplicateCode.searchParams.append('code', CODE)
    const both = new URL(good); both.searchParams.set('error', 'access_denied')
    const duplicateError = callback(authorize, {error: 'access_denied'}); duplicateError.searchParams.append('error', 'access_denied')
    const oversizedCode = callback(authorize, {code: 'a'.repeat(8193)})
    const values = [null, {}, 8, '', 'my normal clipboard', 'a'.repeat(17000),
        good.href.replace('https:', 'http:'), good.href.replace('login.microsoftonline.com', 'attacker.invalid'),
        good.href.replace('login.microsoftonline.com', 'login.microsoftonline.com.attacker.invalid'),
        good.href.replace('login.microsoftonline.com', 'user@login.microsoftonline.com'),
        good.href.replace('login.microsoftonline.com', 'login.microsoftonline.com:443'),
        good.href.replace('/nativeclient?', '/nativeclient/evil?'), good.href + '#fragment',
        callback(authorize, {state: 'wrong'}).href, callback(authorize, {state: '한'.repeat(43)}).href,
        callback(authorize, {code: 'two words'}).href, callback(authorize, {code: ''}).href,
        duplicateState.href, duplicateCode.href, duplicateError.href, both.href, oversizedCode.href,
        NATIVE + '?state=' + authorize.searchParams.get('state')]
    for (const value of values) assert.equal(flow.accept(value), false, 'invalid input must not consume flow')
    assert.equal(flow.calls.length, 0)
    assert.equal(flow.accept('  ' + good.href + '\n'), true)
    await flow.result
    assert.equal(flow.calls.length, 1)
})

test('copy-link accepts once; stale callback and reopen are disabled after completion', async () => {
    let completeExchange
    const flow = start({requestToken: () => new Promise(resolve => { completeExchange = resolve })}), authorize = await flow.ready
    const good = callback(authorize).href
    assert.equal(flow.accept(good), true)
    assert.equal(flow.accept(good), false)
    assert.equal(await flow.reopen(), false)
    completeExchange(response())
    await flow.result
    assert.equal(flow.accept(good), false)
    assert.equal(await flow.reopen(), false)
    assert.equal(flow.calls.length, 1)
})

test('reopen uses exactly the same generated main-only URL, state and challenge', async () => {
    const flow = start(), authorize = await flow.ready
    await nextTurn()
    assert.equal(await flow.reopen(), true)
    assert.equal(flow.opens.length, 2)
    assert.equal(flow.opens[0], flow.opens[1])
    flow.accept(callback(authorize).href)
    await flow.result
})

test('independent attempts get distinct state/verifier; callback from another attempt is rejected', async () => {
    const a = start(), b = start(), au = await a.ready, bu = await b.ready
    assert.notEqual(au.searchParams.get('state'), bu.searchParams.get('state'))
    assert.notEqual(au.searchParams.get('code_challenge'), bu.searchParams.get('code_challenge'))
    assert.equal(a.accept(callback(bu).href), false)
    assert.equal(b.accept(callback(au).href), false)
    a.accept(callback(au).href); b.accept(callback(bu).href)
    await Promise.all([a.result, b.result])
    assert.notEqual(a.calls[0].form.code_verifier, b.calls[0].form.code_verifier)
})

for (const [provider, expected] of [['access_denied', 'AUTH_BROWSER_DENIED'], ['invalid_client', 'AUTH_BROWSER_CONFIG_REQUIRED'], ['invalid_request', 'AUTH_BROWSER_CONFIG_REQUIRED'], ['temporarily_unavailable', 'AUTH_TEMPORARY_FAILURE']]) {
    test('valid provider callback maps ' + provider + ' without reflecting details', async () => {
        const flow = start(), authorize = await flow.ready
        assert.equal(flow.accept(callback(authorize, {error: provider, description: 'SENSITIVE_DESCRIPTION ' + CODE}).href), true)
        const {error} = await flow.observed
        assertSafeError(error, expected)
        assert.equal(flow.calls.length, 0)
    })
}

test('cancellation before opening has no browser or token side effects', async () => {
    const controller = new AbortController(); controller.abort()
    const flow = start({signal: controller.signal})
    assertSafeError((await flow.observed).error, 'AUTH_STATE_CHANGED', 'cancelled')
    assert.equal(flow.opens.length, 0); assert.equal(flow.calls.length, 0)
})

test('cancel waiting makes previously registered clipboard callback inert', async () => {
    const flow = start(), authorize = await flow.ready
    flow.controller.abort()
    assertSafeError((await flow.observed).error, 'AUTH_STATE_CHANGED', 'cancelled')
    assert.equal(flow.accept(callback(authorize).href), false)
    assert.equal(await flow.reopen(), false)
    assert.equal(flow.calls.length, 0)
})

test('cancel while exchanging aborts network and ignores a late token response', async () => {
    let release
    const flow = start({requestToken: () => new Promise(resolve => { release = resolve })}), authorize = await flow.ready
    flow.accept(callback(authorize).href)
    assert.equal(flow.calls[0].signal.aborted, false)
    flow.controller.abort()
    assertSafeError((await flow.observed).error, 'AUTH_STATE_CHANGED', 'cancelled')
    assert.equal(flow.calls[0].signal.aborted, true)
    release(response())
    await nextTurn()
    assert.ok(!flow.statuses.includes('complete'))
})

test('flow deadline cancels even a browser-opening promise that never resolves', async () => {
    const flow = start({timeoutMs: 50, openBrowser: () => new Promise(() => {})}), authorize = await flow.ready
    assertSafeError((await flow.observed).error, 'AUTH_BROWSER_TIMEOUT', 'expired')
    assert.equal(flow.accept(callback(authorize).href), false)
})

test('flow deadline aborts a pending token exchange', async () => {
    const flow = start({timeoutMs: 50, requestToken: () => new Promise(() => {})}), authorize = await flow.ready
    flow.accept(callback(authorize).href)
    assertSafeError((await flow.observed).error, 'AUTH_BROWSER_TIMEOUT', 'expired')
    assert.equal(flow.calls[0].signal.aborted, true)
})

test('browser-opening and transport exceptions discard their original sensitive text', async () => {
    const opener = start({openBrowser: async () => { throw new Error(CODE + ' https://attacker.invalid') }})
    assertSafeError((await opener.observed).error, 'AUTH_TEMPORARY_FAILURE', 'browser_open_failed')
    const network = start({requestToken: async () => { throw Object.assign(new Error(GOOD_TOKEN.refresh_token), {response: {body: GOOD_TOKEN}}) }}), authorize = await network.ready
    network.accept(callback(authorize).href)
    assertSafeError((await network.observed).error, 'AUTH_TEMPORARY_FAILURE', 'network')
})

const invalidResponses = [
    ['redirect', {statusCode: 302, headers: {location: 'https://attacker.invalid'}, body: ''}, 'AUTH_INVALID_RESPONSE'],
    ['invalid JSON', {statusCode: 200, headers: {'content-type': 'application/json'}, body: '{' + CODE}, 'AUTH_INVALID_RESPONSE'],
    ['oversized body', {statusCode: 200, headers: {'content-type': 'application/json'}, body: ' '.repeat(65537)}, 'AUTH_INVALID_RESPONSE'],
    ['HTML', response(GOOD_TOKEN, 200, {'content-type': 'text/html'}), 'AUTH_INVALID_RESPONSE'],
    ['missing mime', response(GOOD_TOKEN, 200, {}), 'AUTH_INVALID_RESPONSE'],
    ['array', response([]), 'AUTH_INVALID_RESPONSE'],
    ['null', response(null), 'AUTH_INVALID_RESPONSE'],
    ['missing access', response({...GOOD_TOKEN, access_token: undefined}), 'AUTH_INVALID_RESPONSE'],
    ['missing refresh', response({...GOOD_TOKEN, refresh_token: undefined}), 'AUTH_INVALID_RESPONSE'],
    ['wrong type', response({...GOOD_TOKEN, token_type: 'Basic'}), 'AUTH_INVALID_RESPONSE'],
    ['string expiry', response({...GOOD_TOKEN, expires_in: '3600'}), 'AUTH_INVALID_RESPONSE'],
    ['short expiry', response({...GOOD_TOKEN, expires_in: 10}), 'AUTH_INVALID_RESPONSE'],
    ['unsafe expiry', response({...GOOD_TOKEN, expires_in: Number.MAX_SAFE_INTEGER}), 'AUTH_INVALID_RESPONSE'],
    ['control token', response({...GOOD_TOKEN, access_token: 'bad\ntoken'}), 'AUTH_INVALID_RESPONSE'],
    ['unicode token', response({...GOOD_TOKEN, refresh_token: '비밀'}), 'AUTH_INVALID_RESPONSE'],
    ['error on success', response({...GOOD_TOKEN, error: 'invalid_client'}), 'AUTH_INVALID_RESPONSE'],
    ['configuration', response({error: 'invalid_client', error_description: 'SENSITIVE_DESCRIPTION'}, 400), 'AUTH_BROWSER_CONFIG_REQUIRED'],
    ['invalid grant', response({error: 'invalid_grant', error_description: CODE}, 400), 'AUTH_REAUTH_REQUIRED'],
    ['rate limit', response({error: GOOD_TOKEN.refresh_token}, 429), 'AUTH_TEMPORARY_FAILURE'],
    ['provider unavailable', {statusCode: 503, body: CODE}, 'AUTH_TEMPORARY_FAILURE']
]
for (const [name, reply, expected] of invalidResponses) {
    test('token response rejects ' + name + ' with no retry or sensitive error data', async () => {
        const flow = start({requestToken: async () => reply}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assertSafeError((await flow.observed).error, expected)
        assert.equal(flow.calls.length, 1)
    })
}

test('token response exposes only required fields to main and tolerates failing status notifications', async () => {
    const flow = start({requestToken: async () => response({...GOOD_TOKEN, token_type: 'bearer', untrusted: 'ignore', id_token: 'EXTRA_PRIVATE'}), onStatus: () => Promise.reject(new Error('SENSITIVE_DESCRIPTION'))}), authorize = await flow.ready
    flow.accept(callback(authorize).href)
    assert.deepEqual(await flow.result, GOOD_TOKEN)
    await nextTurn()
})

test('loopback optional mode binds an ephemeral IPv4 listener and returns constant no-store HTML', async () => {
    const flow = start({mode: 'loopback'}), authorize = await flow.ready
    const redirect = new URL(authorize.searchParams.get('redirect_uri'))
    assert.equal(redirect.protocol, 'http:'); assert.equal(redirect.hostname, 'localhost')
    assert.ok(Number(redirect.port) > 0); assert.equal(redirect.pathname, '/')
    const result = await localRequest(authorize)
    assert.equal(result.status, 200)
    assert.match(result.headers['cache-control'], /no-store/)
    assert.equal(result.headers['referrer-policy'], 'no-referrer')
    assert.match(result.headers['content-security-policy'], /default-src 'none'/)
    assert.ok(!result.body.includes(CODE)); assert.ok(!result.body.includes(authorize.searchParams.get('state')))
    assert.deepEqual(await flow.result, GOOD_TOKEN)
    assert.equal(flow.calls[0].form.redirect_uri, redirect.href)
    assert.equal(crypto.createHash('sha256').update(flow.calls[0].form.code_verifier).digest('base64url'), authorize.searchParams.get('code_challenge'))
})

test('unsolicited loopback requests do not consume legitimate pending authentication', async () => {
    const flow = start({mode: 'loopback'}), authorize = await flow.ready
    const duplicate = callback(authorize); duplicate.searchParams.append('state', authorize.searchParams.get('state'))
    const invalid = [
        {target: callback(authorize, {state: 'wrong'})}, {method: 'POST'}, {host: 'attacker.invalid'},
        {path: '/wrong?' + callback(authorize).searchParams.toString()}, {target: duplicate},
        {path: '/?' + 'x='.repeat(9000)}
    ]
    for (const request of invalid) {
        const result = await localRequest(authorize, request)
        assert.equal(result.status, 400)
        assert.ok(!result.body.includes(CODE))
    }
    assert.equal(flow.calls.length, 0)
    await localRequest(authorize)
    await flow.result
    assert.equal(flow.calls.length, 1)
})

test('loopback remote-address boundary rejects unsolicited peers without consuming the pending login', async t => {
    // macOS need not configure 127.0.0.2 as a bindable interface. Keep real
    // IPv4 HTTP transport and inject only peer metadata at the server boundary.
    const originalCreateServer = http.createServer
    let remoteAddress = '127.0.0.2', requests = 0
    t.mock.method(http, 'createServer', function(options, listener) {
        return originalCreateServer.call(this, options, (request, response) => {
            assert.equal(request.socket.remoteAddress, '127.0.0.1')
            Object.defineProperty(request.socket, 'remoteAddress', {value: remoteAddress, configurable: true})
            requests++
            listener(request, response)
        })
    })
    const flow = start({mode: 'loopback'}), authorize = await flow.ready
    try {
        const invalidPeers = ['127.0.0.2', '192.0.2.17', '::1', '::ffff:127.0.0.1', undefined]
        for (const peer of invalidPeers) {
            remoteAddress = peer
            const result = await localRequest(authorize)
            assert.equal(result.status, 400)
            assert.ok(!result.body.includes(CODE))
            assert.equal(flow.calls.length, 0)
        }
        remoteAddress = '127.0.0.1'
        assert.equal((await localRequest(authorize)).status, 200)
        assert.deepEqual(await flow.result, GOOD_TOKEN)
        assert.equal(flow.calls.length, 1)
        assert.equal(requests, invalidPeers.length + 1)
    } finally {
        flow.controller.abort()
        await flow.observed
    }
})

test('loopback cancellation closes listener; no token request occurs', async () => {
    const flow = start({mode: 'loopback'}), authorize = await flow.ready
    flow.controller.abort()
    assertSafeError((await flow.observed).error, 'AUTH_STATE_CHANGED')
    await assert.rejects(localRequest(authorize))
    assert.equal(flow.calls.length, 0)
})

test('configuration failures never open browser or accept an uncontrolled endpoint', async () => {
    assert.throws(() => createMicrosoftBrowserLogin({timeoutMs: 300001}), {code: 'AUTH_BROWSER_CONFIG_REQUIRED'})
    assert.throws(() => createMicrosoftBrowserLogin({requestTimeoutMs: 15001}), {code: 'AUTH_BROWSER_CONFIG_REQUIRED'})
    const login = createMicrosoftBrowserLogin({requestToken: async () => { throw new Error('must not request') }})
    for (const options of [{}, {clientId: CLIENT, openBrowser() {}}, {clientId: 'malicious', mode: 'loopback', openBrowser() {}},
        {clientId: CLIENT, mode: 'external', openBrowser() {}}, {clientId: CLIENT, mode: 'loopback', openBrowser() {}, signal: {}}]) {
        await assert.rejects(login(options), {code: 'AUTH_BROWSER_CONFIG_REQUIRED'})
    }
})

// Intercept only the native HTTPS socket factory. No remote sockets or real auth transactions.
async function withFakeHttps(scenario, run) {
    const original = https.request, requests = []
    https.request = (url, options, onResponse) => {
        const request = new EventEmitter()
        const record = {url, options, payload: null, destroyed: 0, request}
        requests.push(record)
        request.destroy = () => { record.destroyed++; return request }
        request.end = payload => {
            record.payload = payload
            queueMicrotask(() => scenario({record, onResponse}))
            return request
        }
        return request
    }
    try { await run(requests) } finally { https.request = original }
}

function sendNative(onResponse, {statusCode = 200, headers = {'content-type': 'application/json'}, body = JSON.stringify(GOOD_TOKEN), aborted = false} = {}) {
    const incoming = new PassThrough()
    incoming.statusCode = statusCode
    incoming.headers = headers
    onResponse(incoming)
    if (aborted) incoming.emit('aborted')
    else incoming.end(body)
    return incoming
}

test('native HTTPS uses fixed POST endpoint and form, without cookies, redirects or retries', async () => {
    await withFakeHttps(({onResponse}) => sendNative(onResponse), async requests => {
        const flow = start({nativeRequest: true}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assert.deepEqual(await flow.result, GOOD_TOKEN)
        assert.equal(requests.length, 1)
        const record = requests[0], form = new URLSearchParams(record.payload)
        assert.equal(record.url, TOKEN_URL)
        assert.equal(record.options.method, 'POST')
        assert.equal(record.options.headers['Content-Type'], 'application/x-www-form-urlencoded')
        assert.equal(record.options.headers['Content-Length'], Buffer.byteLength(record.payload))
        assert.equal(record.options.headers.Cookie, undefined)
        assert.equal(record.options.headers.Authorization, undefined)
        assert.equal(form.get('client_id'), CLIENT)
        assert.equal(form.get('redirect_uri'), NATIVE)
        assert.equal(form.get('code'), CODE)
        assert.equal(crypto.createHash('sha256').update(form.get('code_verifier')).digest('base64url'), authorize.searchParams.get('code_challenge'))
    })
})

test('native HTTPS aborts an oversized response before JSON decoding', async () => {
    await withFakeHttps(({onResponse}) => sendNative(onResponse, {body: Buffer.alloc(65537, 32)}), async requests => {
        const flow = start({nativeRequest: true}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assertSafeError((await flow.observed).error, 'AUTH_INVALID_RESPONSE')
        assert.equal(requests.length, 1)
        assert.ok(requests[0].destroyed > 0)
    })
})

test('native HTTPS rejects a redirect response without contacting its location', async () => {
    await withFakeHttps(({onResponse}) => sendNative(onResponse, {statusCode: 302, headers: {location: 'https://attacker.invalid/' + CODE}, body: ''}), async requests => {
        const flow = start({nativeRequest: true}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assertSafeError((await flow.observed).error, 'AUTH_INVALID_RESPONSE', 'redirect_rejected')
        assert.equal(requests.length, 1)
    })
})

test('native HTTPS has a total request deadline and destroys a stalled request', async () => {
    await withFakeHttps(() => {}, async requests => {
        const flow = start({nativeRequest: true, requestTimeoutMs: 25}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assertSafeError((await flow.observed).error, 'AUTH_TEMPORARY_FAILURE', 'network_timeout')
        assert.equal(requests.length, 1)
        assert.ok(requests[0].destroyed > 0)
    })
})

test('native HTTPS cancellation destroys its pending request', async () => {
    await withFakeHttps(() => {}, async requests => {
        const flow = start({nativeRequest: true}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        flow.controller.abort()
        assertSafeError((await flow.observed).error, 'AUTH_STATE_CHANGED', 'cancelled')
        assert.ok(requests[0].destroyed > 0)
    })
})

test('native HTTPS transport and stream errors never expose their original error objects', async () => {
    await withFakeHttps(({record}) => record.request.emit('error', Object.assign(new Error(CODE), {url: 'https://attacker.invalid', body: GOOD_TOKEN})), async () => {
        const flow = start({nativeRequest: true}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assertSafeError((await flow.observed).error, 'AUTH_TEMPORARY_FAILURE', 'network')
    })
    await withFakeHttps(({onResponse}) => sendNative(onResponse, {aborted: true}), async () => {
        const flow = start({nativeRequest: true}), authorize = await flow.ready
        flow.accept(callback(authorize).href)
        assertSafeError((await flow.observed).error, 'AUTH_TEMPORARY_FAILURE', 'network')
    })
})
