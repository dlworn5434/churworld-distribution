const test=require('node:test')
const assert=require('node:assert/strict')
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm')
const {EventEmitter}=require('node:events')
const redact=require('../app/assets/js/auth-redaction')

test('log redaction covers every credential occurrence without mutating actual launch arguments',()=>{
    const account={uuid:'fake-a',displayName:'Fake',type:'microsoft',accessToken:'FAKE-MC-TOKEN',microsoft:{access_token:'FAKE-MS-TOKEN',refresh_token:'FAKE-REFRESH-TOKEN'}}
    const args=['--accessToken',account.accessToken,'duplicate='+account.accessToken,account.microsoft.refresh_token]
    const before=[...args]
    const logs=args.map(v=>redact(v,account,'FAKE-CLIENT-TOKEN'))
    assert.deepEqual(args,before)
    assert.doesNotMatch(logs.join(' '),/FAKE-.*TOKEN/)
    assert.equal(logs[0],'--accessToken')
})

test('actual ProcessBuilder gives Java the hydrated Minecraft token and masks args/stdout/stderr',()=>{
    const account={uuid:'fake-a',displayName:'Fake',type:'microsoft',accessToken:'FAKE-MC-TOKEN',microsoft:{access_token:'FAKE-MS-TOKEN',refresh_token:'FAKE-REFRESH-TOKEN'}}
    const logs=[],spawns=[]
    const child=new EventEmitter()
    for(const name of ['stdout','stderr']){child[name]=new EventEmitter();child[name].setEncoding=()=>{}}
    const config={getInstanceDirectory:()=>'/synthetic/instances',getCommonDirectory:()=>'/synthetic/common',getTempNativeFolder:()=> 'synthetic-natives',
        getModConfiguration:()=>({mods:{}}),getMaxRAM:()=> '4G',getMinRAM:()=> '2G',getJVMOptions:()=>[],getAutoConnect:()=>false,
        getClientToken:()=> 'FAKE-CLIENT-TOKEN',getJavaExecutable:()=> 'synthetic-java',getLaunchDetached:()=>false}
    const deps={
        './configmanager':config,'./auth-redaction':redact,
        'fs-extra':{ensureDirSync(){},remove(_p,done){done()}},
        'child_process':{spawn(executable,args,options){spawns.push({executable,args,options});return child}},
        'helios-core':{LoggerUtil:{getLogger(){return {info(...v){logs.push(v)},warn(...v){logs.push(v)}}}}},
        'helios-core/common':{mcVersionAtLeast:()=>true,getMojangOS:()=> 'windows'},
        'helios-distribution-types':{Type:{Fabric:'fabric'}}
    }
    const module={exports:{}}
    const filename=path.resolve(__dirname,'../app/assets/js/processbuilder.js')
    vm.runInNewContext(fs.readFileSync(filename,'utf8'),{module,exports:module.exports,
        require:id=>Object.hasOwn(deps,id)?deps[id]:require(id),process:{platform:'win32',arch:'x64'},__dirname:path.dirname(filename),
        console:{log(...v){logs.push(v)}}},{filename})
    const Builder=module.exports
    const builder=new Builder({rawServer:{id:'fixture-server',minecraftVersion:'1.21.4'},modules:[]},
        {arguments:{jvm:[],game:['--username','${auth_player_name}','--uuid','${auth_uuid}','--accessToken','${auth_access_token}']},assets:'fixture',type:'release'},
        {arguments:{game:[]},mainClass:'net.minecraft.client.main.Main'},account,'2.2.9')
    builder.constructJVMArguments=function(mods,natives){return this._constructJVMArguments113(mods,natives)}
    builder.constructModList=()=>[]
    assert.equal(builder.build(),child)
    assert.equal(spawns.length,1)
    const args=spawns[0].args
    assert.equal(args[args.indexOf('--accessToken')+1],account.accessToken)
    assert.equal(args.includes(account.microsoft.refresh_token),false)
    assert.equal(args.includes(account.microsoft.access_token),false)
    child.stdout.emit('data',`synthetic ${account.accessToken} twice ${account.accessToken}\n`)
    child.stderr.emit('data',`synthetic ${account.microsoft.refresh_token}\n`)
    const beforeSplit = logs.length
    child.stdout.emit('data', 'normal prefix FAKE-MC-')
    assert.equal(logs.length, beforeSplit)
    child.stdout.emit('data', 'TOKEN split across chunks\nordinary output\n')
    child.stderr.emit('data', 'refresh FAKE-REFRESH-')
    child.stderr.emit('data', 'TOKEN')
    child.stderr.emit('end')
    child.stdout.emit('data', 'x'.repeat(64 * 1024) + 'FAKE-MC-')
    child.stdout.emit('data', 'TOKEN\nrecovered output\n')
    child.stdout.emit('data', 'normal final line without newline')
    child.emit('close', 0)
    const rendered = JSON.stringify(logs)
    assert.doesNotMatch(rendered,/FAKE-(MC|MS|REFRESH|CLIENT)-TOKEN/)
    assert.doesNotMatch(rendered,/FAKE-MC-|FAKE-REFRESH-/)
    assert.match(rendered,/ordinary output/)
    assert.match(rendered,/recovered output/)
    assert.match(rendered,/normal final line without newline/)
    assert.equal(logs.filter(v=>String(v[0]).includes('Oversized log line omitted')).length,1)
    const beforeSpawnError = logs.length
    child.emit('error', Object.assign(new Error('PRIVATE_OS_ERROR'), {spawnargs:['--accessToken',account.accessToken]}))
    assert.equal(child.churuSpawnFailed,true)
    assert.equal(logs.length,beforeSpawnError+1)
    assert.equal(logs.at(-1)[0],'Minecraft process could not be started.')
    assert.equal(JSON.stringify(logs).includes('PRIVATE_OS_ERROR'),false)
    assert.doesNotMatch(JSON.stringify(logs),/FAKE-(MC|MS|REFRESH|CLIENT)-TOKEN/)
    assert.equal(account.accessToken,'FAKE-MC-TOKEN')
})
