'use strict'
// Real renderer handlers with a capability-only bridge. No account, clipboard, Electron or network access.
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const {test} = require('node:test')
const root = path.resolve(__dirname, '..')
const read = name => fs.readFileSync(path.join(root, 'app', name), 'utf8')
const source = read('assets/js/scripts/loginOptions.js')
const A = 'a'.repeat(32), B = 'b'.repeat(32)
const flush = async () => { for(let n = 0; n < 8; n++) await Promise.resolve() }
function deferred(){
    let resolve, reject
    const promise = new Promise((yes, no) => { resolve = yes; reject = no })
    return {promise, resolve, reject}
}
function fixture(platform = 'win32'){
    const state = {ipc: [], calls: [], failures: [], methods: {}, replies: {}, view: '#loginOptions', elements: new Map()}
    const get = id => {
        if(id === 'loginOptionMojang' || id === 'settingsAddMojangAccount') return null
        if(!state.elements.has(id)) state.elements.set(id, {
            id, disabled: false, hidden: false, textContent: '', style: {}, attrs: {}, value: '',
            setAttribute(key, value){ this.attrs[key] = value }, focus(){ state.focused = id },
            click(){ if(!this.disabled) return this.onclick?.() }
        })
        return state.elements.get(id)
    }
    const api = {onBrowserLoginStatus(listener){ state.status = listener }}
    for(const name of ['completeBrowserLogin', 'reopenBrowserLogin', 'cancelBrowserLogin']){
        api[name] = id => {
            state.calls.push([name, id])
            return state.methods[name]?.(id) ?? Promise.resolve()
        }
    }
    const ctx = vm.createContext({
        window: {launcher: {accounts: api}}, launcherPlatform: platform,
        document: {getElementById: get},
        $: element => ({show(){ element.hidden = false }, hide(){ element.hidden = true }}),
        VIEWS: {loginOptions: '#loginOptions', landing: '#landing', settings: '#settings', waiting: '#waiting'},
        MSFT_OPCODE: {OPEN_LOGIN: 'login', OPEN_BROWSER_LOGIN: 'browserLogin', REPLY_LOGIN: 'loginReply'},
        MSFT_REPLY_TYPE: {SUCCESS: 'success', ERROR: 'error'}, MSFT_ERROR: {NOT_FINISHED: 'notFinished'},
        ipcRenderer: {send(...args){ state.ipc.push(args) }, on(name, fn){ state.replies[name] = fn }},
        getCurrentView: () => state.view,
        switchView(_from, to, _first, _second, onCurrent = () => {}, onNext = () => {}){
            state.view = to; onCurrent(); onNext()
        },
        showAuthFailure(error){ state.failures.push(error.code) },
        LoggerUtil: {getLogger: () => ({})}, updateSelectedAccount(){}, prepareSettings: async () => {},
        loginUsername: get('loginUsername'), loginPassword: get('loginPassword')
    })
    vm.runInContext(source, ctx)
    vm.runInContext("loginOptionsViewOnLoginSuccess = VIEWS.landing; loginOptionsViewOnLoginCancel = VIEWS.loginOptions; loginOptionsViewOnCancel = VIEWS.landing", ctx)
    function loadSettings(){
        const settings = read('assets/js/scripts/settings.js')
        vm.runInContext(settings.slice(settings.indexOf('const msftLoginLogger'), settings.indexOf('const settingsCurrentMicrosoftAccounts')), ctx)
    }
    const status = (id, status, extra = {}) => state.status({id, status, ...extra})
    const start = (id = A) => { get('loginOptionBrowser').click(); status(id, 'opening_browser'); status(id, 'waiting_for_browser') }
    return {state, ctx, get, status, start, loadSettings}
}

test('browser start keeps its instructions visible and suppresses duplicate and popup starts', () => {
    const f = fixture()
    f.get('loginOptionBrowser').click()
    f.get('loginOptionBrowser').onclick()
    f.get('loginOptionMicrosoft').onclick()
    assert.deepEqual(f.state.ipc, [['browserLogin', '#landing', '#loginOptions']])
    assert.equal(f.state.view, '#loginOptions')
    assert.equal(f.get('browserLoginPanel').hidden, false)
    assert.equal(f.get('loginOptionActions').hidden, true)
    assert.equal(f.get('browserLoginComplete').disabled, true)
    assert.equal(f.get('browserLoginCancel').disabled, true)
    f.status(A, 'opening_browser')
    assert.equal(f.get('browserLoginCancel').disabled, false)
})

test('existing embedded Microsoft login retains its waiting screen and IPC', () => {
    const f = fixture(); f.get('loginOptionMicrosoft').click()
    assert.equal(f.state.view, '#waiting')
    assert.deepEqual(f.state.ipc, [['login', '#landing', '#loginOptions']])
})

test('complete address action sends only the operation ID and cannot overlap', async () => {
    const f = fixture(), pending = deferred()
    f.state.methods.completeBrowserLogin = () => pending.promise
    f.start()
    const promise = f.get('browserLoginComplete').click()
    f.get('browserLoginComplete').onclick()
    f.get('browserLoginReopen').onclick()
    assert.deepEqual(f.state.calls, [['completeBrowserLogin', A]])
    assert.equal(f.get('browserLoginComplete').disabled, true)
    assert.equal(f.get('browserLoginCancel').disabled, false)
    pending.resolve(); await promise
    assert.equal(f.get('browserLoginComplete').disabled, false)
})

test('invalid copied address shows the safe error and preserves the pending browser session', async () => {
    const f = fixture()
    f.state.methods.completeBrowserLogin = async () => { throw {code: 'AUTH_BROWSER_LINK_INVALID', message: 'PRIVATE_ADDRESS'} }
    f.start(); await f.get('browserLoginComplete').click()
    assert.deepEqual(f.state.failures, ['AUTH_BROWSER_LINK_INVALID'])
    assert.equal(f.get('browserLoginPanel').hidden, false)
    assert.equal(f.get('browserLoginComplete').disabled, false)
    await f.get('browserLoginReopen').click()
    assert.deepEqual(f.state.calls, [['completeBrowserLogin', A], ['reopenBrowserLogin', A]])
    assert.ok(![...f.state.elements.values()].some(element => element.textContent.includes('PRIVATE_ADDRESS')))
})

test('token and account checks disable submission while preserving cancellation', () => {
    const f = fixture(); f.start()
    for(const stage of ['exchanging_token', 'checking_account']){
        f.status(A, stage)
        assert.equal(f.get('browserLoginComplete').disabled, true)
        assert.equal(f.get('browserLoginReopen').disabled, true)
        assert.equal(f.get('browserLoginCancel').disabled, false)
        f.get('browserLoginComplete').onclick()
    }
    assert.deepEqual(f.state.calls, [])
})

test('malformed and unrelated status events do not alter the active session', () => {
    const f = fixture(); f.start()
    const expected = f.get('browserLoginStatus').textContent
    for(const event of [null, {}, {id: 'x', status: 'error'}, {id: A, status: 'PRIVATE_ADDRESS'}, {id: A, status: {}}, {id: B, status: 'complete'}]) f.state.status(event)
    assert.equal(f.get('browserLoginStatus').textContent, expected)
    assert.equal(f.get('browserLoginPanel').hidden, false)
    f.status(A, 'checking_account', {url: 'PRIVATE_ADDRESS', code: 'PRIVATE_CODE'})
    assert.ok(![...f.state.elements.values()].some(element => /PRIVATE_/.test(element.textContent)))
})

for(const terminal of ['complete', 'cancelled', 'error']){
    test('terminal ' + terminal + ' waits for reply before retry; retired events cannot take over', () => {
        const f = fixture(); f.start(); f.status(A, terminal)
        assert.equal(f.get('browserLoginPanel').hidden, false)
        assert.equal(f.get('loginOptionBrowser').disabled, true)
        assert.equal(f.get('browserLoginCancel').disabled, true)
        f.ctx.resetBrowserLoginUI()
        assert.equal(f.get('browserLoginPanel').hidden, true)
        assert.equal(f.get('loginOptionBrowser').disabled, false)
        f.get('loginOptionBrowser').click()
        f.status(A, 'opening_browser'); f.status(A, 'complete')
        assert.equal(f.get('browserLoginComplete').disabled, true)
        f.status(B, 'opening_browser'); f.status(B, 'waiting_for_browser')
        f.status(A, 'error')
        assert.equal(f.get('browserLoginComplete').disabled, false)
        assert.equal(f.get('browserLoginPanel').hidden, false)
    })
}

test('cancel during an import isolates the eventual result from a new browser attempt', async () => {
    const f = fixture(), pending = deferred()
    f.state.methods.completeBrowserLogin = () => pending.promise
    f.start()
    const importing = f.get('browserLoginComplete').click()
    await f.get('browserLoginCancel').click()
    assert.equal(f.get('loginOptionBrowser').disabled, true)
    assert.equal(f.get('browserLoginComplete').disabled, true)
    assert.equal(f.get('browserLoginCancel').disabled, true)
    f.get('loginOptionBrowser').onclick()
    assert.equal(f.state.ipc.length, 1)
    f.status(A, 'cancelled'); f.ctx.resetBrowserLoginUI()
    f.start(B)
    pending.reject({code: 'AUTH_BROWSER_LINK_INVALID'}); await importing
    assert.equal(f.get('browserLoginPanel').hidden, false)
    assert.equal(f.get('browserLoginComplete').disabled, false)
    assert.deepEqual(f.state.failures, [])
    assert.deepEqual(f.state.calls, [['completeBrowserLogin', A], ['cancelBrowserLogin', A]])
})

test('cancel error restores retryable controls, and outer navigation cannot bypass cancellation', async () => {
    const f = fixture()
    f.state.methods.cancelBrowserLogin = async () => { throw {code: 'AUTH_TEMPORARY_FAILURE'} }
    f.start(); f.get('loginOptionCancelButton').onclick()
    assert.equal(f.state.view, '#loginOptions')
    await f.get('browserLoginCancel').click()
    assert.equal(f.get('browserLoginCancel').disabled, false)
    assert.equal(f.get('browserLoginComplete').disabled, false)
    assert.deepEqual(f.state.failures, ['AUTH_TEMPORARY_FAILURE'])
})

test('settings browser action shows instructions and preserves return-to-settings routes', () => {
    const f = fixture(); f.loadSettings(); f.state.view = '#settings'
    f.get('settingsAddBrowserMicrosoftAccount').click()
    assert.equal(f.state.view, '#loginOptions')
    assert.equal(f.state.focused, 'loginOptionBrowser')
    assert.deepEqual(f.state.ipc, [])
    f.get('loginOptionBrowser').click()
    assert.deepEqual(f.state.ipc, [['browserLogin', '#settings', '#settings']])
    f.ctx.resetBrowserLoginUI(); f.get('loginOptionCancelButton').click()
    assert.equal(f.state.view, '#settings')
})

test('settings original Microsoft add button remains the embedded path', () => {
    const f = fixture(); f.loadSettings(); f.state.view = '#settings'
    f.get('settingsAddMicrosoftAccount').click()
    assert.equal(f.state.view, '#waiting')
    assert.deepEqual(f.state.ipc, [['login', '#settings', '#settings']])
})

test('start error reply resets browser controls even before any operation ID arrives', async () => {
    const f = fixture(); f.loadSettings(); f.get('loginOptionBrowser').click()
    f.state.replies.loginReply(null, 'error', {code: 'AUTH_BROWSER_OPEN_FAILED'}, '#loginOptions')
    await flush()
    assert.equal(f.get('loginOptionBrowser').disabled, false)
    assert.equal(f.get('browserLoginPanel').hidden, true)
    assert.deepEqual(f.state.failures, ['AUTH_BROWSER_OPEN_FAILED'])
})

test('Mac instructions use Command and Windows instructions remain in the template', () => {
    const f = fixture('darwin')
    assert.equal(f.get('browserLoginCopyShortcut').textContent, '⌘+L → ⌘+C')
    assert.ok(read('loginOptions.ejs').includes('Ctrl+L → Ctrl+C'))
})

test('browser UI has live status, responsive sizing, no callback input or clipboard access', () => {
    const html = read('loginOptions.ejs'), css = read('assets/css/launcher.css')
    assert.match(html, /id="browserLoginStatus" role="status" aria-live="polite"/)
    assert.match(html, /id="browserLoginComplete"[^>]*type="button"/)
    assert.doesNotMatch(html, /<(?:input|textarea)\b/i)
    assert.doesNotMatch(source, /clipboard|readText|writeText|URLSearchParams|accessToken|refreshToken|console\./)
    assert.match(css, /width: min\(510px, calc\(100% - 32px\)\)/)
    assert.match(css, /max-height: calc\(100% - 32px\)/)
})
