'use strict'
// Real sandboxed Electron/EJS/preload/service/controller. All authentication,
// browser and clipboard dependencies below are synthetic; HTTP is blocked.
const {app, BrowserWindow, ipcMain, session} = require('electron')
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), assert = require('node:assert/strict')
const {pathToFileURL} = require('node:url')
const root = path.resolve(__dirname, '..')
const temp = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'churu-browser-ui-test-')))
const preview = path.resolve(root, '../preview')
app.setPath('userData', path.join(temp, 'profile'))
process.env.APPDATA = temp
app.disableHardwareAcceleration()
const ejse = require('ejs-electron'), toml = require('toml'), merge = require('lodash.merge')
const language = merge({}, toml.parse(fs.readFileSync(path.join(root, 'app/assets/lang/en_US.toml'), 'utf8')),
    toml.parse(fs.readFileSync(path.join(root, 'app/assets/lang/_custom.toml'), 'utf8')))
const query = (id, values = {}) => {
    let result = id.split('.').reduce((value, key) => value?.[key], language) || id
    for(const [key, value] of Object.entries(values)) result = result.replaceAll('{' + key + '}', value)
    return result
}
const config = {
    settings: {game: {resWidth: 1280, resHeight: 720, fullscreen: false, autoConnect: true, launchDetached: true},
        launcher: {allowPrerelease: false, dataDirectory: temp}},
    javaConfig: {churworld: {minRAM: '2G', maxRAM: '4G', executable: path.join(temp, 'synthetic-java.exe'), jvmOptions: []}},
    modConfigurations: [{id: 'churworld', mods: {}}], newsCache: {content: null, date: null, dismissed: false},
    selectedServer: 'churworld', selectedDestination: 'life', selectedAccount: 'fake-uuid',
    authenticationDatabase: {'fake-uuid': {uuid: 'fake-uuid', displayName: 'TestUser', type: 'microsoft',
        accessToken: 'FAKE_PRIVATE_MC', microsoft: {access_token: 'FAKE_PRIVATE_MS', refresh_token: 'FAKE_PRIVATE_REFRESH'}}},
    clientToken: 'FAKE_PRIVATE_CLIENT', authRevision: 0, firstLaunch: false
}
const server = {rawServer: {id: 'churworld', name: 'ChurWorld test', description: 'Synthetic fixture',
    minecraftVersion: '1.21.4', version: '1.0', icon: '', mainServer: true, javaOptions: {ram: {minimum: 2048}}},
    effectiveJavaOptions: {suggestedMajor: 21, supported: '>=21', distribution: 'temurin'}, hostname: 'invalid.local', port: 25565, modules: []}
const distro = {rawDistribution: {rss: null}, servers: [server], getServerById: id => id === 'churworld' ? server : null, getMainServer: () => server}
const documentURL = pathToFileURL(path.join(root, 'app/app.ejs')).href
let win, persisted = structuredClone(config), revision = 0, clipboardValue = '', clipboardReads = 0, clipboardClears = 0
let browserOpens = 0, popupLogins = 0, attempts = 0, addedTokens = 0, deferAbort = false, releaseAbort, holdAccount, releaseAccount, holdReply, releaseReply
const statuses = [], errors = [], screenshots = [], dimensions = []
const wait = ms => new Promise(resolve => setTimeout(resolve, ms))
const evaluate = code => win.webContents.executeJavaScript(code)
async function until(expression, description){
    for(let attempt = 0; attempt < 200; attempt++){
        if(await evaluate(expression)) return
        await wait(20)
    }
    throw new Error('Timed out: ' + description)
}
async function capture(name){
    await wait(100)
    const file = path.join(preview, name + '.png')
    fs.writeFileSync(file, (await win.webContents.capturePage()).toPNG())
    screenshots.push(file)
}
async function assertPanelFits(){
    const result = await evaluate(`(() => {
        const panel=document.getElementById('browserLoginPanel'), rect=panel.getBoundingClientRect();
        const buttons=['browserLoginComplete','browserLoginReopen','browserLoginCancel'].map(id=>{
            const r=document.getElementById(id).getBoundingClientRect();return {id,x:r.x,y:r.y,right:r.right,bottom:r.bottom}
        });return {width:innerWidth,height:innerHeight,rect:{x:rect.x,y:rect.y,right:rect.right,bottom:rect.bottom},buttons}
    })()`)
    assert.ok(result.rect.x >= 0 && result.rect.y >= 0 && result.rect.right <= result.width && result.rect.bottom <= result.height)
    for(const button of result.buttons) assert.ok(button.x >= 0 && button.y >= 0 && button.right <= result.width && button.bottom <= result.height)
    dimensions.push(result)
}
async function showOptions(){
    await evaluate(`loginOptionsViewOnLoginSuccess=VIEWS.landing;loginOptionsViewOnLoginCancel=VIEWS.loginOptions;
        loginOptionsViewOnCancel=VIEWS.landing;loginOptionsCancelEnabled(true);switchView(getCurrentView(),VIEWS.loginOptions,0,0)`)
    await until("getComputedStyle(document.getElementById('loginOptionsContainer')).display !== 'none'", 'options visible')
}
async function startBrowser(){
    await evaluate("document.getElementById('loginOptionBrowser').click()")
    await until("!document.getElementById('browserLoginComplete').disabled", 'browser waiting')
}
app.whenReady().then(async () => {
    fs.mkdirSync(preview, {recursive: true})
    const {createLoginController} = require('../app/assets/js/login-controller')
    const controller = createLoginController({
        beginAttempt(){
            attempts++
            return {async addTokens(tokens){
                assert.equal(tokens.access_token, 'FAKE_PRIVATE_NEW_ACCESS')
                if(holdAccount) await holdAccount
                addedTokens++
            }}
        },
        acquireBrowserToken(options){
            return new Promise((resolve, reject) => {
                const cancelled = () => reject(Object.assign(new Error('AUTH_STATE_CHANGED'), {code: 'AUTH_STATE_CHANGED'}))
                options.signal.addEventListener('abort', () => { if(deferAbort) releaseAbort = cancelled; else cancelled() }, {once: true})
                options.onCallbackReady(value => {
                    if(value !== 'FAKE_PRIVATE_CALLBACK') return false
                    options.onStatus('exchanging_token')
                    resolve({access_token: 'FAKE_PRIVATE_NEW_ACCESS', refresh_token: 'FAKE_PRIVATE_NEW_REFRESH'})
                    return true
                })
                options.onReopenReady(async () => { await options.openBrowser('https://login.microsoftonline.com/FAKE_PRIVATE_AUTH'); return true })
                options.openBrowser('https://login.microsoftonline.com/FAKE_PRIVATE_AUTH').then(() => options.onStatus('waiting_for_browser'), reject)
            })
        },
        openExternal: async url => { assert.match(url, /^https:\/\/login\.microsoftonline\.com\//); browserOpens++ },
        readClipboard: () => { clipboardReads++; return clipboardValue },
        clearClipboard: () => { clipboardClears++; clipboardValue = '' },
        notify(value){ statuses.push(value); win.webContents.send('churu-browser-login', value) }
    })
    const {createLauncherService} = require('../app/assets/js/launcher-service')
    createLauncherService({app, ipcMain, dialog: {}, shell: {openExternal: async () => { throw new Error('Unexpected external URL') }},
        windowFor: () => win, documentURL,
        store: {result: () => ({config: structuredClone(persisted), revision, firstLaunch: false}),
            save(next, expected){ assert.equal(expected, revision); persisted = structuredClone(next); return {revision: ++revision} }},
        update: {}, login: () => controller.run('popup', async () => { popupLogins++; return true }), logout: async () => true,
        browserLogin: {start: async () => { try { return await controller.startBrowser() } finally { if(holdReply) await holdReply } }, complete: id => controller.completeBrowser(id),
            cancel: id => controller.cancelBrowser(id), reopen: id => controller.reopenBrowser(id)},
        dependencies: {AuthManager: {validateSelected: async () => true},
            distribution: {DistroAPI: {getDistribution: async () => distro}},
            synchronization: {syncModConfigurations(){}, ensureJavaSettings(){}}, textFeed: async () => '<feed/>',
            MojangRestAPI: {status: async () => ({responseStatus: 0, data: []})}, getServerStatus: async () => ({players: {online: 1, max: 100}}),
            game: {isBusy: () => false, checkJava: async () => ({semverStr: '21.0.1', vendor: 'Synthetic'})}}})
    session.defaultSession.webRequest.onBeforeRequest((details, callback) => callback({cancel: /^https?:/.test(details.url)}))
    ejse.data('bkid', 0); ejse.data('lang', (key, values) => query('ejs.' + key, values))
    win = new BrowserWindow({show: false, frame: false, width: 980, height: 552,
        webPreferences: {preload: path.join(root, 'app/assets/js/preloader.js'), nodeIntegration: false, contextIsolation: true, sandbox: true, devTools: false, backgroundThrottling: false}})
    win.webContents.on('console-message', details => { if(details.level === 'error' && !/ERR_BLOCKED_BY_CLIENT|Failed to load resource/.test(details.message)) errors.push(details.message) })
    win.webContents.on('preload-error', (_event, _file, error) => errors.push('PRELOAD ' + error.message))
    await win.loadURL(documentURL)
    await until("typeof getCurrentView==='function' && getCurrentView()===VIEWS.landing && document.getElementById('main').style.display !== 'none'", 'launcher ready')
    await wait(1200)
    assert.equal(await evaluate('fatalStartupError'), false)
    await showOptions()
    await capture('browser-login-options-980x552')
    await startBrowser()
    assert.equal(attempts, 1); assert.equal(browserOpens, 1); assert.equal(clipboardReads, 0)
    await assertPanelFits(); await capture('browser-login-waiting-980x552')
    await evaluate("document.getElementById('browserLoginReopen').click()")
    await until("!document.getElementById('browserLoginReopen').disabled", 'reopen complete')
    assert.equal(browserOpens, 2)
    const rejectedCode = await evaluate("window.launcher.accounts.completeBrowserLogin(browserLoginId).then(()=>null,error=>error?.code || null)")
    assert.equal(rejectedCode, 'AUTH_BROWSER_LINK_INVALID', 'safe error code survives the real context bridge')
    await evaluate("document.getElementById('browserLoginComplete').click()")
    await until('isOverlayVisible()', 'safe invalid address error')
    assert.equal(await evaluate("document.getElementById('overlayTitle').textContent"), '로그인 확인')
    assert.match(await evaluate("document.getElementById('overlayDesc').textContent"), /주소창 전체를 복사/)
    assert.equal(await evaluate("document.getElementById('browserLoginPanel').hidden"), false)
    assert.equal(attempts, 1); assert.equal(clipboardReads, 2)
    await until("getComputedStyle(document.getElementById('overlayContainer')).opacity === '1'", 'error overlay painted')
    await capture('browser-login-invalid-address-980x552')
    await evaluate("document.getElementById('overlayAcknowledge').click()")
    await until("!isOverlayVisible() && getComputedStyle(document.getElementById('overlayContainer')).display === 'none'", 'error dismissed')
    win.setSize(720, 480)
    await assertPanelFits(); await capture('browser-login-waiting-720x480')
    win.setSize(980, 552)
    deferAbort = true
    holdReply = new Promise(resolve => { releaseReply = resolve })
    await evaluate("document.getElementById('browserLoginCancel').click()")
    await until("document.getElementById('browserLoginStatus').textContent.includes('취소') && document.getElementById('browserLoginCancel').disabled", 'cancel pending reply')
    assert.equal(await evaluate("['loginOptionBrowser','browserLoginComplete','browserLoginReopen','browserLoginCancel'].every(id=>document.getElementById(id).disabled)"), true)
    await evaluate("document.getElementById('loginOptionBrowser').click();document.getElementById('loginOptionMicrosoft').click()")
    assert.equal(attempts, 1); assert.equal(popupLogins, 0)
    assert.equal(typeof releaseAbort, 'function'); releaseAbort(); deferAbort = false
    releaseReply(); holdReply = null
    await until("!document.getElementById('loginOptionBrowser').disabled && !loginRequestPending", 'cancel reply resets UI')
    await wait(1100)
    await startBrowser()
    holdAccount = new Promise(resolve => { releaseAccount = resolve })
    clipboardValue = 'FAKE_PRIVATE_CALLBACK'
    await evaluate("document.getElementById('browserLoginComplete').click()")
    await until("document.getElementById('browserLoginStatus').textContent.includes('마인크래프트')", 'account check')
    assert.equal(await evaluate("document.getElementById('browserLoginComplete').disabled"), true)
    assert.equal(clipboardValue, ''); assert.equal(clipboardClears, 1)
    assert.equal(await evaluate("document.body.textContent.includes('FAKE_PRIVATE') || JSON.stringify(BOOT).includes('FAKE_PRIVATE')"), false)
    releaseAccount(); holdAccount = null
    await until('getCurrentView()===VIEWS.landing && !loginRequestPending', 'browser login success')
    assert.equal(addedTokens, 1)
    await wait(1100); await showOptions()
    await evaluate("document.getElementById('loginOptionMicrosoft').click()")
    await until('getCurrentView()===VIEWS.landing && !loginRequestPending', 'embedded login success')
    assert.equal(popupLogins, 1)
    assert.equal(persisted.authenticationDatabase['fake-uuid'].microsoft.refresh_token, 'FAKE_PRIVATE_REFRESH')
    for(const value of statuses){ assert.deepEqual(Object.keys(value).sort(), ['id', 'status']); assert.match(value.id, /^[a-f0-9]{32}$/) }
    assert.deepEqual(errors, [])
    const report = {ok: true, test: 'native browser login UI', attempts, browserOpens, popupLogins, addedTokens,
        clipboardReads, clipboardClears, dimensions, screenshots, nativeClipboardCalls: 0, realBrowserCalls: 0, externalNetworkAllowed: false}
    fs.writeFileSync(path.join(preview, 'browser-login-native-result.json'), JSON.stringify(report, null, 2) + '\n')
    console.log(JSON.stringify(report))
    win.destroy(); app.exit(0)
}).catch(error => { console.error(error.stack); console.error(JSON.stringify({errors})); if(win && !win.isDestroyed()) win.destroy(); app.exit(1) })
