'use strict'
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const vm = require('node:vm')
const { createRequire } = require('node:module')
const { TrustedRepair, SafeMojangProcessor, downloadVendorQueue } = require('../app/assets/js/trusted-repair')
const { EventEmitter } = require('node:events')
const { Readable } = require('node:stream')
const { TrustedCache } = require('../app/assets/js/trusted-cache')
const { SIGNING_PREFIX, verifyEnvelope } = require('../app/assets/js/trusted-manifest')
const { atomicWrite } = require('../app/assets/js/secure-download')
const NOW = Date.parse('2026-10-23T00:00:00Z'), URL_ROOT = 'https://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/'
const digest = (data, algo = 'sha256') => crypto.createHash(algo).update(data).digest('hex')
const keys = crypto.generateKeyPairSync('ed25519')
const keyring = { schema: 1, keys: [{ id: 'repair-fixture', algorithm: 'Ed25519', publicKeySpki: keys.publicKey.export({ type: 'spki', format: 'der' }).toString('base64'), purposes: ['distribution'], notBefore: '2026-01-01T00:00:00Z', notAfter: '2027-01-01T00:00:00Z' }] }
function signed(payload) { const bytes = Buffer.from(JSON.stringify(payload)); return { schema: 1, keyId: 'repair-fixture', payload: bytes.toString('base64'), signature: crypto.sign(null, Buffer.concat([SIGNING_PREFIX, bytes]), keys.privateKey).toString('base64') } }
function fixture(t) {
    const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'chur-trusted-repair-')))
    t.after(() => fs.rmSync(root, { force: true, recursive: true }))
    const common = path.join(root, 'common'), instance = path.join(root, 'instances')
    const moduleBytes = Buffer.from('AUDIT_FAKE_JAR'), modJson = Buffer.from(JSON.stringify({ id: '1.21.4-fabric-0.17.2' }))
    const artifact = data => ({ size: data.length, SHA256: digest(data), MD5: digest(data, 'md5'), url: URL_ROOT + 'files/fixture' })
    const payload = { schema: 1, purpose: 'distribution', sequence: 1, issuedAt: '2026-10-22T23:00:00Z', expiresAt: '2026-10-24T00:00:00Z', distribution: { servers: [{ id: 'fixture', address: 'localhost', minecraftVersion: '1.21.4', modules: [{ id: 'net.fabricmc:fabric-loader:0.17.2', type: 'Fabric', artifact: artifact(moduleBytes), subModules: [{ id: '1.21.4-fabric-0.17.2', type: 'VersionManifest', artifact: artifact(modJson) }] }] }] } }
    const signedEnvelope = signed(payload), verified = verifyEnvelope(signedEnvelope, { purpose: 'distribution', keys: keyring, now: NOW })
    const filename = path.resolve(__dirname, '../app/assets/js/distromanager.js'), realRequire = createRequire(filename), module = { exports: {} }
    vm.runInNewContext(fs.readFileSync(filename, 'utf8'), { require: name => name === './configmanager' ? { getLauncherDirectory: () => root, getCommonDirectory: () => common } : name === 'helios-core' ? { LoggerUtil: { getLogger: () => ({ warn() {} }) } } : realRequire(name), module, exports: module.exports, process }, { filename })
    const api = new module.exports.ManagedDistributionAPI(root, common, instance, URL_ROOT + 'distribution.signed.json', false)
    api.trustedCache = new TrustedCache({ directory: path.join(root, 'trusted-metadata'), purpose: 'distribution', url: URL_ROOT + 'distribution.signed.json', keys: keyring, now: () => NOW, allowExpiredFallback: true, fetch: async () => JSON.stringify(signedEnvelope) })
    atomicWrite(api.trustedCache.filename, JSON.stringify(signedEnvelope), api.trustedCache.directory)
    const distribution = api.build(verified)
    const write = (filename, data) => { fs.mkdirSync(path.dirname(filename), { recursive: true }); fs.writeFileSync(filename, data) }
    const main = distribution.getServerById('fixture').modules[0]
    write(main.getPath(), moduleBytes); write(main.subModules[0].getPath(), modJson)
    const client = Buffer.from('AUDIT_FAKE_CLIENT'), log = Buffer.from('<fake/>'), index = { objects: {} }
    const versionFile = path.join(common, 'versions/1.21.4/1.21.4.json'), indexFile = path.join(common, 'assets/indexes/fixture.json'), clientFile = path.join(common, 'versions/1.21.4/1.21.4.jar'), logFile = path.join(common, 'assets/log_configs/fixture.xml')
    const version = { id: '1.21.4', assetIndex: { id: 'fixture' }, libraries: [], downloads: { client: { sha1: digest(client, 'sha1'), size: client.length, url: 'https://piston-data.mojang.com/fixture-client' } }, logging: { client: { file: { id: 'fixture.xml', sha1: digest(log, 'sha1'), size: log.length, url: 'https://piston-data.mojang.com/fixture-log' } } } }
    write(versionFile, JSON.stringify(version)); write(indexFile, JSON.stringify(index)); write(logFile, log)
    let initCalls = 0, downloads = 0
    class FixtureMojang {
        constructor() { this.versionJson = undefined; this.assetIndex = undefined }
        getAssetIndexPath() { return indexFile }
        async init() { initCalls++; this.versionJson = JSON.parse(fs.readFileSync(versionFile)); this.assetIndex = JSON.parse(fs.readFileSync(indexFile)) }
        totalStages() { return 1 }
        async validate(progress) {
            await progress()
            const assets = []
            for(const [id, filename, data] of [['client', clientFile, client], ['log', logFile, log]]) {
                if(!fs.existsSync(filename) || digest(fs.readFileSync(filename), 'sha1') !== digest(data, 'sha1')) assets.push({ id, path: filename, hash: digest(data, 'sha1'), algo: 'sha1', size: data.length, url: 'https://piston-data.mojang.com/fixture' })
            }
            return { assets }
        }
        async postDownload() {}
    }
    const queue = async assets => { downloads++; const received = {}; for(const asset of assets) { write(asset.path, asset.id === 'client' ? client : log); received[asset.id] = asset.size } return received }
    const create = offlineOnly => new TrustedRepair({ commonDirectory: common, instanceDirectory: instance, launcherDirectory: root, serverId: 'fixture', distribution, offlineOnly, dependencies: { api, MojangIndexProcessor: FixtureMojang, downloadQueue: queue } })
    return { root, api, distribution, verified, create, write, client, clientFile, versionFile, main, init: () => initCalls, downloads: () => downloads }
}
test('fresh signed-only install repairs vendor files without legacy distribution.json', async t => {
    const f = fixture(t), repair = f.create(false)
    assert.equal(fs.existsSync(path.join(f.root, 'distribution.json')), false)
    repair.spawnReceiver(); assert.equal(await repair.verifyFiles(), 1)
    await repair.download(); assert.equal(await repair.verifyFiles(), 0)
    const metadata = await repair.getLaunchMetadata()
    assert.equal(metadata.vanilla.id, '1.21.4'); assert.equal(metadata.mod.id, '1.21.4-fabric-0.17.2')
    assert.equal(f.downloads(), 1)
    assert.ok(fs.existsSync(repair.receipt))
    repair.destroyReceiver()
})
test('legacy poisoned unsigned cache is ignored while signed snapshot repairs', async t => {
    const f = fixture(t), repair = f.create(false)
    f.write(path.join(f.root, 'distribution.json'), JSON.stringify({ servers: [{ id: 'fixture', modules: [{ artifact: { url: 'http://attacker.invalid/payload' } }] }] }))
    repair.spawnReceiver(); await repair.verifyFiles(); await repair.download(); assert.equal(await repair.verifyFiles(), 0)
    assert.equal((await repair.getLaunchMetadata()).mod.id, '1.21.4-fabric-0.17.2')
})
test('expiry permits previously verified unchanged installation with zero metadata fetch or downloads', async t => {
    const f = fixture(t), online = f.create(false)
    online.spawnReceiver(); await online.verifyFiles(); await online.download(); await online.verifyFiles(); online.destroyReceiver()
    const initBefore = f.init(), downloadsBefore = f.downloads()
    f.api.trustedCache.now = () => NOW + 4 * 86400000
    // The expired remote response cannot be newly cached; existing cache is kept.
    const original = fs.readFileSync(f.api.trustedCache.filename)
    const fallback = await f.api.trustedCache.refresh()
    assert.equal(fallback.digest, f.verified.digest); assert.deepEqual(fs.readFileSync(f.api.trustedCache.filename), original)
    const offline = f.create(true); offline.spawnReceiver()
    assert.equal(await offline.verifyFiles(), 0)
    assert.equal((await offline.getLaunchMetadata()).vanilla.id, '1.21.4')
    await assert.rejects(offline.download(), { code: 'TRUST_EXPIRED_DOWNLOAD_DISABLED' })
    assert.equal(f.init(), initBefore); assert.equal(f.downloads(), downloadsBefore)
})
for(const kind of ['missing receipt', 'client mutation', 'metadata mutation', 'custom mutation']) test(`expired install refuses ${kind} without any repair download`, async t => {
    const f = fixture(t), online = f.create(false)
    online.spawnReceiver(); await online.verifyFiles(); await online.download(); await online.verifyFiles(); online.destroyReceiver()
    f.api.trustedCache.now = () => NOW + 4 * 86400000
    if(kind === 'missing receipt') fs.unlinkSync(online.receipt)
    if(kind === 'client mutation') fs.writeFileSync(f.clientFile, Buffer.alloc(f.client.length))
    if(kind === 'metadata mutation') fs.writeFileSync(f.versionFile, '{}')
    if(kind === 'custom mutation') fs.writeFileSync(f.main.getPath(), 'CHANGED')
    const before = f.downloads(), offline = f.create(true); offline.spawnReceiver()
    await assert.rejects(offline.verifyFiles())
    await assert.rejects(offline.download(), { code: 'TRUST_EXPIRED_DOWNLOAD_DISABLED' })
    assert.equal(f.downloads(), before)
})
test('newly expired remote metadata can never create a trusted cache', async t => {
    const f = fixture(t)
    fs.unlinkSync(f.api.trustedCache.filename)
    f.api.trustedCache.now = () => NOW + 4 * 86400000
    await assert.rejects(f.api.trustedCache.refresh(), { code: 'TRUST_MANIFEST_EXPIRED' })
    assert.equal(fs.existsSync(f.api.trustedCache.filename), false)
})

for(const scenario of ['traversal', 'foreign URL', 'bad hash']) test(`real Mojang processor rejects ${scenario} before unsafe metadata write`, async t => {
    const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'chur-vendor-safe-')))
    t.after(() => fs.rmSync(root, { recursive: true, force: true }))
    const common = path.join(root, 'common'), requests = []
    const index = Buffer.from('{"objects":{}}')
    const version = Buffer.from(JSON.stringify({ id: '1.21.4', assetIndex: { id: scenario === 'traversal' ? '../../../outside-common' : 'fixture', url: scenario === 'foreign URL' ? 'https://unapproved.invalid/asset-index' : 'https://piston-meta.mojang.com/fixture-index', sha1: scenario === 'bad hash' ? '0'.repeat(40) : digest(index, 'sha1') } }))
    const manifest = Buffer.from(JSON.stringify({ versions: [{ id: '1.21.4', sha1: digest(version, 'sha1'), url: 'https://piston-meta.mojang.com/fixture-version' }] }))
    const processor = new SafeMojangProcessor(common, '1.21.4', async url => {
        requests.push(url)
        if(url.endsWith('version_manifest_v2.json')) return manifest
        if(url.endsWith('fixture-version')) return version
        if(url.endsWith('fixture-index')) return index
        throw new Error('Unexpected fixture request')
    })
    await assert.rejects(processor.init(), { code: scenario === 'bad hash' ? 'TRUST_VENDOR_METADATA_HASH' : scenario === 'foreign URL' ? 'TRUST_VENDOR_URL_INVALID' : 'TRUST_VENDOR_METADATA_INVALID' })
    assert.equal(fs.existsSync(path.join(root, 'outside-common.json')), false)
    assert.equal(fs.existsSync(path.join(common, 'assets/indexes/fixture.json')), false)
    assert.equal(requests.some(url => url.includes('unapproved.invalid')), false)
    assert.equal(requests.length, scenario === 'bad hash' ? 3 : 2)
})

test('real Mojang processor preserves and reuses original metadata bytes only when SHA1 matches', async t => {
    const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'chur-vendor-bytes-')))
    t.after(() => fs.rmSync(root, { recursive: true, force: true }))
    const raw = Buffer.from('{  "objects": {} }\n'), filename = path.join(root, 'assets/indexes/fixture.json')
    let requests = 0
    const processor = new SafeMojangProcessor(root, '1.21.4', async () => { requests++; return raw })
    const hash = { algo: 'sha1', value: digest(raw, 'sha1') }
    await processor.loadContentWithRemoteFallback('https://piston-meta.mojang.com/fixture', filename, hash)
    assert.deepEqual(fs.readFileSync(filename), raw)
    await processor.loadContentWithRemoteFallback('https://piston-meta.mojang.com/fixture', filename, hash)
    assert.equal(requests, 1)
    await assert.rejects(processor.loadContentWithRemoteFallback('https://piston-meta.mojang.com/fixture', path.join(root, '..', 'escape.json'), hash), { code: 'TRUST_PATH_ESCAPE' })
    assert.equal(requests, 1)
})

test('vendor downloads keep SHA1 compatibility and reject HTTPS redirect outside official hosts', async t => {
    const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'chur-vendor-download-')))
    t.after(() => fs.rmSync(root, { recursive: true, force: true }))
    const bytes = Buffer.from('AUDIT_FAKE_VENDOR_FILE'), target = path.join(root, 'library.jar')
    const asset = { id: 'fixture', url: 'https://libraries.minecraft.net/fixture.jar', path: target, size: bytes.length, hash: digest(bytes, 'sha1'), algo: 'sha1' }
    let redirect = true, requests = 0
    const request = (_url, options, callback) => {
        requests++; assert.equal(options.rejectUnauthorized, true)
        const req = new EventEmitter(); req.destroy = error => req.emit('error', error)
        process.nextTick(() => {
            const response = Readable.from(redirect ? [] : [bytes])
            response.statusCode = redirect ? 302 : 200
            response.headers = redirect ? { location: 'https://unapproved.invalid/fixture.jar' } : { 'content-length': String(bytes.length) }
            callback(response)
        })
        return req
    }
    fs.writeFileSync(target, 'original')
    await assert.rejects(downloadVendorQueue([asset], () => {}, root, request), { code: 'TRUST_VENDOR_URL_INVALID' })
    assert.equal(requests, 1); assert.equal(fs.readFileSync(target, 'utf8'), 'original')
    redirect = false
    assert.deepEqual(await downloadVendorQueue([asset], () => {}, root, request), { fixture: bytes.length })
    assert.deepEqual(fs.readFileSync(target), bytes)
})
