'use strict'

const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const util = require('node:util')
const errors = require('../app/assets/js/auth-errors')
const source = fs.readFileSync(path.join(__dirname, '../app/assets/js/authmanager.js'), 'utf8')
const NOW = 1800000000000
const SECRET = 'BROWSER_AUDIT_FAKE_SECRET_NOT_A_CREDENTIAL'
const stages = ['getAccessToken', 'getXBLToken', 'getXSTSToken', 'getMCAccessToken', 'getMCProfile']
const microsoftToken = () => ({access_token: SECRET + '_ms', refresh_token: SECRET + '_refresh', expires_in: 3600})
const account = uuid => ({type: 'microsoft', uuid, displayName: 'Audit ' + uuid,
    accessToken: SECRET + '_old_mc', expiresAt: NOW + 100000,
    microsoft: {access_token: SECRET + '_old_ms', refresh_token: SECRET + '_old_refresh', expires_at: NOW + 100000}})

// Execute the product module with synthetic providers and a synchronous atomic
// storage boundary. This fixture never opens an actual launcher profile/network.
function harness(initial = [account('A'), account('B')]) {
    let database = Object.fromEntries(initial.map(value => [value.uuid, value]))
    let selected = initial[0]?.uuid, revision = 0, now = NOW, failSave = false
    let saves = 0, durableSaves = 0
    const calls = [], logs = []
    const ok = data => ({responseStatus: 0, data})
    const config = {
        getSelectedAccount: () => database[selected],
        getAuthAccount: uuid => database[uuid],
        getAuthRevision: () => revision,
        setSelectedAccount(uuid) { if(database[uuid] && selected !== uuid) {selected = uuid; revision++} },
        addMicrosoftAuthAccount(uuid, accessToken, name, expiresAt, access_token, refresh_token, expires_at) {
            const value = {type: 'microsoft', uuid, displayName: name, accessToken, expiresAt,
                microsoft: {access_token, refresh_token, expires_at}}
            database[uuid] = value; selected = uuid; revision++
            return value
        },
        removeAuthAccount(uuid) {
            if(database[uuid]) {
                delete database[uuid]
                if(selected === uuid) selected = Object.keys(database)[0]
                revision++
            }
        },
        transactionAuth(action) {
            const before = database, beforeSelected = selected
            database = {...database}
            try {
                const result = action(); saves++
                assert.equal(typeof result?.then, 'undefined', 'the atomic storage action must stay synchronous')
                if(failSave) throw new Error(SECRET + '_storage_failure')
                durableSaves++
                return result
            } catch(error) {
                database = before; selected = beforeSelected; revision++
                throw error
            }
        }
    }
    const handlers = {
        getAccessToken: async () => ok(microsoftToken()),
        getXBLToken: async () => ok({Token: SECRET + '_xbl'}),
        getXSTSToken: async () => ok({Token: SECRET + '_xsts', DisplayClaims: {xui: [{uhs: 'FAKE_UHS'}]}}),
        getMCAccessToken: async () => ok({access_token: SECRET + '_mc', expires_in: 7200}),
        getMCProfile: async () => ok({id: 'NEW', name: 'Fake Browser Player'})
    }
    const MicrosoftAuth = Object.fromEntries(stages.map(name => [name, async (...args) => {
        calls.push({name, args}); return handlers[name](...args)
    }]))
    const dependencies = {
        './configmanager': config, './auth-errors': errors,
        'helios-core': {LoggerUtil: {getLogger: () => Object.fromEntries(['warn', 'error', 'info', 'debug'].map(level => [level, (...args) => logs.push(args)]))}},
        'helios-core/common': {RestResponseStatus: {SUCCESS: 0, ERROR: 1}},
        'helios-core/microsoft': {MicrosoftAuth, MicrosoftErrorCode: {NO_PROFILE: 1, NO_XBOX_ACCOUNT: 2, XBL_BANNED: 3, UNDER_18: 4}},
        './ipcconstants': {AZURE_CLIENT_ID: 'FAKE_PUBLIC_CLIENT'}, './langloader': {queryJS: key => key}
    }
    const module = {exports: {}}
    vm.runInNewContext(source, {module, exports: module.exports, Error,
        Date: class extends Date {static now() {return now}},
        require(id) {assert.ok(Object.hasOwn(dependencies, id), 'unexpected dependency: ' + id); return dependencies[id]}
    }, {filename: 'authmanager.js', timeout: 5000})
    return {auth: module.exports, config, handlers, calls, logs, ok,
        get saves() {return saves}, get durableSaves() {return durableSaves},
        advance(ms) {now += ms}, failSave() {failSave = true},
        assertSafe(error) {
            assert.equal(util.inspect(logs, {depth: null}).includes(SECRET), false)
            if(error) assert.equal(util.inspect(error, {showHidden: true}).includes(SECRET), false)
        }
    }
}

function deferred() {
    let resolve, reject
    const promise = new Promise((yes, no) => {resolve = yes; reject = no})
    return {promise, resolve, reject}
}

const cancelled = error => error.code === 'AUTH_STATE_CHANGED' && error.cancelled

test('device tokens use the existing Xbox/Minecraft flow and one complete atomic save', async () => {
    const h = harness(), a = h.config.getAuthAccount('A'), b = h.config.getAuthAccount('B')
    const session = h.auth.beginMicrosoftLogin()
    assert.deepEqual(Object.keys(session), ['addCode', 'addTokens']); assert.ok(Object.isFrozen(session))
    assert.equal(h.calls.length, 0)
    const result = await session.addTokens(microsoftToken())
    assert.deepEqual(h.calls.map(call => call.name), stages.slice(1))
    assert.equal(h.calls[0].args[0], SECRET + '_ms')
    assert.equal(result, h.config.getSelectedAccount()); assert.equal(result.uuid, 'NEW')
    assert.equal(result.microsoft.refresh_token, SECRET + '_refresh')
    assert.equal(h.config.getAuthAccount('A'), a); assert.equal(h.config.getAuthAccount('B'), b)
    assert.equal(h.durableSaves, 1); h.assertSafe()
})

test('popup code and legacy API still exchange the code with the configured public client', async t => {
    for(const mode of ['captured', 'legacy']) await t.test(mode, async () => {
        const h = harness([])
        const result = await (mode === 'legacy' ? h.auth.addMicrosoftAccount(SECRET + '_code')
            : h.auth.beginMicrosoftLogin().addCode(SECRET + '_code'))
        assert.deepEqual(h.calls.map(call => call.name), stages)
        assert.deepEqual(h.calls[0].args, [SECRET + '_code', false, 'FAKE_PUBLIC_CLIENT'])
        assert.equal(result.microsoft.expires_at, NOW + 3590000)
        assert.equal(result.expiresAt, NOW + 7190000); assert.equal(h.durableSaves, 1)
    })
})

test('state captured before the external browser rejects selection changes and remove/re-add', async t => {
    for(const mode of ['code', 'tokens']) for(const change of ['select', 'select-back', 'remove', 'remove-readd']) {
        await t.test(mode + ':' + change, async () => {
            const h = harness(), session = h.auth.beginMicrosoftLogin()
            if(change.startsWith('select')) {
                h.config.setSelectedAccount('B')
                if(change === 'select-back') h.config.setSelectedAccount('A')
            } else {
                h.config.removeAuthAccount('A')
                if(change === 'remove-readd') h.config.addMicrosoftAuthAccount('A', 'new', 'replacement', NOW + 1, 'new', 'new', NOW + 1)
            }
            const selected = h.config.getSelectedAccount()
            await assert.rejects(mode === 'code' ? session.addCode(SECRET) : session.addTokens(microsoftToken()), cancelled)
            assert.equal(h.config.getSelectedAccount(), selected); assert.equal(h.calls.length, 0); assert.equal(h.saves, 0)
        })
    }
})

test('aborted before or after session creation never requests or saves credentials', async t => {
    for(const before of [true, false]) for(const method of ['addCode', 'addTokens']) await t.test(before + ':' + method, async () => {
        const h = harness(), controller = new AbortController()
        if(before) controller.abort(SECRET)
        const session = h.auth.beginMicrosoftLogin(controller.signal)
        if(!before) controller.abort(new Error(SECRET))
        await assert.rejects(session[method](method === 'addCode' ? SECRET : microsoftToken()), error => {
            h.assertSafe(error); return cancelled(error)
        })
        assert.equal(h.calls.length, 0); assert.equal(h.saves, 0)
    })
})

test('cancellation after every provider response prevents the next request and commit', async t => {
    for(const stage of stages) await t.test(stage, async () => {
        const h = harness(), before = h.config.getSelectedAccount(), controller = new AbortController()
        const original = h.handlers[stage]
        h.handlers[stage] = async () => {const result = await original(); controller.abort(SECRET); return result}
        await assert.rejects(h.auth.beginMicrosoftLogin(controller.signal).addCode(SECRET), cancelled)
        assert.deepEqual(h.calls.map(call => call.name), stages.slice(0, stages.indexOf(stage) + 1))
        assert.equal(h.config.getSelectedAccount(), before); assert.equal(h.saves, 0); h.assertSafe()
    })
})

test('a selection change while any provider is pending stops that login before the next stage', async t => {
    for(const stage of stages) await t.test(stage, async () => {
        const h = harness(), entered = deferred(), hold = deferred(), original = h.handlers[stage]
        h.handlers[stage] = () => {entered.resolve(); return hold.promise}
        const pending = h.auth.beginMicrosoftLogin().addCode(SECRET)
        await entered.promise; h.config.setSelectedAccount('B'); hold.resolve(await original())
        await assert.rejects(pending, cancelled)
        assert.equal(h.config.getSelectedAccount().uuid, 'B'); assert.equal(h.saves, 0)
        assert.equal(h.calls.length, stages.indexOf(stage) + 1)
    })
})

test('logout during profile lookup cannot resurrect the removed account', async () => {
    const h = harness(), hold = deferred(), entered = deferred()
    h.handlers.getMCProfile = () => {entered.resolve(); return hold.promise}
    const pending = h.auth.beginMicrosoftLogin().addTokens(microsoftToken())
    await entered.promise; await h.auth.removeMicrosoftAccount('A')
    hold.resolve(h.ok({id: 'A', name: 'Old User'}))
    await assert.rejects(pending, cancelled)
    assert.equal(h.config.getAuthAccount('A'), undefined); assert.equal(h.config.getSelectedAccount().uuid, 'B')
    assert.equal(h.durableSaves, 1, 'only the user-requested logout was persisted')
})

test('cancellation while a provider fails suppresses raw errors and preserves the prior account', async () => {
    const h = harness(), hold = deferred(), entered = deferred(), controller = new AbortController()
    const before = h.config.getSelectedAccount()
    h.handlers.getXBLToken = () => {entered.resolve(); return hold.promise}
    const pending = h.auth.beginMicrosoftLogin(controller.signal).addTokens(microsoftToken())
    await entered.promise; controller.abort(SECRET); hold.reject(new Error(SECRET))
    await assert.rejects(pending, error => {h.assertSafe(error); return cancelled(error)})
    assert.equal(h.config.getSelectedAccount(), before); assert.equal(h.saves, 0)
})

test('one captured login can be used only once, including concurrent mixed methods', async () => {
    const h = harness(), hold = deferred(), entered = deferred()
    h.handlers.getAccessToken = () => {entered.resolve(); return hold.promise}
    const session = h.auth.beginMicrosoftLogin(), pending = session.addCode(SECRET)
    await entered.promise
    await assert.rejects(session.addTokens(microsoftToken()), cancelled)
    assert.equal(h.calls.length, 1)
    hold.resolve(h.ok(microsoftToken())); await pending
    await assert.rejects(session.addCode(SECRET), cancelled)
    assert.equal(h.durableSaves, 1)
})

test('independent overlapping sessions cannot overwrite an account saved by the first finisher', async () => {
    const h = harness(), one = h.auth.beginMicrosoftLogin(), two = h.auth.beginMicrosoftLogin()
    await one.addTokens(microsoftToken())
    const current = h.config.getSelectedAccount(), calls = h.calls.length
    await assert.rejects(two.addTokens(microsoftToken()), cancelled)
    assert.equal(h.config.getSelectedAccount(), current); assert.equal(h.calls.length, calls); assert.equal(h.durableSaves, 1)
})

test('malformed or overflowing supplied Microsoft tokens cause no service request or overwrite', async t => {
    const invalid = [null, {}, {access_token: SECRET, expires_in: 3600},
        {...microsoftToken(), access_token: ''}, {...microsoftToken(), refresh_token: ''},
        ...[0, 10, -1, 10.5, Infinity, NaN, '3600', Number.MAX_SAFE_INTEGER].map(expires_in => ({...microsoftToken(), expires_in}))]
    for(let i = 0; i < invalid.length; i++) await t.test(String(i), async () => {
        const h = harness(), before = h.config.getSelectedAccount()
        await assert.rejects(h.auth.beginMicrosoftLogin().addTokens(invalid[i]), error => error.code === 'AUTH_INVALID_RESPONSE')
        assert.equal(h.calls.length, 0); assert.equal(h.saves, 0); assert.equal(h.config.getSelectedAccount(), before)
    })
})

test('invalid provider responses do not partially install a browser account', async t => {
    for(const stage of stages.slice(1)) await t.test(stage, async () => {
        const h = harness(), before = h.config.getSelectedAccount()
        h.handlers[stage] = async () => h.ok({})
        await assert.rejects(h.auth.beginMicrosoftLogin().addTokens(microsoftToken()), error => error.code === 'AUTH_INVALID_RESPONSE')
        assert.equal(h.config.getSelectedAccount(), before); assert.equal(h.saves, 0)
    })
})

test('device token expiry is measured on receipt, separately from the Minecraft token', async () => {
    const h = harness(), token = microsoftToken()
    // The external approval may take minutes; the token lifetime starts when
    // tokens are delivered, not when the login operation was first created.
    const session = h.auth.beginMicrosoftLogin()
    h.advance(600000)
    h.handlers.getXBLToken = async () => {h.advance(12000); return h.ok({Token: SECRET + '_xbl'})}
    h.handlers.getMCProfile = async () => {h.advance(25000); return h.ok({id: 'NEW', name: 'Audit'})}
    const pending = session.addTokens(token)
    token.access_token = 'changed'; token.refresh_token = 'changed'; token.expires_in = 999999
    const result = await pending
    assert.equal(result.microsoft.access_token, SECRET + '_ms')
    assert.equal(result.microsoft.refresh_token, SECRET + '_refresh')
    assert.equal(result.microsoft.expires_at, NOW + 600000 + 3590000)
    assert.equal(result.expiresAt, NOW + 600000 + 12000 + 7190000)
})

test('popup token expiry starts at its exchange response and never extends by profile delay', async () => {
    const h = harness()
    h.handlers.getAccessToken = async () => {h.advance(20000); return h.ok(microsoftToken())}
    h.handlers.getXBLToken = async () => {h.advance(5000); return h.ok({Token: SECRET + '_xbl'})}
    h.handlers.getMCProfile = async () => {h.advance(17000); return h.ok({id: 'NEW', name: 'Audit'})}
    const result = await h.auth.beginMicrosoftLogin().addCode(SECRET)
    assert.equal(result.microsoft.expires_at, NOW + 20000 + 3590000)
    assert.equal(result.expiresAt, NOW + 25000 + 7190000)
})

test('tokens which expire during the remaining authentication cannot replace an existing account', async t => {
    for(const expired of ['microsoft', 'minecraft']) await t.test(expired, async () => {
        const h = harness(), before = h.config.getSelectedAccount(), token = microsoftToken()
        if(expired === 'microsoft') token.expires_in = 15
        else h.handlers.getMCAccessToken = async () => h.ok({access_token: SECRET, expires_in: 15})
        h.handlers.getMCProfile = async () => {h.advance(6000); return h.ok({id: 'NEW', name: 'Audit'})}
        await assert.rejects(h.auth.beginMicrosoftLogin().addTokens(token), error => error.code === 'AUTH_INVALID_RESPONSE')
        assert.equal(h.config.getSelectedAccount(), before); assert.equal(h.saves, 0)
    })
})

test('atomic save failure retains old account identities and reports storage failure, not cancellation', async t => {
    for(const mode of ['code', 'tokens']) await t.test(mode, async () => {
        const h = harness(), before = h.config.getSelectedAccount(), other = h.config.getAuthAccount('B')
        h.failSave()
        const session = h.auth.beginMicrosoftLogin()
        await assert.rejects(mode === 'code' ? session.addCode(SECRET) : session.addTokens(microsoftToken()), error => {
            h.assertSafe(error); return error.code === 'AUTH_STORAGE_FAILURE'
        })
        assert.equal(h.config.getSelectedAccount(), before); assert.equal(h.config.getAuthAccount('B'), other)
        assert.equal(h.config.getAuthAccount('NEW'), undefined); assert.equal(h.durableSaves, 0)
    })
})
