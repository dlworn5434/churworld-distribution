const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const vm = require('node:vm')

// Execute the product store against an in-memory filesystem. The darwin branch
// exercises directory fsync; no user profile or physical test file is accessed.
function harness({legacy = false} = {}) {
    const directory = '/AUDIT_FAKE_ONLY', main = directory + '/config.json'
    const legacyPath = '/AUDIT_LEGACY/config.json'
    const files = new Map(), handles = new Map()
    let nextHandle = 1, failure = null, primaryRenamed = false
    const error = code => Object.assign(new Error('Synthetic filesystem failure'), {code})
    const fail = phase => { if(failure === phase) throw error('EIO') }
    const fakeFS = {
        mkdirSync() {},
        existsSync(file) { return files.has(file) },
        lstatSync(file) {
            if(!files.has(file)) throw error('ENOENT')
            return {isFile: () => true, isSymbolicLink: () => false, size: files.get(file).length}
        },
        readFileSync(file) {
            if(typeof file === 'number') file = handles.get(file).file
            if(!files.has(file)) throw error('ENOENT')
            return Buffer.from(files.get(file))
        },
        openSync(file, flags) {
            if(flags === 'wx') {
                if(files.has(file)) throw error('EEXIST')
                files.set(file, Buffer.alloc(0))
            }
            const fd = nextHandle++
            handles.set(fd, {file, directory: file === directory})
            return fd
        },
        writeFileSync(fd, bytes) { files.set(handles.get(fd).file, Buffer.from(bytes)) },
        fsyncSync(fd) {
            const handle = handles.get(fd)
            if(handle.directory && primaryRenamed) fail('post-primary-directory-sync')
            if(!handle.directory && handle.file.includes('.config.json.')) fail('primary-file-sync')
        },
        fchmodSync(fd) { if(handles.get(fd).file.includes('.config.json.')) fail('primary-mode') },
        chmodSync(file) { if(file === main || file.includes('.config.json.')) fail('primary-mode') },
        closeSync(fd) { handles.delete(fd) },
        renameSync(from, to) {
            if(to === main) fail('primary-rename')
            if(!files.has(from)) throw error('ENOENT')
            files.set(to, files.get(from))
            files.delete(from)
            if(to === main) primaryRenamed = true
        },
        unlinkSync(file) {
            if(primaryRenamed && file.includes('.config.json.')) fail('post-commit-temp-cleanup')
            if(!files.delete(file)) throw error('ENOENT')
        }
    }
    const module = {exports: {}}
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../app/assets/js/protectedconfig.js'), 'utf8'), {
        module, Buffer, process: {platform: 'darwin'},
        require(id) {
            if(id === 'node:fs') return fakeFS
            if(id === 'node:path') return path.posix
            if(id === 'node:crypto') return crypto
            throw new Error('Blocked unexpected dependency')
        }
    }, {filename: 'protectedconfig.js', timeout: 5000})
    const key = crypto.randomBytes(32)
    const encryption = {
        encryptString(value) {
            const iv = crypto.randomBytes(12), cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
            const body = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()])
            return Buffer.concat([iv, cipher.getAuthTag(), body])
        },
        decryptString(value) {
            const cipher = crypto.createDecipheriv('aes-256-gcm', key, value.subarray(0, 12))
            cipher.setAuthTag(value.subarray(12, 28))
            return Buffer.concat([cipher.update(value.subarray(28)), cipher.final()]).toString('utf8')
        }
    }
    const makeStore = () => new module.exports.ProtectedConfigStore({directory, encryption, legacyPath: legacy ? legacyPath : undefined})
    const store = makeStore()
    const defaults = {settings: {example: 1}, authenticationDatabase: {
        fake: {uuid: 'fake', type: 'microsoft', accessToken: 'AUDIT_FAKE_SECRET_NOT_CREDENTIAL'}
    }, selectedAccount: 'fake', clientToken: null}
    if(legacy) files.set(legacyPath, Buffer.from(JSON.stringify(defaults)))
    return {store, defaults, makeStore,
        failAt(phase) { failure = phase; primaryRenamed = false },
        bytes: () => Buffer.from(files.get(main)),
        disk: () => store.decode(files.get(main)),
        legacyExists: () => files.has(legacyPath),
        removePrimary: () => files.delete(main),
        primaryExists: () => files.has(main),
        previousBytes: () => Buffer.from(files.get(store.previousFile)),
        tempFiles: () => [...files.keys()].filter(name => name.endsWith('.tmp'))
    }
}

test('post-rename directory fsync failure keeps committed disk and runtime generations aligned', () => {
    const h = harness(), loaded = h.store.load(h.defaults)
    loaded.config.authenticationDatabase = {}; loaded.config.selectedAccount = null
    h.failAt('post-primary-directory-sync')
    const saved = h.store.save(loaded.config, loaded.revision)
    assert.ok(saved.revision > loaded.revision)
    assert.equal(saved.warning, 'CONFIG_DURABILITY_UNCONFIRMED')
    assert.equal(h.disk().selectedAccount, null)
    assert.equal(h.store.result().config.selectedAccount, null)
    assert.equal(h.store.expectedDigest, crypto.createHash('sha256').update(h.bytes()).digest('hex'))
    assert.deepEqual(h.tempFiles(), [])
})

test('a save after a post-rename warning uses the committed generation', () => {
    const h = harness(), loaded = h.store.load(h.defaults)
    loaded.config.settings.example = 2
    h.failAt('post-primary-directory-sync')
    const warned = h.store.save(loaded.config, loaded.revision)
    h.failAt(null)
    loaded.config.settings.example = 3
    const saved = h.store.save(loaded.config, warned.revision)
    assert.ok(saved.revision > warned.revision)
    assert.equal(h.disk().settings.example, 3)
    assert.equal(h.store.result().config.settings.example, 3)
})

test('first-load directory fsync warning does not discard the committed profile', () => {
    const h = harness(); h.failAt('post-primary-directory-sync')
    const loaded = h.store.load(h.defaults)
    assert.equal(loaded.warning, 'CONFIG_DURABILITY_UNCONFIRMED')
    assert.equal(loaded.firstLaunch, true)
    assert.equal(loaded.config.selectedAccount, 'fake')
    assert.equal(h.disk().selectedAccount, 'fake')
    assert.equal(h.store.loaded, true)
})

test('successful rename does not perform fallible cleanup of its already-consumed temporary path', () => {
    const h = harness(), loaded = h.store.load(h.defaults)
    loaded.config.settings.example = 2
    h.failAt('post-commit-temp-cleanup')
    const saved = h.store.save(loaded.config, loaded.revision)
    assert.ok(saved.revision > loaded.revision)
    assert.equal(h.disk().settings.example, 2)
    assert.equal(h.store.result().config.settings.example, 2)
})

test('legacy migration never removes the source before destination durability is confirmed', () => {
    const h = harness({legacy: true}); h.failAt('post-primary-directory-sync')
    const loaded = h.store.load(h.defaults)
    assert.equal(loaded.warning, 'CONFIG_DURABILITY_UNCONFIRMED')
    assert.equal(h.legacyExists(), true)
    assert.equal(h.disk().selectedAccount, 'fake')
    assert.equal(h.store.result().config.selectedAccount, 'fake')
})

test('legacy migration retries matching plaintext cleanup on the next durable startup', () => {
    const h = harness({legacy: true}); h.failAt('post-primary-directory-sync')
    h.store.load(h.defaults)
    assert.equal(h.legacyExists(), true)
    h.failAt(null)
    const restarted = h.makeStore().load(h.defaults)
    assert.equal(restarted.config.selectedAccount, 'fake')
    assert.equal(h.legacyExists(), false)
})

test('missing primary with a protected backup stops without creating defaults or overwriting recovery data', () => {
    const h = harness(), loaded = h.store.load(h.defaults)
    h.store.save(loaded.config, loaded.revision)
    const previous = h.previousBytes()
    h.removePrimary()
    assert.throws(() => h.makeStore().load(h.defaults), {code: 'CONFIG_RECOVERY_REQUIRED'})
    assert.equal(h.primaryExists(), false)
    assert.deepEqual(h.previousBytes(), previous)
})

test('explicit recovery restores the protected profile without changing its backup', () => {
    const h = harness(), loaded = h.store.load(h.defaults)
    h.store.save(loaded.config, loaded.revision)
    const previous = h.previousBytes()
    h.removePrimary()
    const restarted = h.makeStore()
    restarted.recoverPrevious()
    assert.deepEqual(h.bytes(), previous)
    assert.deepEqual(h.previousBytes(), previous)
    assert.equal(restarted.load(h.defaults).config.selectedAccount, 'fake')
})

for(const phase of ['primary-file-sync', 'primary-mode', 'primary-rename']) {
    test(phase + ' failure before replacement preserves the original profile', () => {
        const h = harness(), loaded = h.store.load(h.defaults), before = h.bytes()
        loaded.config.authenticationDatabase = {}; loaded.config.selectedAccount = null
        h.failAt(phase)
        assert.throws(() => h.store.save(loaded.config, loaded.revision), {code: 'CONFIG_WRITE_FAILED'})
        assert.deepEqual(h.bytes(), before)
        assert.equal(h.store.result().revision, loaded.revision)
        assert.equal(h.store.result().config.selectedAccount, 'fake')
        assert.deepEqual(h.tempFiles(), [])
    })
}
