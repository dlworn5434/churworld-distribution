'use strict'
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os')
const {createLauncherService}=require('../app/assets/js/launcher-service')
function fixture(t){
    const dir=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'churu-service-test-')));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}))
    const state={settings:{game:{resWidth:1280,resHeight:720,fullscreen:false,autoConnect:true,launchDetached:true},launcher:{allowPrerelease:false,dataDirectory:dir}},
        javaConfig:{s:{minRAM:'2G',maxRAM:'4G',executable:null,jvmOptions:[]}},modConfigurations:[{id:'s',mods:{}}],newsCache:{content:null,date:null,dismissed:false},selectedServer:'s',selectedDestination:'life',selectedAccount:'a',
        authenticationDatabase:{a:{uuid:'a',displayName:'A',type:'microsoft'}},authRevision:0,paths:{common:path.join(dir,'common'),instances:path.join(dir,'instances'),launcher:dir}}
    let failedSave=false, busy=false, loginCalls=0, removals=0, selected='a', trustFailure=false
    const config={bindStorage(){},load(){},getPublicState:()=>structuredClone(state),getCommonDirectory:()=>state.paths.common,getInstanceDirectory:()=>state.paths.instances,
        getSelectedServer:()=>state.selectedServer,getSelectedDestination:()=>state.selectedDestination,getAuthAccount:uuid=>state.authenticationDatabase[uuid],getAuthAccounts:()=>state.authenticationDatabase,
        transactionAuth(fn){const old=selected;try{fn();if(failedSave)throw {code:'CONFIG_WRITE_FAILED'}}catch(e){selected=old;state.selectedAccount=old;throw e}},setSelectedAccount(uuid){selected=uuid;state.selectedAccount=uuid},
        commitPublicPreferences(next){if(failedSave)throw {code:'CONFIG_WRITE_FAILED'};Object.assign(state,next);return this.getPublicState()}}
    const server={rawServer:{id:'s',name:'server',minecraftVersion:'1.21.4'},modules:[],effectiveJavaOptions:{supported:'>=21'}}
    const distro={servers:[server],rawDistribution:{},getServerById:id=>id==='s'?server:null,getMainServer:()=>server}
    const sync=new Map(),async=new Map(),frames={url:'file:///synthetic/app.ejs'},webContents={mainFrame:frames,send(){}},win={isDestroyed:()=>false,webContents,isMaximized:()=>false}
    const event={sender:webContents,senderFrame:frames},diagnostic=path.join(dir,'diagnostics.json')
    const service=createLauncherService({app:{getVersion:()=> 'test',isPackaged:true},ipcMain:{on:(k,f)=>sync.set(k,f),handle:(k,f)=>async.set(k,f)},
        dialog:{showOpenDialog:async()=>({canceled:false,filePaths:[path.join(dir,'java.exe')]}),showSaveDialog:async()=>({canceled:false,filePath:diagnostic})},
        shell:{openExternal:async()=>{},trashItem:async(file)=>fs.unlinkSync(file)},windowFor:()=>win,documentURL:frames.url,store:{},update:{},
        login:async()=>{loginCalls++},logout:async()=>true,dependencies:{ConfigManager:config,AuthManager:{validateSelected:async()=>true,removeMicrosoftAccount:async()=>{removals++}},
            distribution:{DistroAPI:{getDistribution:async()=>distro,getTrustStatus:()=>{if(trustFailure)throw {code:'TRUST_SIGNATURE_INVALID'};return {offlineOnly:false}}}},synchronization:{syncModConfigurations(){},ensureJavaSettings(){}},game:{isBusy:()=>busy,launch:async()=>true}}})
    const callSync=(operation,data,override=event)=>{sync.get('churu-ui-sync')(override,{operation,data});return override.returnValue}
    const call=(operation,data,override=event)=>async.get('churu-ui')(override,{operation,data})
    return {dir,state,config,service,callSync,call,event,diagnostic,setFailure:value=>failedSave=value,setBusy:value=>busy=value,setTrustFailure:value=>trustFailure=value,counts:()=>({loginCalls,removals})}
}
test('real bridge whitelist denies secret/raw filesystem/IPC operations and foreign frames',async t=>{
    const f=fixture(t);await f.call('distribution.read')
    for(const op of ['getClientToken','authenticationDatabase','require','readFile','spawn','TRASH_ITEM','churu-protected-config','__proto__']){
        assert.equal(f.callSync(op).ok,false);assert.equal((await f.call(op)).ok,false)
    }
    assert.equal(f.callSync('bootstrap',null,{...f.event,senderFrame:{url:f.event.senderFrame.url}}).ok,false)
    const boot=f.callSync('bootstrap').value;assert.equal(JSON.stringify(boot).includes('accessToken'),false)
    assert.equal((await f.call('accounts.login')).ok,true);assert.equal(f.counts().loginCalls,1)
})
test('preferences merge is isolated from accounts and storage failure preserves state',async t=>{
    const f=fixture(t);await f.call('distribution.read')
    const preferences=()=>Object.fromEntries(['settings','javaConfig','modConfigurations','newsCache','selectedServer','selectedDestination'].map(k=>[k,structuredClone(f.state[k])]))
    const next=preferences();next.authenticationDatabase={};assert.equal(f.callSync('preferences.save',next).ok,false)
    const valid=preferences();valid.settings.game.resWidth=1920;f.setFailure(true)
    assert.equal(f.callSync('preferences.save',valid).ok,false);assert.equal(f.state.settings.game.resWidth,1280);assert.ok(f.state.authenticationDatabase.a)
    f.setFailure(false);assert.equal(f.callSync('preferences.save',valid).ok,true);assert.equal(f.state.settings.game.resWidth,1920)
    f.setBusy(true);assert.equal(f.callSync('preferences.save',valid).ok,false)
})
test('file APIs address listed mod basenames only; arbitrary paths and dangling shader links are rejected',async t=>{
    const f=fixture(t);await f.call('distribution.read');const mods=path.join(f.dir,'instances/s/mods');fs.mkdirSync(mods,{recursive:true});fs.writeFileSync(path.join(mods,'one.jar'),'fixture')
    assert.equal(f.callSync('files.scanMods').value.length,1)
    assert.equal((await f.call('files.toggleMod',{name:'one.jar',enabled:false})).ok,true);assert.equal(fs.existsSync(path.join(mods,'one.jar.disabled')),true)
    for(const name of ['../outside.jar',path.join(mods,'one.jar.disabled'),'nonexistent.jar'])assert.equal((await f.call('files.removeMod',name)).ok,false)
    const outside=path.join(f.dir,'should-not-exist.txt'),link=path.join(f.dir,'instances/s/optionsshaders.txt');fs.symlinkSync(outside,link,'file')
    assert.equal(f.callSync('files.selectShader','OFF').ok,false);assert.equal(fs.existsSync(outside),false)
})
test('safe diagnostic records trusted failure codes without credential/body or account identifiers',async t=>{
    const f=fixture(t);f.service.recordFault({code:'TRUST_MANIFEST_EXPIRED',message:'FAKE_PRIVATE_TOKEN',body:'FAKE_PASSWORD'},'launcher-update')
    assert.equal((await f.call('diagnostics.export')).ok,true)
    const text=fs.readFileSync(f.diagnostic,'utf8');assert.equal(text.includes('TRUST_MANIFEST_EXPIRED'),true);assert.equal(text.includes('FAKE_'),false);assert.equal(text.includes('authenticationDatabase'),false);assert.equal(text.includes(f.dir),false)
})

test('diagnostics remain exportable when cached distribution signature has become invalid',async t=>{
    const f=fixture(t);await f.call('distribution.read');f.setTrustFailure(true)
    assert.equal((await f.call('diagnostics.export')).ok,true)
    const report=JSON.parse(fs.readFileSync(f.diagnostic,'utf8'));assert.equal(report.distributionTrust.unavailable,true)
    assert.equal(report.distributionTrust.code,'TRUST_SIGNATURE_INVALID');assert.equal(report.rendererIsolation,true)
})
