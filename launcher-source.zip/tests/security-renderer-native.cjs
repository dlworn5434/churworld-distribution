'use strict'
// Synthetic native test: no production app entry, user profile, network, auth or game process.
const {app, BrowserWindow, ipcMain, session} = require('electron')
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), assert = require('node:assert/strict')
const {pathToFileURL} = require('node:url')
const root = path.resolve(__dirname, '..'), temp = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'churu-renderer-test-')))
app.setPath('userData', path.join(temp, 'profile'))
process.env.APPDATA = temp
process.env.HOME = temp
app.disableHardwareAcceleration()
const ejse = require('ejs-electron'), toml = require('toml'), merge = require('lodash.merge')
const language = merge({}, toml.parse(fs.readFileSync(path.join(root, 'app/assets/lang/en_US.toml'), 'utf8')),
    toml.parse(fs.readFileSync(path.join(root, 'app/assets/lang/_custom.toml'), 'utf8')))
const query = (id, values = {}) => { let result = id.split('.').reduce((v,k) => v?.[k], language) || id;
    for(const [key,val] of Object.entries(values)) result = result.replaceAll('{' + key + '}', val); return result }
const state = {settings: {game: {resWidth: 1280, resHeight: 720, fullscreen: false, autoConnect: true, launchDetached: true},
    launcher: {allowPrerelease: false, dataDirectory: temp}}, javaConfig: {churworld: {minRAM: '2G', maxRAM: '4G', executable: path.join(temp,'synthetic-java.exe'), jvmOptions: []}},
    modConfigurations: [{id: 'churworld', mods: {}}], newsCache: {content: null, date: null, dismissed: false}, selectedServer: 'churworld',
    selectedDestination: 'life', selectedAccount: 'fake-uuid', authenticationDatabase: {'fake-uuid': {uuid: 'fake-uuid', displayName: 'TestUser', type: 'microsoft'}},
    authRevision: 0, firstLaunch: false, paths: {data: temp, common: temp, instances: temp, launcher: temp}}
state.defaults = structuredClone({settings: state.settings})
const distro = {mainServerId: 'churworld', rawDistribution: {rss: null}, servers: [{rawServer: {id: 'churworld', name: 'ChurWorld test',
    description: 'Synthetic fixture', minecraftVersion: '1.21.4', version: '1.0', icon: '', mainServer: true, javaOptions: {ram: {minimum: 2048}}},
    effectiveJavaOptions: {suggestedMajor: 21, supported: '>=21', distribution: 'temurin'}, hostname: 'invalid.local', port: 25565, modules: []}]}
let win, launches = 0, externalCalls = 0, diagnosticCalls = 0, javaChecks = 0
const errors = []
const documentURL = pathToFileURL(path.join(root,'app/app.ejs')).href
const {trustedSender} = require('../app/assets/js/renderer-policy')
const respond = (event, req) => {
    assert.equal(trustedSender(event, win, documentURL), true)
    switch(req.operation) {
        case 'bootstrap': return {state, platform: process.platform, version: '2.2.10', isDev: true, language,
            Type: require('helios-distribution-types').Type, memory: {total: 16 * 1024 ** 3, free: 8 * 1024 ** 3}}
        case 'preferences.read': return state
        case 'preferences.save': Object.assign(state, req.data); return state
        case 'window.maximized': return false
        case 'files.scanMods': return []
        case 'files.scanShaders': return [{fullName:'OFF',name:'Off (Default)'}]
        case 'files.selectedShader': return 'OFF'
        case 'files.selectShader': return true
        default: throw new Error('Unexpected sync op ' + req.operation)
    }
}
app.whenReady().then(async() => {
    // Real main service and ConfigManager; only external side effects use synthetic dependencies.
    const config = {...state, clientToken:'FAKE_PRIVATE_CLIENT',authenticationDatabase:{'fake-uuid':{uuid:'fake-uuid',displayName:'TestUser',type:'microsoft',accessToken:'FAKE_PRIVATE_MC',microsoft:{access_token:'FAKE_PRIVATE_MS',refresh_token:'FAKE_PRIVATE_REFRESH'}}}}
    delete config.paths; delete config.defaults
    let persisted = structuredClone(config), revision = 0
    const fakeDistro = {rawDistribution:{rss:null},servers:distro.servers,getServerById:id=>distro.servers.find(s=>s.rawServer.id===id),getMainServer:()=>distro.servers[0]}
    const {createLauncherService} = require('../app/assets/js/launcher-service')
    createLauncherService({app,ipcMain,dialog:{showSaveDialog:async()=>{diagnosticCalls++;return {canceled:false,filePath:path.join(temp,'diagnostics.json')}}},
        shell:{openExternal:async()=>{externalCalls++},trashItem:async file=>{assert.ok(file.startsWith(temp + path.sep));fs.unlinkSync(file)}},windowFor:()=>win,documentURL,
        store:{result:()=>({config:structuredClone(persisted),revision,firstLaunch:false}),save:(next,expected)=>{assert.equal(expected,revision);persisted=structuredClone(next);return {revision:++revision}}},
        update:{},login:async()=>true,logout:async()=>true,dependencies:{AuthManager:{validateSelected:async()=>true},
            distribution:{DistroAPI:{getDistribution:async()=>fakeDistro}},textFeed:async()=>'<feed/>',
            MojangRestAPI:{status:async()=>({responseStatus:0,data:[]})},getServerStatus:async()=>({players:{online:1,max:100}}),
            game:{isBusy:()=>false,launch:async()=>{launches++;return true},checkJava:async()=>{javaChecks++;return {semverStr:'21.0.1',vendor:'Synthetic'}}}}})
    session.defaultSession.webRequest.onBeforeRequest((details,callback) => callback({cancel:/^https?:/.test(details.url)}))
    ejse.data('bkid', 0); ejse.data('lang',(key,values) => query('ejs.' + key,values))
    win = new BrowserWindow({show:false,width:980,height:552,webPreferences:{preload:path.join(root,'app/assets/js/preloader.js'),
        nodeIntegration:false,contextIsolation:true,sandbox:true,devTools:false}})
    win.webContents.on('console-message',(details) => { if(details.level === 'error' && !/ERR_BLOCKED_BY_CLIENT|Failed to load resource/.test(details.message)) errors.push(details.message) })
    win.webContents.on('preload-error',(_event,_file,error) => errors.push('PRELOAD '+error.message))
    await win.loadURL(documentURL)
    await new Promise(resolve => setTimeout(resolve,2200))
    // Give Chromium a real synthetic File, so sandbox webUtils capability is exercised.
    const imported = path.join(temp, 'synthetic-dropin.jar')
    fs.writeFileSync(imported, 'harmless synthetic mod fixture')
    await win.webContents.executeJavaScript("const input=document.createElement('input');input.type='file';input.id='syntheticImport';document.body.append(input)")
    win.webContents.debugger.attach('1.3')
    const {root:domRoot}=await win.webContents.debugger.sendCommand('DOM.getDocument')
    const {nodeId}=await win.webContents.debugger.sendCommand('DOM.querySelector',{nodeId:domRoot.nodeId,selector:'#syntheticImport'})
    await win.webContents.debugger.sendCommand('DOM.setFileInputFiles',{nodeId,files:[imported]})
    win.webContents.debugger.detach()
    await win.webContents.executeJavaScript("window.launcher.files.importMods(Array.from(document.getElementById('syntheticImport').files))")
    const modFile = path.join(temp,'instances/churworld/mods/synthetic-dropin.jar')
    assert.equal(fs.readFileSync(modFile,'utf8'),'harmless synthetic mod fixture')
    await win.webContents.executeJavaScript("window.launcher.files.toggleMod('synthetic-dropin.jar',false)")
    assert.equal(fs.existsSync(modFile+'.disabled'),true)
    await win.webContents.executeJavaScript("window.launcher.files.removeMod('synthetic-dropin.jar.disabled')")
    assert.equal(fs.existsSync(modFile+'.disabled'),false)
    const javaChecksBefore = javaChecks
    const result = await win.webContents.executeJavaScript(`(async () => {
        const p = {require:typeof require,process:typeof process,remote:typeof remote,selected:ConfigManager.getSelectedAccount(),
            view:getCurrentView(),fatal:fatalStartupError,main:document.getElementById('main').style.display,launcherKeys:Object.keys(window.launcher),buttonDisabled:document.getElementById('launch_button').disabled,java:ConfigManager.getJavaExecutable(ConfigManager.getSelectedServer())}
        const cleaned = sanitizeContent('<script>window.injected=1</script><img src="x" onerror="window.injected=2"><a href="javascript:alert(1)">link</a><b>safe</b><iframe src="https://example.com"></iframe>')
        p.cleaned=cleaned;p.injected=window.injected||0;p.privateLeak=JSON.stringify(BOOT).includes('FAKE_PRIVATE')
        document.getElementById('settingsAboutDevToolsButton').click()
        await new Promise(resolve=>setTimeout(resolve,50))
        p.urlAfterDiagnostics=window.location.href
        document.getElementById('launch_button').click()
        await new Promise(resolve=>setTimeout(resolve,50))
        return p
    })()`)
    for(let attempt=0;attempt<100 && launches===0;attempt++) await new Promise(resolve=>setTimeout(resolve,10))
    assert.equal(javaChecks,javaChecksBefore+1)
    assert.equal(result.buttonDisabled,false);assert.equal(result.urlAfterDiagnostics,documentURL);assert.equal(win.webContents.getURL(),documentURL)
    assert.equal(result.privateLeak,false);assert.equal(result.require,'undefined');assert.equal(result.process,'undefined');assert.equal(result.remote,'undefined')
    assert.equal(result.fatal,false);assert.equal(result.view,'#landingContainer');assert.equal(result.injected,0)
    assert.equal(result.cleaned.includes('onerror'),false);assert.equal(result.cleaned.includes('javascript:'),false);assert.equal(result.cleaned.includes('iframe'),false)
    assert.equal(result.cleaned.includes('<b>safe</b>'),true);assert.equal(launches,1);assert.equal(diagnosticCalls,1)
    assert.deepEqual(errors,[])
    console.log(JSON.stringify({ok:true,checks:21,renderer:result.require,view:result.view,launches,diagnosticCalls}))
    win.destroy();app.exit(0)
}).catch(error => { console.error(error.stack); console.error(JSON.stringify({errors})); app.exit(1) })
