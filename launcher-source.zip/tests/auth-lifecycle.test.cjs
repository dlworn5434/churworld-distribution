'use strict'

const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const util = require('node:util')
const root = path.resolve(__dirname, '..')
const source = fs.readFileSync(path.join(root, 'app/assets/js/authmanager.js'), 'utf8')
const errors = require('../app/assets/js/auth-errors')
const NOW = 1800000000000
const SECRET = 'AUDIT_FAKE_SECRET_NOT_A_CREDENTIAL'

function account(uuid = 'AUDIT_A', overrides = {}) {
    return {
        type: 'microsoft', uuid, username: 'AuditFake', displayName: 'AuditFake',
        accessToken: SECRET + '_old_mc', expiresAt: NOW - 1,
        microsoft: { access_token: SECRET + '_old_ms', refresh_token: SECRET + '_old_refresh', expires_at: NOW - 1 },
        ...overrides
    }
}

function harness(initial = [account()]) {
    let database = Object.fromEntries(initial.map(a => [a.uuid, a]))
    let selected = initial[0]?.uuid ?? null
    let revision = 0
    let saveFailure = false
    const calls = [], logs = []
    let saves = 0, durableSaves = 0
    const ok = data => ({ responseStatus: 0, data })
    const config = {
        getSelectedAccount: () => database[selected],
        getAuthAccount: uuid => database[uuid],
        getAuthRevision: () => revision,
        setSelectedAccount(uuid) {
            if(database[uuid] && selected !== uuid) { selected = uuid; revision++ }
            return database[uuid]
        },
        addMicrosoftAuthAccount(uuid, accessToken, name, expiresAt, msAccess, msRefresh, msExpires) {
            database[uuid] = { type: 'microsoft', uuid, username: name, displayName: name, accessToken, expiresAt,
                microsoft: { access_token: msAccess, refresh_token: msRefresh, expires_at: msExpires } }
            selected = uuid; revision++; return database[uuid]
        },
        updateMicrosoftAuthAccount(uuid, accessToken, msAccess, msRefresh, msExpires, expiresAt) {
            assert.ok(database[uuid], 'must not resurrect a removed account')
            database[uuid] = { ...database[uuid], accessToken, expiresAt,
                microsoft: { access_token: msAccess, refresh_token: msRefresh, expires_at: msExpires } }
            revision++; return database[uuid]
        },
        removeAuthAccount(uuid) {
            if(!database[uuid]) return false
            delete database[uuid]
            if(selected === uuid) selected = Object.keys(database)[0] ?? null
            revision++; return true
        },
        transactionAuth(action) {
            const before = { ...database }, oldSelected = selected
            try {
                const result = action(); saves++
                if(saveFailure) throw new Error('disk/keychain failure ' + SECRET)
                durableSaves++; return result
            } catch(error) { database = before; selected = oldSelected; revision++; throw error }
        }
    }
    const code = { UNKNOWN: 0, NO_PROFILE: 1, NO_XBOX_ACCOUNT: 2148916233, XBL_BANNED: 2148916235, UNDER_18: 2148916238 }
    const handlers = {
        getAccessToken: async () => ok({ access_token: SECRET + '_new_ms', refresh_token: SECRET + '_new_refresh', expires_in: 3600 }),
        getXBLToken: async () => ok({ Token: SECRET + '_xbl' }),
        getXSTSToken: async () => ok({ Token: SECRET + '_xsts', DisplayClaims: { xui: [{ uhs: 'AUDIT_UHS' }] } }),
        getMCAccessToken: async () => ok({ access_token: SECRET + '_new_mc', expires_in: 7200 }),
        getMCProfile: async () => ok({ id: initial[0]?.uuid ?? 'AUDIT_A', name: 'AuditFake' })
    }
    const MicrosoftAuth = Object.fromEntries(Object.keys(handlers).map(name => [name, async (...args) => {
        calls.push({ name, args }); return handlers[name](...args)
    }]))
    const logger = Object.fromEntries(['error', 'warn', 'info', 'debug'].map(level => [level, (...args) => logs.push({ level, args })]))
    const dependencies = {
        './configmanager': config, './auth-errors': errors,
        'helios-core': { LoggerUtil: { getLogger: () => logger } },
        'helios-core/common': { RestResponseStatus: { SUCCESS: 0, ERROR: 1 } },
        'helios-core/microsoft': { MicrosoftAuth, MicrosoftErrorCode: code },
        './ipcconstants': { AZURE_CLIENT_ID: 'AUDIT_PUBLIC_CLIENT' },
        './langloader': { queryJS: key => key }
    }
    const module = { exports: {} }
    const context = vm.createContext({ module, exports: module.exports, Error,
        Date: class extends Date { static now() { return NOW } },
        console: Object.fromEntries(['log', 'warn', 'error'].map(level => [level, (...args) => logs.push({ level, args })])),
        require(id) { assert.ok(Object.hasOwn(dependencies, id), 'blocked undeclared/network dependency: ' + id); return dependencies[id] }
    })
    vm.runInContext(source, context, { filename: 'authmanager.js', timeout: 5000 })
    return { auth: module.exports, config, handlers, MicrosoftAuth, code, calls, logs, ok,
        get saves() { return saves }, get durableSaves() { return durableSaves },
        failSave() { saveFailure = true },
        assertNoSecretLogs() { assert.equal(util.inspect(logs, { depth: null }).includes(SECRET), false) }
    }
}

function failed(status, body = {}, microsoftErrorCode = 0) {
    return { responseStatus: 1, microsoftErrorCode,
        error: { response: { statusCode: status, body }, options: { form: { refresh_token: SECRET } } } }
}

function deferred() {
    let resolve
    const promise = new Promise(r => { resolve = r })
    return { promise, resolve }
}

test('valid cached Minecraft token does not contact services or write', async () => {
    const h = harness([account('AUDIT_A', { expiresAt: NOW + 60000 })])
    assert.equal(await h.auth.validateSelected(), true)
    assert.equal(h.calls.length, 0); assert.equal(h.saves, 0)
})

test('only Minecraft expired: preserve Microsoft pair and use its cached access token', async () => {
    const a = account(); a.microsoft.expires_at = NOW + 60000
    const h = harness([a]); assert.equal(await h.auth.validateSelected(), true)
    assert.equal(h.calls[0].name, 'getXBLToken'); assert.equal(h.calls[0].args[0], a.microsoft.access_token)
    assert.equal(h.calls.some(c => c.name === 'getAccessToken'), false)
    assert.equal(h.config.getSelectedAccount().microsoft.refresh_token, a.microsoft.refresh_token)
    assert.equal(h.config.getSelectedAccount().expiresAt, NOW + 7190000)
    assert.equal(h.durableSaves, 1)
})

test('full refresh rotates pair and follows response expires_in with ten-second margin', async () => {
    const h = harness(); assert.equal(await h.auth.validateSelected(), true)
    assert.deepEqual(h.calls[0].args, [SECRET + '_old_refresh', true, 'AUDIT_PUBLIC_CLIENT'])
    assert.equal(h.config.getSelectedAccount().microsoft.refresh_token, SECRET + '_new_refresh')
    assert.equal(h.config.getSelectedAccount().microsoft.expires_at, NOW + 3590000)
    assert.equal(h.durableSaves, 1); h.assertNoSecretLogs()
})

test('new login persists one complete account only after successful full flow', async () => {
    const h = harness([]); const result = await h.auth.addMicrosoftAccount(SECRET + '_code')
    assert.equal(h.calls[0].args[1], false)
    assert.equal(result.accessToken, SECRET + '_new_mc'); assert.equal(h.durableSaves, 1)
    h.assertNoSecretLogs()
})

test('network, 5xx, rate limit and even invalid_grant on 5xx preserve account', async t => {
    for(const status of [undefined, 408, 429, 500, 503]) {
        await t.test(String(status), async () => {
            const a = account(), h = harness([a])
            h.handlers.getAccessToken = async () => failed(status, { error: 'invalid_grant', secret: SECRET })
            await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_TEMPORARY_FAILURE' && e.retryable)
            assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.saves, 0); h.assertNoSecretLogs()
        })
    }
})

test('thrown transport errors are sanitized and do not store raw causes', async () => {
    const h = harness(); h.handlers.getAccessToken = async () => { throw new Error(SECRET) }
    await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_TEMPORARY_FAILURE' && !util.inspect(e, { showHidden: true }).includes(SECRET))
    assert.equal(h.saves, 0); h.assertNoSecretLogs()
})

test('explicit invalid_grant requires re-login without deleting saved account', async () => {
    const a = account(), h = harness([a]); h.handlers.getAccessToken = async () => failed(400, { error: 'invalid_grant' })
    assert.equal(await h.auth.validateSelected(), false); assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.saves, 0)
})

test('known account restrictions remain typed and do not become transport failure', async () => {
    const a = account(), h = harness([a]); h.handlers.getMCProfile = async () => failed(404, {}, h.code.NO_PROFILE)
    await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_ACCOUNT_ACTION_REQUIRED')
    assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.saves, 0)
})

test('malformed local expiry cannot enter the valid-cache branch', async t => {
    for(const expiresAt of [undefined, NaN, Infinity, 'tomorrow']) await t.test(String(expiresAt), async () => {
        const h = harness([account('AUDIT_A', { expiresAt })]); assert.equal(await h.auth.validateSelected(), false)
        assert.equal(h.calls.length, 0); assert.equal(h.saves, 0)
    })
})

test('invalid remote token response and mismatched profile never overwrite account', async t => {
    await t.test('token response', async () => {
        const a = account(), h = harness([a]); h.handlers.getAccessToken = async () => h.ok({ access_token: SECRET, expires_in: 3600 })
        await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_INVALID_RESPONSE')
        assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.saves, 0)
    })
    await t.test('profile mismatch', async () => {
        const a = account(), h = harness([a]); h.handlers.getMCProfile = async () => h.ok({ id: 'AUDIT_OTHER', name: 'AuditFake' })
        await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_INVALID_RESPONSE')
        assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.saves, 0)
    })
})

test('refresh storage failure rolls back runtime and leaves original credentials', async () => {
    const a = account(), h = harness([a]); h.failSave()
    await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_STORAGE_FAILURE' && !util.inspect(e).includes(SECRET))
    assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.durableSaves, 0)
})

test('new-login storage failure does not install an unsaved account', async () => {
    const h = harness([]); h.failSave()
    await assert.rejects(h.auth.addMicrosoftAccount(SECRET), e => e.code === 'AUTH_STORAGE_FAILURE')
    assert.equal(h.config.getSelectedAccount(), undefined); assert.equal(h.durableSaves, 0)
})

test('expiry arithmetic overflow is rejected before any account mutation', async () => {
    const a = account(), h = harness([a])
    h.handlers.getAccessToken = async () => h.ok({ access_token: SECRET, refresh_token: SECRET, expires_in: Number.MAX_SAFE_INTEGER })
    await assert.rejects(h.auth.validateSelected(), e => e.code === 'AUTH_INVALID_RESPONSE')
    assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.durableSaves, 0)
})

test('new-login failure after account switch is a cancellation, not a stale error', async () => {
    const a = account(), b = account('AUDIT_B'), h = harness([a, b]), hold = deferred()
    h.handlers.getAccessToken = () => hold.promise
    const pending = h.auth.addMicrosoftAccount(SECRET)
    h.config.setSelectedAccount(b.uuid); hold.resolve(failed(400, { error: 'invalid_grant' }))
    await assert.rejects(pending, e => e.code === 'AUTH_STATE_CHANGED')
    assert.equal(h.config.getSelectedAccount(), b); assert.equal(h.saves, 0)
})

test('concurrent validation of same account shares a refresh', async () => {
    const h = harness(), hold = deferred(); h.handlers.getAccessToken = () => hold.promise
    const one = h.auth.validateSelected(), two = h.auth.validateSelected()
    assert.equal(h.calls.length, 1)
    hold.resolve(h.ok({ access_token: SECRET, refresh_token: SECRET, expires_in: 3600 }))
    assert.deepEqual(await Promise.all([one, two]), [true, true]); assert.equal(h.durableSaves, 1)
})

test('selection A to B to A still cancels stale result by revision', async () => {
    const a = account(), b = account('AUDIT_B'), h = harness([a, b]), hold = deferred()
    h.handlers.getAccessToken = () => hold.promise
    const pending = h.auth.validateSelected()
    h.config.setSelectedAccount(b.uuid); h.config.setSelectedAccount(a.uuid)
    hold.resolve(h.ok({ access_token: SECRET, refresh_token: SECRET, expires_in: 3600 }))
    await assert.rejects(pending, e => e.code === 'AUTH_STATE_CHANGED' && e.cancelled)
    assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.saves, 0)
})

test('explicit logout while refreshing cannot resurrect an account', async () => {
    const a = account(), h = harness([a]), hold = deferred(); h.handlers.getAccessToken = () => hold.promise
    const pending = h.auth.validateSelected(); await h.auth.removeMicrosoftAccount(a.uuid)
    hold.resolve(h.ok({ access_token: SECRET, refresh_token: SECRET, expires_in: 3600 }))
    await assert.rejects(pending, e => e.code === 'AUTH_STATE_CHANGED')
    assert.equal(h.config.getAuthAccount(a.uuid), undefined); assert.equal(h.durableSaves, 1)
})

test('stale authentication failure does not request re-login against a new selection', async () => {
    const a = account(), b = account('AUDIT_B'), h = harness([a, b]), hold = deferred(); h.handlers.getAccessToken = () => hold.promise
    const pending = h.auth.validateSelected(); h.config.setSelectedAccount(b.uuid)
    hold.resolve(failed(400, { error: 'invalid_grant' }))
    await assert.rejects(pending, e => e.code === 'AUTH_STATE_CHANGED'); assert.equal(h.config.getSelectedAccount(), b)
})

test('legacy password function never imports/calls Mojang API or stores credentials', async () => {
    const h = harness([account('AUDIT_OLD', { type: 'mojang' })])
    await assert.rejects(h.auth.addMojangAccount('audit@example.invalid', SECRET), e => e.code === 'AUTH_LEGACY_DISABLED')
    assert.equal(await h.auth.validateSelected(), false); assert.equal(h.calls.length, 0); assert.equal(h.saves, 0)
    await h.auth.removeMojangAccount('AUDIT_OLD')
    assert.equal(h.config.getSelectedAccount(), undefined); assert.equal(h.calls.length, 0); assert.equal(h.durableSaves, 1)
    h.assertNoSecretLogs()
})

test('local removal storage failure restores original account without remote invalidation', async () => {
    const a = account(), h = harness([a]); h.failSave()
    await assert.rejects(h.auth.removeMicrosoftAccount(a.uuid), e => e.code === 'AUTH_STORAGE_FAILURE')
    assert.equal(h.config.getSelectedAccount(), a); assert.equal(h.calls.length, 0)
})

test('helios logger adapter discards complete error, response and header objects', () => {
    const h = harness()
    h.MicrosoftAuth.logger.error('raw ' + SECRET, { request: { body: SECRET } })
    h.MicrosoftAuth.logger.debug('Body:', { access_token: SECRET, refresh_token: SECRET })
    h.MicrosoftAuth.logger.warn(SECRET); h.MicrosoftAuth.logger.info(SECRET)
    h.assertNoSecretLogs(); assert.equal(h.logs.length, 2)
})
