'use strict'
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const {spawnSync} = require('node:child_process')
const tool = path.resolve(__dirname, '../tools/release-key.cjs')

test('operator vault protects its key and signs only bounded payloads', {skip:process.platform !== 'win32', timeout:90000}, async t => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'churworld-signing-test-'))
    const vault = path.join(directory, 'vault')
    const publicFile = path.join(directory, 'public.json')
    const payloadFile = path.join(directory, 'payload.json')
    const envelopeFile = path.join(directory, 'envelope.json')
    const run = (...args) => spawnSync(process.execPath, [tool, ...args, '--key-dir', vault], {encoding:'utf8', windowsHide:true, timeout:30000})
    const payload = {schema:1, purpose:'distribution', sequence:1, issuedAt:new Date().toISOString(), expiresAt:new Date(Date.now() + 86400000).toISOString(), distribution:{servers:[{id:'synthetic', modules:[]}]}}
    try {
        await t.test('DPAPI vault and public export are distinct', () => {
            const result = run('init', '--id', 'synthetic-test-key', '--public-out', publicFile)
            assert.equal(result.status, 0, result.stderr)
            const value = JSON.parse(fs.readFileSync(path.join(vault, 'release-key.dpapi.json')))
            assert.equal(value.protection, 'Windows-DPAPI-CurrentUser')
            assert.equal(value.privateKey, undefined)
            assert.ok(value.ciphertext.length > 80)
            assert.equal(JSON.parse(fs.readFileSync(publicFile)).keys[0].id, 'synthetic-test-key')
            assert.ok(!fs.readFileSync(publicFile, 'utf8').includes(value.ciphertext))
        })
        await t.test('signature verifies only the exact domain-separated payload', () => {
            fs.writeFileSync(payloadFile, JSON.stringify(payload))
            const result = run('sign', '--input', payloadFile, '--out', envelopeFile)
            assert.equal(result.status, 0, result.stderr)
            const signed = JSON.parse(fs.readFileSync(envelopeFile))
            const publicKey = crypto.createPublicKey({key:Buffer.from(JSON.parse(fs.readFileSync(publicFile)).keys[0].publicKeySpki, 'base64'), format:'der', type:'spki'})
            const message = Buffer.concat([Buffer.from('ChurWorld signed manifest v1\n'), Buffer.from(signed.payload, 'base64')])
            assert.equal(crypto.verify(null, message, publicKey, Buffer.from(signed.signature, 'base64')), true)
            message[message.length - 1] ^= 1
            assert.equal(crypto.verify(null, message, publicKey, Buffer.from(signed.signature, 'base64')), false)
        })
        await t.test('existing keys and signed files cannot be overwritten', () => {
            const before = fs.readFileSync(envelopeFile)
            assert.notEqual(run('init', '--id', 'replacement-test-key', '--public-out', publicFile).status, 0)
            assert.notEqual(run('sign', '--input', payloadFile, '--out', envelopeFile).status, 0)
            assert.deepEqual(fs.readFileSync(envelopeFile), before)
        })
        await t.test('same-sequence replacement is rejected but identical retry succeeds', () => {
            const replacement = path.join(directory, 'conflict.json'), retry = path.join(directory, 'retry.json')
            fs.writeFileSync(payloadFile, JSON.stringify({...payload, distribution:{servers:[{id:'changed', modules:[]}]}}))
            assert.notEqual(run('sign', '--input', payloadFile, '--out', replacement).status, 0)
            assert.equal(fs.existsSync(replacement), false)
            fs.writeFileSync(payloadFile, JSON.stringify(payload))
            assert.equal(run('sign', '--input', payloadFile, '--out', retry).status, 0)
            assert.deepEqual(JSON.parse(fs.readFileSync(retry)), JSON.parse(fs.readFileSync(envelopeFile)))
        })
        for(const [label, change] of [
            ['expired', {expiresAt:new Date(Date.now() - 1000).toISOString()}],
            ['overlong lifetime', {expiresAt:new Date(Date.now() + 31 * 86400000).toISOString()}],
            ['future issue', {issuedAt:new Date(Date.now() + 3600000).toISOString()}],
            ['unknown purpose', {purpose:'arbitrary-command'}],
            ['invalid sequence', {sequence:0}],
            ['invalid distribution schema', {distribution:{servers:[]}}],
            ['issue before key validity', {issuedAt:new Date(Date.now() - 86400000).toISOString()}]
        ]) await t.test(`rejects ${label} without an output file`, () => {
            const target = path.join(directory, label + '.signed.json')
            fs.writeFileSync(payloadFile, JSON.stringify({...payload, ...change}))
            assert.notEqual(run('sign', '--input', payloadFile, '--out', target).status, 0)
            assert.equal(fs.existsSync(target), false)
        })
    } finally {
        const resolved = fs.realpathSync(directory)
        const temporary = fs.realpathSync(os.tmpdir())
        assert.equal(path.dirname(resolved).toLowerCase(), temporary.toLowerCase())
        assert.ok(path.basename(resolved).startsWith('churworld-signing-test-'))
        fs.rmSync(resolved, {recursive:true, force:true})
    }
})
