'use strict'
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const crypto = require('node:crypto')
const vm = require('node:vm')
const { createRequire } = require('node:module')
const { Readable } = require('node:stream')
const { EventEmitter } = require('node:events')
const trust = require('../app/assets/js/trusted-manifest')
const secure = require('../app/assets/js/secure-download')
const { TrustedCache } = require('../app/assets/js/trusted-cache')
const { prepareDistribution } = require('../tools/trusted-manifest.cjs')
const NOW = Date.parse('2026-10-23T00:00:00Z')
const keys = crypto.generateKeyPairSync('ed25519')
const config = { schema: 1, keys: [{ id: 'fixture', algorithm: 'Ed25519', publicKeySpki: keys.publicKey.export({ type: 'spki', format: 'der' }).toString('base64'), purposes: ['distribution', 'launcher-update'], notBefore: '2026-01-01T00:00:00Z', notAfter: '2027-01-01T00:00:00Z' }] }
const URL_ROOT = 'https://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/'
const bytes = Buffer.from('AUDIT_FAKE_ARTIFACT_NOT_EXECUTABLE')
const sha = content => crypto.createHash('sha256').update(content).digest('hex')
function moduleFile(overrides = {}) { return { id: 'example', name: 'Fixture', type: 'File', artifact: { path: 'mods/example.jar', size: bytes.length, SHA256: sha(bytes), MD5: crypto.createHash('md5').update(bytes).digest('hex'), url: URL_ROOT + 'files/example.jar' }, ...overrides } }
function payload(overrides = {}) { return { schema: 1, purpose: 'distribution', sequence: 1, issuedAt: '2026-10-22T23:00:00Z', expiresAt: '2026-10-24T23:00:00Z', distribution: { servers: [{ id: 'fixture', name: 'Fixture', address: 'localhost:25565', minecraftVersion: '1.21.4', modules: [moduleFile()] }] }, ...overrides } }
function envelope(body) { const data = Buffer.from(JSON.stringify(body)); return { schema: 1, keyId: 'fixture', payload: data.toString('base64'), signature: crypto.sign(null, Buffer.concat([trust.SIGNING_PREFIX, data]), keys.privateKey).toString('base64') } }
function verify(input, extra = {}) { return trust.verifyEnvelope(input, { purpose: 'distribution', keys: config, now: NOW, ...extra }) }
function temporary(t) { const dir = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'churworld-signed-test-'))); t.after(() => fs.rmSync(dir, { recursive: true, force: true })); return dir }
function requestFixture(routes, requests = []) {
    return (url, options, callback) => {
        requests.push({ url: url.href, options })
        const req = new EventEmitter(); req.destroy = error => req.emit('error', error)
        process.nextTick(() => {
            const fixture = routes[url.href]
            if(!fixture) return req.emit('error', new Error('Fixture network unavailable'))
            const response = Readable.from(fixture.chunks || [fixture.body || Buffer.alloc(0)])
            response.statusCode = fixture.status || 200; response.headers = fixture.headers || {}
            callback(response)
        })
        return req
    }
}
test('actual Ed25519 signature accepts canonical envelope and rejects payload+hash substitution', () => {
    const signed = envelope(payload())
    assert.equal(verify(signed).payload.sequence, 1)
    const changed = payload(); changed.distribution.servers[0].modules[0].artifact.SHA256 = 'a'.repeat(64)
    signed.payload = Buffer.from(JSON.stringify(changed)).toString('base64')
    assert.throws(() => verify(signed), { code: 'TRUST_SIGNATURE_INVALID' })
})
for(const [name, change, code] of [
    ['unknown key', signed => { signed.keyId = 'attacker' }, 'TRUST_KEY_UNKNOWN'],
    ['malformed signature', signed => { signed.signature = 'AAAA' }, 'TRUST_SIGNATURE_INVALID'],
    ['missing signature', signed => { delete signed.signature }, 'TRUST_ENCODING_INVALID'],
    ['noncanonical base64', signed => { signed.payload += '\n' }, 'TRUST_ENCODING_INVALID']
]) test(name, () => { const signed = envelope(payload()); change(signed); assert.throws(() => verify(signed), { code }) })
for(const [name, change, code] of [
    ['expired', body => { body.expiresAt = '2026-10-22T23:30:00Z' }, 'TRUST_MANIFEST_EXPIRED'],
    ['future issued', body => { body.issuedAt = '2026-10-23T01:00:00Z' }, 'TRUST_DATE_INVALID'],
    ['unbounded expiry', body => { body.expiresAt = '2026-12-23T00:00:00Z' }, 'TRUST_DATE_INVALID'],
    ['wrong purpose', body => { body.purpose = 'launcher-update' }, 'TRUST_PAYLOAD_INVALID'],
    ['noninteger sequence', body => { body.sequence = 1.2 }, 'TRUST_PAYLOAD_INVALID'],
    ['MD5 only executable', body => { delete body.distribution.servers[0].modules[0].artifact.SHA256 }, 'TRUST_ARTIFACT_INVALID'],
    ['unsafe server path', body => { body.distribution.servers[0].id = '../outside' }, 'TRUST_SERVER_INVALID'],
    ['mutable executable', body => { body.distribution.servers[0].modules[0].artifact.mutable = true }, 'TRUST_MUTABLE_INVALID']
]) test(name, () => { const body = payload(); change(body); assert.throws(() => verify(envelope(body)), { code }) })
for(const invalid of ['../escape.jar', '/escape.jar', 'C:/escape.jar', 'config/../escape.jar', 'config\\evil.jar', 'config/CON.txt', 'config/x.', 'config/x:stream']) test(`reject unsafe artifact path ${invalid}`, () => { const body = payload(); body.distribution.servers[0].modules[0].artifact.path = invalid; assert.throws(() => verify(envelope(body)), { code: 'TRUST_PATH_INVALID' }) })
test('sequence floor and same sequence equivocation are rejected, identical refresh accepted', () => {
    const previous = verify(envelope(payload({ sequence: 4 })))
    assert.throws(() => verify(envelope(payload({ sequence: 3 })), { previous }), { code: 'TRUST_ROLLBACK' })
    assert.equal(verify(envelope(payload({ sequence: 4 })), { previous }).digest, previous.digest)
    assert.throws(() => verify(envelope(payload({ sequence: 4, extra: true })), { previous }), { code: 'TRUST_ROLLBACK' })
    assert.throws(() => verify(envelope(payload()), { keys: { ...config, minimumSequence: { distribution: 2 } } }), { code: 'TRUST_ROLLBACK' })
})
test('launcher version cannot decrease even with increasing sequence', () => {
    const update = version => ({ schema: 1, purpose: 'launcher-update', sequence: 1, issuedAt: '2026-10-22T23:00:00Z', expiresAt: '2026-10-24T23:00:00Z', version, artifacts: [{ platform: 'win32', arch: 'x64', name: `ChurWorld-Launcher-setup-${version}.exe`, size: bytes.length, sha256: sha(bytes), url: `https://github.com/dlworn5434/churworld-distribution/releases/download/v${version}/ChurWorld-Launcher-setup-${version}.exe` }] })
    const previous = verify(envelope(update('2.3.0')), { purpose: 'launcher-update' })
    assert.throws(() => verify(envelope({ ...update('2.2.9'), sequence: 2 }), { purpose: 'launcher-update', previous }), { code: 'TRUST_ROLLBACK' })
})
for(const bad of ['http://raw.githubusercontent.com/dlworn5434/churworld-distribution/main/a', 'https://evil.test/a', 'https://github.com/attacker/repository/releases/download/v1/a', 'https://user:pass@github.com/dlworn5434/churworld-distribution/releases/download/v1/a', URL_ROOT + 'files/../a', URL_ROOT + 'files/%2e%2e/a']) test(`reject URL ${bad}`, () => assert.throws(() => trust.approvedUrl(bad), trust.TrustError))
test('immutable artifact commits are accepted, while metadata remains on main', () => {
    const commit = '632234307adcb5589661f5ae5ae0d8035b4bf359'
    const url = URL_ROOT.replace('/main/', `/${commit}/`) + 'files/example.jar'
    assert.equal(trust.approvedUrl(url).href, url)
    const body = payload(); body.distribution.servers[0].modules[0].artifact.url = url
    assert.equal(verify(envelope(body)).payload.distribution.servers[0].modules[0].artifact.url, url)
    assert.throws(() => trust.approvedUrl(url, { manifest: true }), { code: 'TRUST_URL_NOT_APPROVED' })
    assert.equal(trust.approvedUrl(URL_ROOT + 'distribution.signed.json', { manifest: true }).hostname, 'raw.githubusercontent.com')
})
for(const ref of ['feature', 'v2.2.10', 'a'.repeat(39), 'a'.repeat(41), 'A'.repeat(40), 'g'.repeat(40)]) test(`reject noncanonical artifact ref ${ref}`, () => {
    assert.throws(() => trust.approvedUrl(URL_ROOT.replace('/main/', `/${ref}/`) + 'files/example.jar'), { code: 'TRUST_URL_NOT_APPROVED' })
})
test('pinned commit cannot authorize a foreign repository, query or non-HTTPS source', () => {
    const url = URL_ROOT.replace('/main/', `/${'a'.repeat(40)}/`) + 'files/example.jar'
    for(const candidate of [url.replace('dlworn5434', 'attacker'), url + '?ref=main', url.replace('https:', 'http:')]) assert.throws(() => trust.approvedUrl(candidate), trust.TrustError)
})
test('each redirect is validated before any second request, including downgrade and unrelated HTTPS host', async () => {
    for(const location of ['http://github.com/unsafe', 'https://evil.test/payload']) {
        const requests = []
        await assert.rejects(secure.fetchBytes(URL_ROOT + 'a', { maxBytes: 100, request: requestFixture({ [URL_ROOT + 'a']: { status: 302, headers: { location } } }, requests) }), trust.TrustError)
        assert.equal(requests.length, 1)
        assert.equal(requests[0].options.rejectUnauthorized, true)
    }
})
test('HTTPS redirect chain to approved release asset downloads with exact signed size/hash', async t => {
    const dir = temporary(t), target = path.join(dir, 'update.exe'), initial = 'https://github.com/dlworn5434/churworld-distribution/releases/download/v2.2.9/test.exe', final = 'https://release-assets.githubusercontent.com/github-production-release-asset/1/2?sig=fixture'
    const request = requestFixture({ [initial]: { status: 302, headers: { location: final } }, [final]: { body: bytes, headers: { 'content-length': String(bytes.length) } } })
    await secure.downloadFile({ url: initial, size: bytes.length, sha256: sha(bytes) }, target, undefined, { request })
    assert.deepEqual(fs.readFileSync(target), bytes)
    assert.equal(await secure.verifyFile({ url: initial, size: bytes.length, sha256: sha(bytes) }, target), true)
})
for(const kind of ['hash', 'short', 'oversize', 'contentLength']) test(`failed ${kind} download retains original and removes partial`, async t => {
    const dir = temporary(t), target = path.join(dir, 'module.jar'), url = URL_ROOT + 'module.jar'
    fs.writeFileSync(target, 'ORIGINAL')
    const body = kind === 'short' ? bytes.subarray(1) : kind === 'oversize' ? Buffer.concat([bytes, bytes]) : Buffer.from(bytes)
    if(kind === 'hash') body[0] ^= 1
    const request = requestFixture({ [url]: { body, headers: kind === 'contentLength' ? { 'content-length': '99999' } : {} } })
    await assert.rejects(secure.downloadFile({ url, size: bytes.length, sha256: sha(bytes) }, target, undefined, { request }))
    assert.equal(fs.readFileSync(target, 'utf8'), 'ORIGINAL')
    assert.deepEqual(fs.readdirSync(dir), ['module.jar'])
})
test('junction escape is rejected by actual filesystem walker', t => {
    const dir = temporary(t), root = path.join(dir, 'root'), outside = path.join(dir, 'outside')
    fs.mkdirSync(root); fs.mkdirSync(outside); fs.symlinkSync(outside, path.join(root, 'linked'), 'junction')
    assert.throws(() => secure.safeDestination(path.join(root, 'linked', 'payload.jar'), root), { code: 'TRUST_PATH_LINK' })
})
test('signed cache retains last good on tampering, rejects replay and corrupted disk', async t => {
    const directory = temporary(t); let remote = envelope(payload({ sequence: 2 }))
    const cache = new TrustedCache({ directory, purpose: 'distribution', url: URL_ROOT + 'distribution.signed.json', keys: config, now: () => NOW, fetch: async () => JSON.stringify(remote) })
    await cache.refresh(); const original = fs.readFileSync(cache.filename)
    remote = envelope(payload()); await assert.rejects(cache.refresh(), { code: 'TRUST_ROLLBACK' }); assert.deepEqual(fs.readFileSync(cache.filename), original)
    remote = { ...remote, signature: envelope(payload({ extra: true })).signature }; await assert.rejects(cache.refresh(), { code: 'TRUST_SIGNATURE_INVALID' }); assert.deepEqual(fs.readFileSync(cache.filename), original)
    fs.writeFileSync(cache.filename, '{"distribution":{}}'); await assert.rejects(cache.refresh(), { code: 'TRUST_ENVELOPE_INVALID' })
})
test('offline cache works only before expiry, with no stale in-memory bypass', async t => {
    const directory = temporary(t); let now = NOW, offline = false
    const cache = new TrustedCache({ directory, purpose: 'distribution', url: URL_ROOT + 'distribution.signed.json', keys: config, now: () => now, fetch: async () => { if(offline) throw Object.assign(new Error('offline'), { code: 'TRUST_NETWORK_FAILED' }); return JSON.stringify(envelope(payload())) } })
    await cache.refresh(); offline = true; assert.equal((await cache.refresh()).payload.sequence, 1)
    now += 4 * 86400000; await assert.rejects(cache.refresh(), { code: 'TRUST_MANIFEST_EXPIRED' })
    assert.equal(cache.read(true).payload.sequence, 1)
})
test('serialized copied launcher info has no approval and cannot authorize a download', async () => {
    const updates = require('../app/assets/js/trusted-updates')
    assert.throws(() => updates.assertTrustedUpdate({ version: '2.2.9', artifact: { sha256: sha(bytes) } }), { code: 'TRUST_UPDATE_NOT_APPROVED' })
})

test('real signed update lifecycle approves one descriptor, rehashes installer and invalidates superseded approval', async t => {
    const directory = temporary(t), now = Date.now()
    const body = (version, sequence) => ({ schema: 1, purpose: 'launcher-update', sequence, version, issuedAt: new Date(now - 60000).toISOString(), expiresAt: new Date(now + 86400000).toISOString(), artifacts: [{ platform: 'win32', arch: 'x64', name: `ChurWorld-Launcher-setup-${version}.exe`, url: `https://github.com/dlworn5434/churworld-distribution/releases/download/v${version}/ChurWorld-Launcher-setup-${version}.exe`, size: bytes.length, sha256: sha(bytes) }] })
    let remote = body('2.2.9', 1)
    class FixtureCache extends TrustedCache {
        constructor(options) { super({ ...options, keys: config, fetch: async () => JSON.stringify(envelope(remote)) }) }
    }
    const filename = path.resolve(__dirname, '../app/assets/js/trusted-updates.js'), realRequire = createRequire(filename), module = { exports: {} }
    const transport = (url, options, callback) => requestFixture({ [url.href]: { body: bytes } })(url, options, callback)
    vm.runInNewContext(fs.readFileSync(filename, 'utf8'), { require: name => name === './trusted-cache' ? { TrustedCache: FixtureCache } : name === './secure-download' ? { ...secure, downloadFile: (descriptor, target, progress) => secure.downloadFile(descriptor, target, progress, { request: transport }) } : realRequire(name), module, exports: module.exports }, { filename })
    const updates = module.exports
    const info = await updates.getTrustedUpdate({ platform: 'win32', arch: 'x64', currentVersion: '2.2.8', cacheDirectory: directory })
    const target = path.join(directory, info.artifact.name)
    await updates.downloadTrustedUpdate(info, target)
    assert.equal(await updates.verifyTrustedUpdate(info, target), true)
    await assert.rejects(updates.downloadTrustedUpdate({ ...info }, target), { code: 'TRUST_UPDATE_NOT_APPROVED' })
    fs.writeFileSync(target, Buffer.alloc(bytes.length))
    await assert.rejects(updates.verifyTrustedUpdate(info, target), { code: 'TRUST_FILE_HASH' })
    remote = body('2.2.10', 2)
    assert.equal((await updates.getTrustedUpdate({ platform: 'win32', arch: 'x64', currentVersion: '2.2.8', cacheDirectory: directory })).version, '2.2.10')
    assert.throws(() => updates.assertTrustedUpdate(info), { code: 'TRUST_ROLLBACK' })
})
test('real distro factory preserves existing mutable settings and enforces final executable hash', async t => {
    const dir = temporary(t), common = path.join(dir, 'common'), instances = path.join(dir, 'instances')
    const filename = path.resolve(__dirname, '../app/assets/js/distromanager.js'), realRequire = createRequire(filename), module = { exports: {} }
    const configStub = { getLauncherDirectory: () => dir, getCommonDirectory: () => common }
    const requireFixture = name => name === './configmanager' ? configStub : name === 'helios-core' ? { LoggerUtil: { getLogger: () => ({ warn() {} }) } } : realRequire(name)
    vm.runInNewContext(fs.readFileSync(filename, 'utf8'), { require: requireFixture, module, exports: module.exports, process }, { filename })
    const api = new module.exports.ManagedDistributionAPI(dir, common, instances, URL_ROOT + 'distribution.signed.json', false)
    const body = payload(), seed = moduleFile({ id: 'settings' }); seed.artifact = { ...seed.artifact, path: 'config/xaerohud.txt', mutable: true }; delete seed.artifact.MD5
    body.distribution.servers[0].modules.push(seed)
    const verified = verify(envelope(body))
    api.trustedCache = new TrustedCache({ directory: path.join(dir, 'metadata'), purpose: 'distribution', url: '', keys: config, now: () => NOW })
    secure.atomicWrite(api.trustedCache.filename, JSON.stringify(verified.envelope), api.trustedCache.directory)
    const distro = api.build(verified), server = path.join(instances, 'fixture')
    fs.mkdirSync(path.join(server, 'mods'), { recursive: true }); fs.mkdirSync(path.join(server, 'config'), { recursive: true })
    fs.writeFileSync(path.join(server, 'mods/example.jar'), bytes); fs.writeFileSync(path.join(server, 'config/xaerohud.txt'), 'USER_CUSTOM_POSITION')
    await api.prepareServerFiles(distro, 'fixture'); await api.verifyServerFiles(distro, 'fixture')
    assert.equal(fs.readFileSync(path.join(server, 'config/xaerohud.txt'), 'utf8'), 'USER_CUSTOM_POSITION')
    fs.writeFileSync(path.join(server, 'mods/example.jar'), Buffer.alloc(bytes.length))
    await assert.rejects(api.verifyServerFiles(distro, 'fixture'), { code: 'TRUST_FILE_HASH' })
    assert.throws(() => { distro.rawDistribution.servers[0].modules[0].artifact.SHA256 = '0'.repeat(64) }, TypeError)
    api.trustedCache.now = () => NOW + 4 * 86400000
    assert.equal(await api.getDistribution(), distro)
    assert.equal(api.isOfflineOnly(distro), true)
    await assert.rejects(api.prepareServerFiles(distro, 'fixture'), { code: 'TRUST_FILE_HASH' })
})
test('offline manifest generator maps approved files only and leaves source unchanged', t => {
    const dir = temporary(t), body = payload(), raw = body.distribution
    fs.mkdirSync(path.join(dir, 'files')); fs.writeFileSync(path.join(dir, 'files/example.jar'), bytes)
    const original = JSON.stringify(raw); fs.writeFileSync(path.join(dir, 'distribution.json'), original)
    const result = prepareDistribution({ source: dir, sequence: 1, issuedAt: body.issuedAt, expiresAt: body.expiresAt })
    assert.equal(result.count, 1); assert.equal(result.payload.distribution.servers[0].modules[0].artifact.SHA256, sha(bytes))
    assert.equal(fs.readFileSync(path.join(dir, 'distribution.json'), 'utf8'), original)
    const commit = '632234307adcb5589661f5ae5ae0d8035b4bf359'
    const pinned = prepareDistribution({ source: dir, sequence: 2, issuedAt: body.issuedAt, expiresAt: body.expiresAt, sourceCommit: commit })
    const item = pinned.payload.distribution.servers[0].modules[0].artifact
    assert.equal(item.url, URL_ROOT.replace('/main/', `/${commit}/`) + 'files/example.jar')
    assert.equal(item.SHA256, sha(bytes))
    assert.equal(verify(envelope(pinned.payload)).payload.sequence, 2)
    assert.equal(fs.readFileSync(path.join(dir, 'distribution.json'), 'utf8'), original)
    for(const sourceCommit of ['main', 'A'.repeat(40), 'a'.repeat(39)]) assert.throws(() => prepareDistribution({ source: dir, sourceCommit }), /MANIFEST_SOURCE_COMMIT_INVALID/)
})
test('Mac helper rechecks complete bundle and signed DMG before swap; real macOS execution required', () => {
    const helper = fs.readFileSync(path.join(__dirname, '../app/assets/js/mac-update-install.sh'), 'utf8')
    assert.ok(helper.indexOf('bundle-digest.sh') < helper.indexOf('/bin/mv "$app" "$backup"'))
    assert.match(helper, /TeamIdentifier=\$team_id/)
    assert.match(helper, /actual_dmg=.*shasum/)
})
